﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGame
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmGame))
        Me.btnClose = New System.Windows.Forms.Button
        Me.tmrGameTick = New System.Windows.Forms.Timer(Me.components)
        Me.picFragileWall6 = New System.Windows.Forms.PictureBox
        Me.picFragileWall5 = New System.Windows.Forms.PictureBox
        Me.picFragileWall4 = New System.Windows.Forms.PictureBox
        Me.picExplosion6 = New System.Windows.Forms.PictureBox
        Me.picExplosion5 = New System.Windows.Forms.PictureBox
        Me.picExplosion2 = New System.Windows.Forms.PictureBox
        Me.picExplosion4 = New System.Windows.Forms.PictureBox
        Me.picExplosion3 = New System.Windows.Forms.PictureBox
        Me.picExplosion1 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet9 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet8 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet7 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet6 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet5 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet4 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet3 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet2 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet1 = New System.Windows.Forms.PictureBox
        Me.picEnemyBullet10 = New System.Windows.Forms.PictureBox
        Me.picPilotHealth = New System.Windows.Forms.PictureBox
        Me.picPilot = New System.Windows.Forms.PictureBox
        Me.picTutorialText4 = New System.Windows.Forms.PictureBox
        Me.picFloor6 = New System.Windows.Forms.PictureBox
        Me.picWall4 = New System.Windows.Forms.PictureBox
        Me.picFragileWall3 = New System.Windows.Forms.PictureBox
        Me.picFragileWall2 = New System.Windows.Forms.PictureBox
        Me.picFragileWall1 = New System.Windows.Forms.PictureBox
        Me.picDefAlienHealth2 = New System.Windows.Forms.PictureBox
        Me.picDefAlien2 = New System.Windows.Forms.PictureBox
        Me.picTalkBox = New System.Windows.Forms.PictureBox
        Me.picTutorialText3 = New System.Windows.Forms.PictureBox
        Me.picWall3 = New System.Windows.Forms.PictureBox
        Me.picFloor5 = New System.Windows.Forms.PictureBox
        Me.picCorner1 = New System.Windows.Forms.PictureBox
        Me.picWall2 = New System.Windows.Forms.PictureBox
        Me.picCeiling2 = New System.Windows.Forms.PictureBox
        Me.picWallPanel1 = New System.Windows.Forms.PictureBox
        Me.picTutorialText2 = New System.Windows.Forms.PictureBox
        Me.picTutorialText1 = New System.Windows.Forms.PictureBox
        Me.picBullet10 = New System.Windows.Forms.PictureBox
        Me.picBullet8 = New System.Windows.Forms.PictureBox
        Me.picBullet9 = New System.Windows.Forms.PictureBox
        Me.picBullet7 = New System.Windows.Forms.PictureBox
        Me.picBullet6 = New System.Windows.Forms.PictureBox
        Me.picBullet5 = New System.Windows.Forms.PictureBox
        Me.picBullet4 = New System.Windows.Forms.PictureBox
        Me.picBullet3 = New System.Windows.Forms.PictureBox
        Me.picBullet2 = New System.Windows.Forms.PictureBox
        Me.picBullet1 = New System.Windows.Forms.PictureBox
        Me.picDefAlienHealth1 = New System.Windows.Forms.PictureBox
        Me.picSpikeballHealth = New System.Windows.Forms.PictureBox
        Me.picFloor4 = New System.Windows.Forms.PictureBox
        Me.picFloor3 = New System.Windows.Forms.PictureBox
        Me.picFloor2 = New System.Windows.Forms.PictureBox
        Me.picFloor1 = New System.Windows.Forms.PictureBox
        Me.picDefAlien1 = New System.Windows.Forms.PictureBox
        Me.picSpikeball = New System.Windows.Forms.PictureBox
        Me.picCeiling1 = New System.Windows.Forms.PictureBox
        Me.picWall1 = New System.Windows.Forms.PictureBox
        Me.picAlarm = New System.Windows.Forms.PictureBox
        Me.lblAmmo = New System.Windows.Forms.Label
        Me.lblGunType = New System.Windows.Forms.Label
        Me.lblLives = New System.Windows.Forms.Label
        Me.picLifeIcon = New System.Windows.Forms.PictureBox
        CType(Me.picFragileWall6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFragileWall5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFragileWall4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExplosion6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExplosion5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExplosion2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExplosion4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExplosion3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picExplosion1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEnemyBullet10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPilotHealth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPilot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTutorialText4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFloor6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWall4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFragileWall3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFragileWall2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFragileWall1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDefAlienHealth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDefAlien2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTalkBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTutorialText3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWall3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFloor5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCorner1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWall2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCeiling2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWallPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTutorialText2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTutorialText1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDefAlienHealth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSpikeballHealth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFloor4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFloor3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFloor2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFloor1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDefAlien1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSpikeball, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCeiling1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWall1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAlarm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLifeIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Black
        Me.btnClose.FlatAppearance.BorderSize = 0
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Red
        Me.btnClose.Location = New System.Drawing.Point(1239, 12)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(29, 27)
        Me.btnClose.TabIndex = 3
        Me.btnClose.TabStop = False
        Me.btnClose.Text = "X"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'tmrGameTick
        '
        Me.tmrGameTick.Interval = 20
        '
        'picFragileWall6
        '
        Me.picFragileWall6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFragileWall6.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall6.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall6.Location = New System.Drawing.Point(5620, 220)
        Me.picFragileWall6.Name = "picFragileWall6"
        Me.picFragileWall6.Size = New System.Drawing.Size(30, 100)
        Me.picFragileWall6.TabIndex = 65
        Me.picFragileWall6.TabStop = False
        '
        'picFragileWall5
        '
        Me.picFragileWall5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFragileWall5.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall5.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall5.Location = New System.Drawing.Point(5620, 420)
        Me.picFragileWall5.Name = "picFragileWall5"
        Me.picFragileWall5.Size = New System.Drawing.Size(30, 100)
        Me.picFragileWall5.TabIndex = 63
        Me.picFragileWall5.TabStop = False
        '
        'picFragileWall4
        '
        Me.picFragileWall4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFragileWall4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall4.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall4.Location = New System.Drawing.Point(5620, 320)
        Me.picFragileWall4.Name = "picFragileWall4"
        Me.picFragileWall4.Size = New System.Drawing.Size(30, 100)
        Me.picFragileWall4.TabIndex = 62
        Me.picFragileWall4.TabStop = False
        '
        'picExplosion6
        '
        Me.picExplosion6.BackColor = System.Drawing.Color.Transparent
        Me.picExplosion6.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.smallExplosion
        Me.picExplosion6.Location = New System.Drawing.Point(692, 220)
        Me.picExplosion6.Name = "picExplosion6"
        Me.picExplosion6.Size = New System.Drawing.Size(100, 100)
        Me.picExplosion6.TabIndex = 61
        Me.picExplosion6.TabStop = False
        Me.picExplosion6.Visible = False
        '
        'picExplosion5
        '
        Me.picExplosion5.BackColor = System.Drawing.Color.Transparent
        Me.picExplosion5.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.smallExplosion
        Me.picExplosion5.Location = New System.Drawing.Point(455, 318)
        Me.picExplosion5.Name = "picExplosion5"
        Me.picExplosion5.Size = New System.Drawing.Size(100, 100)
        Me.picExplosion5.TabIndex = 60
        Me.picExplosion5.TabStop = False
        Me.picExplosion5.Visible = False
        '
        'picExplosion2
        '
        Me.picExplosion2.BackColor = System.Drawing.Color.Transparent
        Me.picExplosion2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.smallExplosion
        Me.picExplosion2.Location = New System.Drawing.Point(427, 182)
        Me.picExplosion2.Name = "picExplosion2"
        Me.picExplosion2.Size = New System.Drawing.Size(100, 100)
        Me.picExplosion2.TabIndex = 59
        Me.picExplosion2.TabStop = False
        Me.picExplosion2.Visible = False
        '
        'picExplosion4
        '
        Me.picExplosion4.BackColor = System.Drawing.Color.Transparent
        Me.picExplosion4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.smallExplosion
        Me.picExplosion4.Location = New System.Drawing.Point(338, 288)
        Me.picExplosion4.Name = "picExplosion4"
        Me.picExplosion4.Size = New System.Drawing.Size(100, 100)
        Me.picExplosion4.TabIndex = 58
        Me.picExplosion4.TabStop = False
        Me.picExplosion4.Visible = False
        '
        'picExplosion3
        '
        Me.picExplosion3.BackColor = System.Drawing.Color.Transparent
        Me.picExplosion3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.smallExplosion
        Me.picExplosion3.Location = New System.Drawing.Point(232, 194)
        Me.picExplosion3.Name = "picExplosion3"
        Me.picExplosion3.Size = New System.Drawing.Size(100, 100)
        Me.picExplosion3.TabIndex = 57
        Me.picExplosion3.TabStop = False
        Me.picExplosion3.Visible = False
        '
        'picExplosion1
        '
        Me.picExplosion1.BackColor = System.Drawing.Color.Transparent
        Me.picExplosion1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.smallExplosion
        Me.picExplosion1.Location = New System.Drawing.Point(577, 72)
        Me.picExplosion1.Name = "picExplosion1"
        Me.picExplosion1.Size = New System.Drawing.Size(100, 100)
        Me.picExplosion1.TabIndex = 56
        Me.picExplosion1.TabStop = False
        Me.picExplosion1.Visible = False
        '
        'picEnemyBullet9
        '
        Me.picEnemyBullet9.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet9.Location = New System.Drawing.Point(1050, 415)
        Me.picEnemyBullet9.Name = "picEnemyBullet9"
        Me.picEnemyBullet9.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet9.TabIndex = 55
        Me.picEnemyBullet9.TabStop = False
        Me.picEnemyBullet9.Visible = False
        '
        'picEnemyBullet8
        '
        Me.picEnemyBullet8.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet8.Location = New System.Drawing.Point(1042, 407)
        Me.picEnemyBullet8.Name = "picEnemyBullet8"
        Me.picEnemyBullet8.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet8.TabIndex = 54
        Me.picEnemyBullet8.TabStop = False
        Me.picEnemyBullet8.Visible = False
        '
        'picEnemyBullet7
        '
        Me.picEnemyBullet7.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet7.Location = New System.Drawing.Point(1034, 399)
        Me.picEnemyBullet7.Name = "picEnemyBullet7"
        Me.picEnemyBullet7.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet7.TabIndex = 53
        Me.picEnemyBullet7.TabStop = False
        Me.picEnemyBullet7.Visible = False
        '
        'picEnemyBullet6
        '
        Me.picEnemyBullet6.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet6.Location = New System.Drawing.Point(1026, 391)
        Me.picEnemyBullet6.Name = "picEnemyBullet6"
        Me.picEnemyBullet6.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet6.TabIndex = 52
        Me.picEnemyBullet6.TabStop = False
        Me.picEnemyBullet6.Visible = False
        '
        'picEnemyBullet5
        '
        Me.picEnemyBullet5.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet5.Location = New System.Drawing.Point(1018, 383)
        Me.picEnemyBullet5.Name = "picEnemyBullet5"
        Me.picEnemyBullet5.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet5.TabIndex = 51
        Me.picEnemyBullet5.TabStop = False
        Me.picEnemyBullet5.Visible = False
        '
        'picEnemyBullet4
        '
        Me.picEnemyBullet4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet4.Location = New System.Drawing.Point(1010, 375)
        Me.picEnemyBullet4.Name = "picEnemyBullet4"
        Me.picEnemyBullet4.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet4.TabIndex = 50
        Me.picEnemyBullet4.TabStop = False
        Me.picEnemyBullet4.Visible = False
        '
        'picEnemyBullet3
        '
        Me.picEnemyBullet3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet3.Location = New System.Drawing.Point(1002, 367)
        Me.picEnemyBullet3.Name = "picEnemyBullet3"
        Me.picEnemyBullet3.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet3.TabIndex = 49
        Me.picEnemyBullet3.TabStop = False
        Me.picEnemyBullet3.Visible = False
        '
        'picEnemyBullet2
        '
        Me.picEnemyBullet2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet2.Location = New System.Drawing.Point(994, 359)
        Me.picEnemyBullet2.Name = "picEnemyBullet2"
        Me.picEnemyBullet2.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet2.TabIndex = 48
        Me.picEnemyBullet2.TabStop = False
        Me.picEnemyBullet2.Visible = False
        '
        'picEnemyBullet1
        '
        Me.picEnemyBullet1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet1.Location = New System.Drawing.Point(986, 351)
        Me.picEnemyBullet1.Name = "picEnemyBullet1"
        Me.picEnemyBullet1.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet1.TabIndex = 47
        Me.picEnemyBullet1.TabStop = False
        Me.picEnemyBullet1.Visible = False
        '
        'picEnemyBullet10
        '
        Me.picEnemyBullet10.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.enemyBullet
        Me.picEnemyBullet10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picEnemyBullet10.Location = New System.Drawing.Point(1060, 426)
        Me.picEnemyBullet10.Name = "picEnemyBullet10"
        Me.picEnemyBullet10.Size = New System.Drawing.Size(25, 5)
        Me.picEnemyBullet10.TabIndex = 46
        Me.picEnemyBullet10.TabStop = False
        Me.picEnemyBullet10.Visible = False
        '
        'picPilotHealth
        '
        Me.picPilotHealth.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picPilotHealth.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picPilotHealth.Location = New System.Drawing.Point(4805, 380)
        Me.picPilotHealth.Name = "picPilotHealth"
        Me.picPilotHealth.Size = New System.Drawing.Size(100, 10)
        Me.picPilotHealth.TabIndex = 45
        Me.picPilotHealth.TabStop = False
        '
        'picPilot
        '
        Me.picPilot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picPilot.BackColor = System.Drawing.Color.Transparent
        Me.picPilot.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.pilotStand
        Me.picPilot.Location = New System.Drawing.Point(4780, 396)
        Me.picPilot.Name = "picPilot"
        Me.picPilot.Size = New System.Drawing.Size(150, 125)
        Me.picPilot.TabIndex = 44
        Me.picPilot.TabStop = False
        '
        'picTutorialText4
        '
        Me.picTutorialText4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picTutorialText4.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.tutorialText4
        Me.picTutorialText4.Location = New System.Drawing.Point(988, 652)
        Me.picTutorialText4.Name = "picTutorialText4"
        Me.picTutorialText4.Size = New System.Drawing.Size(280, 40)
        Me.picTutorialText4.TabIndex = 43
        Me.picTutorialText4.TabStop = False
        '
        'picFloor6
        '
        Me.picFloor6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFloor6.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipFloor2
        Me.picFloor6.Image = CType(resources.GetObject("picFloor6.Image"), System.Drawing.Image)
        Me.picFloor6.Location = New System.Drawing.Point(4180, 521)
        Me.picFloor6.Name = "picFloor6"
        Me.picFloor6.Size = New System.Drawing.Size(1470, 100)
        Me.picFloor6.TabIndex = 42
        Me.picFloor6.TabStop = False
        '
        'picWall4
        '
        Me.picWall4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picWall4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall2
        Me.picWall4.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall1
        Me.picWall4.Location = New System.Drawing.Point(4180, 621)
        Me.picWall4.Name = "picWall4"
        Me.picWall4.Size = New System.Drawing.Size(1470, 200)
        Me.picWall4.TabIndex = 41
        Me.picWall4.TabStop = False
        '
        'picFragileWall3
        '
        Me.picFragileWall3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFragileWall3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall3.Location = New System.Drawing.Point(1250, 554)
        Me.picFragileWall3.Name = "picFragileWall3"
        Me.picFragileWall3.Size = New System.Drawing.Size(30, 67)
        Me.picFragileWall3.TabIndex = 28
        Me.picFragileWall3.TabStop = False
        '
        'picFragileWall2
        '
        Me.picFragileWall2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFragileWall2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall2.Location = New System.Drawing.Point(1250, 487)
        Me.picFragileWall2.Name = "picFragileWall2"
        Me.picFragileWall2.Size = New System.Drawing.Size(30, 67)
        Me.picFragileWall2.TabIndex = 27
        Me.picFragileWall2.TabStop = False
        '
        'picFragileWall1
        '
        Me.picFragileWall1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFragileWall1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.fragileWall
        Me.picFragileWall1.Location = New System.Drawing.Point(1250, 420)
        Me.picFragileWall1.Name = "picFragileWall1"
        Me.picFragileWall1.Size = New System.Drawing.Size(30, 67)
        Me.picFragileWall1.TabIndex = 25
        Me.picFragileWall1.TabStop = False
        '
        'picDefAlienHealth2
        '
        Me.picDefAlienHealth2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDefAlienHealth2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picDefAlienHealth2.Location = New System.Drawing.Point(1708, 380)
        Me.picDefAlienHealth2.Name = "picDefAlienHealth2"
        Me.picDefAlienHealth2.Size = New System.Drawing.Size(100, 10)
        Me.picDefAlienHealth2.TabIndex = 40
        Me.picDefAlienHealth2.TabStop = False
        '
        'picDefAlien2
        '
        Me.picDefAlien2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDefAlien2.BackColor = System.Drawing.Color.Transparent
        Me.picDefAlien2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.defAlienStandLeft
        Me.picDefAlien2.Location = New System.Drawing.Point(1683, 396)
        Me.picDefAlien2.Name = "picDefAlien2"
        Me.picDefAlien2.Size = New System.Drawing.Size(150, 125)
        Me.picDefAlien2.TabIndex = 39
        Me.picDefAlien2.TabStop = False
        '
        'picTalkBox
        '
        Me.picTalkBox.BackColor = System.Drawing.Color.Transparent
        Me.picTalkBox.Location = New System.Drawing.Point(12, 12)
        Me.picTalkBox.Name = "picTalkBox"
        Me.picTalkBox.Size = New System.Drawing.Size(400, 100)
        Me.picTalkBox.TabIndex = 38
        Me.picTalkBox.TabStop = False
        Me.picTalkBox.Visible = False
        '
        'picTutorialText3
        '
        Me.picTutorialText3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picTutorialText3.BackColor = System.Drawing.Color.Transparent
        Me.picTutorialText3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.tutorialText3
        Me.picTutorialText3.Location = New System.Drawing.Point(1470, 220)
        Me.picTutorialText3.Name = "picTutorialText3"
        Me.picTutorialText3.Size = New System.Drawing.Size(364, 70)
        Me.picTutorialText3.TabIndex = 37
        Me.picTutorialText3.TabStop = False
        '
        'picWall3
        '
        Me.picWall3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picWall3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall2
        Me.picWall3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall1
        Me.picWall3.Location = New System.Drawing.Point(2310, 621)
        Me.picWall3.Name = "picWall3"
        Me.picWall3.Size = New System.Drawing.Size(1470, 100)
        Me.picWall3.TabIndex = 36
        Me.picWall3.TabStop = False
        '
        'picFloor5
        '
        Me.picFloor5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFloor5.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipFloor2
        Me.picFloor5.Image = CType(resources.GetObject("picFloor5.Image"), System.Drawing.Image)
        Me.picFloor5.Location = New System.Drawing.Point(2310, 521)
        Me.picFloor5.Name = "picFloor5"
        Me.picFloor5.Size = New System.Drawing.Size(1470, 100)
        Me.picFloor5.TabIndex = 35
        Me.picFloor5.TabStop = False
        '
        'picCorner1
        '
        Me.picCorner1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCorner1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.corner
        Me.picCorner1.Location = New System.Drawing.Point(1370, 320)
        Me.picCorner1.Name = "picCorner1"
        Me.picCorner1.Size = New System.Drawing.Size(100, 100)
        Me.picCorner1.TabIndex = 34
        Me.picCorner1.TabStop = False
        '
        'picWall2
        '
        Me.picWall2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picWall2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall2
        Me.picWall2.Location = New System.Drawing.Point(1470, 0)
        Me.picWall2.Name = "picWall2"
        Me.picWall2.Size = New System.Drawing.Size(4180, 124)
        Me.picWall2.TabIndex = 33
        Me.picWall2.TabStop = False
        '
        'picCeiling2
        '
        Me.picCeiling2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCeiling2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipCeiling
        Me.picCeiling2.Location = New System.Drawing.Point(1470, 120)
        Me.picCeiling2.Name = "picCeiling2"
        Me.picCeiling2.Size = New System.Drawing.Size(4180, 100)
        Me.picCeiling2.TabIndex = 32
        Me.picCeiling2.TabStop = False
        '
        'picWallPanel1
        '
        Me.picWallPanel1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall1
        Me.picWallPanel1.Location = New System.Drawing.Point(371, 214)
        Me.picWallPanel1.Name = "picWallPanel1"
        Me.picWallPanel1.Size = New System.Drawing.Size(210, 100)
        Me.picWallPanel1.TabIndex = 31
        Me.picWallPanel1.TabStop = False
        '
        'picTutorialText2
        '
        Me.picTutorialText2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.tutorialText2
        Me.picTutorialText2.Location = New System.Drawing.Point(1010, 194)
        Me.picTutorialText2.Name = "picTutorialText2"
        Me.picTutorialText2.Size = New System.Drawing.Size(258, 120)
        Me.picTutorialText2.TabIndex = 29
        Me.picTutorialText2.TabStop = False
        '
        'picTutorialText1
        '
        Me.picTutorialText1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.tutorialText1
        Me.picTutorialText1.Location = New System.Drawing.Point(12, 194)
        Me.picTutorialText1.Name = "picTutorialText1"
        Me.picTutorialText1.Size = New System.Drawing.Size(300, 120)
        Me.picTutorialText1.TabIndex = 24
        Me.picTutorialText1.TabStop = False
        '
        'picBullet10
        '
        Me.picBullet10.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet10.Location = New System.Drawing.Point(692, 422)
        Me.picBullet10.Name = "picBullet10"
        Me.picBullet10.Size = New System.Drawing.Size(25, 5)
        Me.picBullet10.TabIndex = 21
        Me.picBullet10.TabStop = False
        Me.picBullet10.Visible = False
        '
        'picBullet8
        '
        Me.picBullet8.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet8.Location = New System.Drawing.Point(684, 414)
        Me.picBullet8.Name = "picBullet8"
        Me.picBullet8.Size = New System.Drawing.Size(25, 5)
        Me.picBullet8.TabIndex = 20
        Me.picBullet8.TabStop = False
        Me.picBullet8.Visible = False
        '
        'picBullet9
        '
        Me.picBullet9.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet9.Location = New System.Drawing.Point(676, 406)
        Me.picBullet9.Name = "picBullet9"
        Me.picBullet9.Size = New System.Drawing.Size(25, 5)
        Me.picBullet9.TabIndex = 19
        Me.picBullet9.TabStop = False
        Me.picBullet9.Visible = False
        '
        'picBullet7
        '
        Me.picBullet7.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet7.Location = New System.Drawing.Point(668, 398)
        Me.picBullet7.Name = "picBullet7"
        Me.picBullet7.Size = New System.Drawing.Size(25, 5)
        Me.picBullet7.TabIndex = 18
        Me.picBullet7.TabStop = False
        Me.picBullet7.Visible = False
        '
        'picBullet6
        '
        Me.picBullet6.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet6.Location = New System.Drawing.Point(660, 390)
        Me.picBullet6.Name = "picBullet6"
        Me.picBullet6.Size = New System.Drawing.Size(25, 5)
        Me.picBullet6.TabIndex = 17
        Me.picBullet6.TabStop = False
        Me.picBullet6.Visible = False
        '
        'picBullet5
        '
        Me.picBullet5.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet5.Location = New System.Drawing.Point(652, 382)
        Me.picBullet5.Name = "picBullet5"
        Me.picBullet5.Size = New System.Drawing.Size(25, 5)
        Me.picBullet5.TabIndex = 16
        Me.picBullet5.TabStop = False
        Me.picBullet5.Visible = False
        '
        'picBullet4
        '
        Me.picBullet4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet4.Location = New System.Drawing.Point(644, 374)
        Me.picBullet4.Name = "picBullet4"
        Me.picBullet4.Size = New System.Drawing.Size(25, 5)
        Me.picBullet4.TabIndex = 15
        Me.picBullet4.TabStop = False
        Me.picBullet4.Visible = False
        '
        'picBullet3
        '
        Me.picBullet3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet3.Location = New System.Drawing.Point(636, 366)
        Me.picBullet3.Name = "picBullet3"
        Me.picBullet3.Size = New System.Drawing.Size(25, 5)
        Me.picBullet3.TabIndex = 14
        Me.picBullet3.TabStop = False
        Me.picBullet3.Visible = False
        '
        'picBullet2
        '
        Me.picBullet2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet2.Location = New System.Drawing.Point(628, 358)
        Me.picBullet2.Name = "picBullet2"
        Me.picBullet2.Size = New System.Drawing.Size(25, 5)
        Me.picBullet2.TabIndex = 13
        Me.picBullet2.TabStop = False
        Me.picBullet2.Visible = False
        '
        'picBullet1
        '
        Me.picBullet1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet1.Location = New System.Drawing.Point(702, 433)
        Me.picBullet1.Name = "picBullet1"
        Me.picBullet1.Size = New System.Drawing.Size(25, 5)
        Me.picBullet1.TabIndex = 12
        Me.picBullet1.TabStop = False
        Me.picBullet1.Visible = False
        '
        'picDefAlienHealth1
        '
        Me.picDefAlienHealth1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDefAlienHealth1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picDefAlienHealth1.Location = New System.Drawing.Point(1368, 478)
        Me.picDefAlienHealth1.Name = "picDefAlienHealth1"
        Me.picDefAlienHealth1.Size = New System.Drawing.Size(100, 10)
        Me.picDefAlienHealth1.TabIndex = 11
        Me.picDefAlienHealth1.TabStop = False
        '
        'picSpikeballHealth
        '
        Me.picSpikeballHealth.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picSpikeballHealth.Location = New System.Drawing.Point(50, 463)
        Me.picSpikeballHealth.Name = "picSpikeballHealth"
        Me.picSpikeballHealth.Size = New System.Drawing.Size(100, 10)
        Me.picSpikeballHealth.TabIndex = 10
        Me.picSpikeballHealth.TabStop = False
        '
        'picFloor4
        '
        Me.picFloor4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFloor4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipFloor2
        Me.picFloor4.Image = CType(resources.GetObject("picFloor4.Image"), System.Drawing.Image)
        Me.picFloor4.Location = New System.Drawing.Point(840, 621)
        Me.picFloor4.Name = "picFloor4"
        Me.picFloor4.Size = New System.Drawing.Size(1470, 100)
        Me.picFloor4.TabIndex = 9
        Me.picFloor4.TabStop = False
        '
        'picFloor3
        '
        Me.picFloor3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFloor3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipFloor
        Me.picFloor3.Location = New System.Drawing.Point(630, 621)
        Me.picFloor3.Name = "picFloor3"
        Me.picFloor3.Size = New System.Drawing.Size(210, 100)
        Me.picFloor3.TabIndex = 8
        Me.picFloor3.TabStop = False
        '
        'picFloor2
        '
        Me.picFloor2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFloor2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipFloor2
        Me.picFloor2.Image = CType(resources.GetObject("picFloor2.Image"), System.Drawing.Image)
        Me.picFloor2.Location = New System.Drawing.Point(210, 621)
        Me.picFloor2.Name = "picFloor2"
        Me.picFloor2.Size = New System.Drawing.Size(425, 100)
        Me.picFloor2.TabIndex = 6
        Me.picFloor2.TabStop = False
        '
        'picFloor1
        '
        Me.picFloor1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picFloor1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipFloor
        Me.picFloor1.Location = New System.Drawing.Point(0, 621)
        Me.picFloor1.Name = "picFloor1"
        Me.picFloor1.Size = New System.Drawing.Size(210, 100)
        Me.picFloor1.TabIndex = 5
        Me.picFloor1.TabStop = False
        '
        'picDefAlien1
        '
        Me.picDefAlien1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDefAlien1.BackColor = System.Drawing.Color.Transparent
        Me.picDefAlien1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.defAlienStandLeft
        Me.picDefAlien1.Location = New System.Drawing.Point(1343, 494)
        Me.picDefAlien1.Name = "picDefAlien1"
        Me.picDefAlien1.Size = New System.Drawing.Size(150, 125)
        Me.picDefAlien1.TabIndex = 4
        Me.picDefAlien1.TabStop = False
        '
        'picSpikeball
        '
        Me.picSpikeball.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSpikeball.BackColor = System.Drawing.Color.Transparent
        Me.picSpikeball.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.spikeballStandRight
        Me.picSpikeball.Location = New System.Drawing.Point(38, 479)
        Me.picSpikeball.Name = "picSpikeball"
        Me.picSpikeball.Size = New System.Drawing.Size(125, 125)
        Me.picSpikeball.TabIndex = 2
        Me.picSpikeball.TabStop = False
        '
        'picCeiling1
        '
        Me.picCeiling1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCeiling1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipCeiling
        Me.picCeiling1.Location = New System.Drawing.Point(0, 320)
        Me.picCeiling1.Name = "picCeiling1"
        Me.picCeiling1.Size = New System.Drawing.Size(1370, 100)
        Me.picCeiling1.TabIndex = 22
        Me.picCeiling1.TabStop = False
        '
        'picWall1
        '
        Me.picWall1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picWall1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.starshipWall2
        Me.picWall1.Location = New System.Drawing.Point(0, 0)
        Me.picWall1.Name = "picWall1"
        Me.picWall1.Size = New System.Drawing.Size(1470, 324)
        Me.picWall1.TabIndex = 23
        Me.picWall1.TabStop = False
        '
        'picAlarm
        '
        Me.picAlarm.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picAlarm.BackColor = System.Drawing.Color.Transparent
        Me.picAlarm.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.alarmSilent
        Me.picAlarm.Location = New System.Drawing.Point(1470, 320)
        Me.picAlarm.Name = "picAlarm"
        Me.picAlarm.Size = New System.Drawing.Size(100, 100)
        Me.picAlarm.TabIndex = 30
        Me.picAlarm.TabStop = False
        '
        'lblAmmo
        '
        Me.lblAmmo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblAmmo.BackColor = System.Drawing.Color.Transparent
        Me.lblAmmo.Font = New System.Drawing.Font("Perpetua Titling MT", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAmmo.ForeColor = System.Drawing.Color.White
        Me.lblAmmo.Location = New System.Drawing.Point(1136, 640)
        Me.lblAmmo.Name = "lblAmmo"
        Me.lblAmmo.Size = New System.Drawing.Size(132, 42)
        Me.lblAmmo.TabIndex = 69
        Me.lblAmmo.Text = "10 | 40"
        Me.lblAmmo.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblGunType
        '
        Me.lblGunType.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGunType.BackColor = System.Drawing.Color.Transparent
        Me.lblGunType.Font = New System.Drawing.Font("Perpetua Titling MT", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGunType.ForeColor = System.Drawing.Color.White
        Me.lblGunType.Location = New System.Drawing.Point(1136, 682)
        Me.lblGunType.Name = "lblGunType"
        Me.lblGunType.Size = New System.Drawing.Size(132, 29)
        Me.lblGunType.TabIndex = 68
        Me.lblGunType.Text = "BLASTER"
        Me.lblGunType.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblLives
        '
        Me.lblLives.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblLives.AutoSize = True
        Me.lblLives.BackColor = System.Drawing.Color.Transparent
        Me.lblLives.Font = New System.Drawing.Font("Perpetua Titling MT", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLives.ForeColor = System.Drawing.Color.White
        Me.lblLives.Location = New System.Drawing.Point(62, 672)
        Me.lblLives.Name = "lblLives"
        Me.lblLives.Size = New System.Drawing.Size(174, 29)
        Me.lblLives.TabIndex = 67
        Me.lblLives.Text = "Spikeball: 5"
        '
        'picLifeIcon
        '
        Me.picLifeIcon.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picLifeIcon.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.spikeballIcon
        Me.picLifeIcon.Location = New System.Drawing.Point(12, 664)
        Me.picLifeIcon.Name = "picLifeIcon"
        Me.picLifeIcon.Size = New System.Drawing.Size(44, 44)
        Me.picLifeIcon.TabIndex = 66
        Me.picLifeIcon.TabStop = False
        '
        'frmGame
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.lblAmmo)
        Me.Controls.Add(Me.lblGunType)
        Me.Controls.Add(Me.lblLives)
        Me.Controls.Add(Me.picLifeIcon)
        Me.Controls.Add(Me.picFragileWall6)
        Me.Controls.Add(Me.picFragileWall5)
        Me.Controls.Add(Me.picFragileWall4)
        Me.Controls.Add(Me.picExplosion6)
        Me.Controls.Add(Me.picExplosion5)
        Me.Controls.Add(Me.picExplosion2)
        Me.Controls.Add(Me.picExplosion4)
        Me.Controls.Add(Me.picExplosion3)
        Me.Controls.Add(Me.picExplosion1)
        Me.Controls.Add(Me.picEnemyBullet9)
        Me.Controls.Add(Me.picEnemyBullet8)
        Me.Controls.Add(Me.picEnemyBullet7)
        Me.Controls.Add(Me.picEnemyBullet6)
        Me.Controls.Add(Me.picEnemyBullet5)
        Me.Controls.Add(Me.picEnemyBullet4)
        Me.Controls.Add(Me.picEnemyBullet3)
        Me.Controls.Add(Me.picEnemyBullet2)
        Me.Controls.Add(Me.picEnemyBullet1)
        Me.Controls.Add(Me.picEnemyBullet10)
        Me.Controls.Add(Me.picPilotHealth)
        Me.Controls.Add(Me.picPilot)
        Me.Controls.Add(Me.picTutorialText4)
        Me.Controls.Add(Me.picFloor6)
        Me.Controls.Add(Me.picWall4)
        Me.Controls.Add(Me.picFragileWall3)
        Me.Controls.Add(Me.picFragileWall2)
        Me.Controls.Add(Me.picFragileWall1)
        Me.Controls.Add(Me.picDefAlienHealth2)
        Me.Controls.Add(Me.picDefAlien2)
        Me.Controls.Add(Me.picTalkBox)
        Me.Controls.Add(Me.picTutorialText3)
        Me.Controls.Add(Me.picWall3)
        Me.Controls.Add(Me.picFloor5)
        Me.Controls.Add(Me.picCorner1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.picWall2)
        Me.Controls.Add(Me.picCeiling2)
        Me.Controls.Add(Me.picWallPanel1)
        Me.Controls.Add(Me.picTutorialText2)
        Me.Controls.Add(Me.picTutorialText1)
        Me.Controls.Add(Me.picBullet10)
        Me.Controls.Add(Me.picBullet8)
        Me.Controls.Add(Me.picBullet9)
        Me.Controls.Add(Me.picBullet7)
        Me.Controls.Add(Me.picBullet6)
        Me.Controls.Add(Me.picBullet5)
        Me.Controls.Add(Me.picBullet4)
        Me.Controls.Add(Me.picBullet3)
        Me.Controls.Add(Me.picBullet2)
        Me.Controls.Add(Me.picBullet1)
        Me.Controls.Add(Me.picDefAlienHealth1)
        Me.Controls.Add(Me.picSpikeballHealth)
        Me.Controls.Add(Me.picFloor4)
        Me.Controls.Add(Me.picFloor3)
        Me.Controls.Add(Me.picFloor2)
        Me.Controls.Add(Me.picFloor1)
        Me.Controls.Add(Me.picDefAlien1)
        Me.Controls.Add(Me.picSpikeball)
        Me.Controls.Add(Me.picCeiling1)
        Me.Controls.Add(Me.picWall1)
        Me.Controls.Add(Me.picAlarm)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "frmGame"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Spikeball's Alien Blaster"
        Me.TransparencyKey = System.Drawing.Color.Salmon
        CType(Me.picFragileWall6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFragileWall5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFragileWall4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExplosion6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExplosion5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExplosion2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExplosion4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExplosion3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picExplosion1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEnemyBullet10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPilotHealth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPilot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTutorialText4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFloor6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWall4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFragileWall3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFragileWall2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFragileWall1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDefAlienHealth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDefAlien2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTalkBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTutorialText3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWall3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFloor5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCorner1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWall2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCeiling2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWallPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTutorialText2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTutorialText1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDefAlienHealth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSpikeballHealth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFloor4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFloor3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFloor2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFloor1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDefAlien1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSpikeball, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCeiling1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWall1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAlarm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLifeIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents picSpikeball As System.Windows.Forms.PictureBox
    Friend WithEvents tmrGameTick As System.Windows.Forms.Timer
    Friend WithEvents picDefAlien1 As System.Windows.Forms.PictureBox
    Friend WithEvents picFloor1 As System.Windows.Forms.PictureBox
    Friend WithEvents picFloor2 As System.Windows.Forms.PictureBox
    Friend WithEvents picFloor3 As System.Windows.Forms.PictureBox
    Friend WithEvents picFloor4 As System.Windows.Forms.PictureBox
    Friend WithEvents picSpikeballHealth As System.Windows.Forms.PictureBox
    Friend WithEvents picDefAlienHealth1 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet1 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet2 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet3 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet4 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet5 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet6 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet7 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet9 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet8 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet10 As System.Windows.Forms.PictureBox
    Friend WithEvents picCeiling1 As System.Windows.Forms.PictureBox
    Friend WithEvents picWall1 As System.Windows.Forms.PictureBox
    Friend WithEvents picTutorialText1 As System.Windows.Forms.PictureBox
    Friend WithEvents picFragileWall1 As System.Windows.Forms.PictureBox
    Friend WithEvents picFragileWall2 As System.Windows.Forms.PictureBox
    Friend WithEvents picFragileWall3 As System.Windows.Forms.PictureBox
    Friend WithEvents picTutorialText2 As System.Windows.Forms.PictureBox
    Friend WithEvents picAlarm As System.Windows.Forms.PictureBox
    Friend WithEvents picWallPanel1 As System.Windows.Forms.PictureBox
    Friend WithEvents picCeiling2 As System.Windows.Forms.PictureBox
    Friend WithEvents picWall2 As System.Windows.Forms.PictureBox
    Friend WithEvents picCorner1 As System.Windows.Forms.PictureBox
    Friend WithEvents picFloor5 As System.Windows.Forms.PictureBox
    Friend WithEvents picWall3 As System.Windows.Forms.PictureBox
    Friend WithEvents picTutorialText3 As System.Windows.Forms.PictureBox
    Friend WithEvents picTalkBox As System.Windows.Forms.PictureBox
    Friend WithEvents picDefAlien2 As System.Windows.Forms.PictureBox
    Friend WithEvents picDefAlienHealth2 As System.Windows.Forms.PictureBox
    Friend WithEvents picWall4 As System.Windows.Forms.PictureBox
    Friend WithEvents picFloor6 As System.Windows.Forms.PictureBox
    Friend WithEvents picTutorialText4 As System.Windows.Forms.PictureBox
    Friend WithEvents picPilot As System.Windows.Forms.PictureBox
    Friend WithEvents picPilotHealth As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet9 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet8 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet7 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet6 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet5 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet4 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet3 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet2 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet1 As System.Windows.Forms.PictureBox
    Friend WithEvents picEnemyBullet10 As System.Windows.Forms.PictureBox
    Friend WithEvents picExplosion1 As System.Windows.Forms.PictureBox
    Friend WithEvents picExplosion3 As System.Windows.Forms.PictureBox
    Friend WithEvents picExplosion4 As System.Windows.Forms.PictureBox
    Friend WithEvents picExplosion2 As System.Windows.Forms.PictureBox
    Friend WithEvents picExplosion5 As System.Windows.Forms.PictureBox
    Friend WithEvents picExplosion6 As System.Windows.Forms.PictureBox
    Friend WithEvents picFragileWall5 As System.Windows.Forms.PictureBox
    Friend WithEvents picFragileWall4 As System.Windows.Forms.PictureBox
    Friend WithEvents picFragileWall6 As System.Windows.Forms.PictureBox
    Friend WithEvents lblAmmo As System.Windows.Forms.Label
    Friend WithEvents lblGunType As System.Windows.Forms.Label
    Friend WithEvents lblLives As System.Windows.Forms.Label
    Friend WithEvents picLifeIcon As System.Windows.Forms.PictureBox
End Class
