﻿Public Class Bullet
    Public Shared Function shoot()
        'Check if the player has no ammo:
        If GameData.ammo > 0 And GameData.activeAmmo = 0 And Not GameData.reloading And GameData.activeAmmo < 5 Then
            GameData.reloading = True
            GameData.reloadingTimer = 30
        End If

        'If the player is reloading lower the countdown until the timer runs out; then fix the ammo:
        If GameData.reloadingTimer > 0 Then
            GameData.leftKey = False
            GameData.rightKey = False
            If Not GameData.jumping And Not GameData.falling Then
                GameData.speed = 0
            Else
                GameData.speed /= 2
            End If
            If Not GameData.graphic = "reload" Then
                If GameData.direction = "left" Then
                    GameData.spikeball.Image = My.Resources.spikeballReloadLeft
                Else
                    GameData.spikeball.Image = My.Resources.spikeballReloadRight
                End If
                GameData.graphic = "reload"
            End If
            GameData.reloadingTimer -= 1
            If GameData.reloadingTimer = 0 Then
                GameData.reloading = False
                If GameData.ammo < 5 Then
                    GameData.activeAmmo = GameData.ammo
                    GameData.ammo = 0
                    If GameData.activeAmmo > 0 Then
                        If GameData.ammo < 5 - GameData.activeAmmo Then
                            GameData.activeAmmo += GameData.ammo
                            GameData.ammo = 0
                        Else
                            GameData.ammo -= 5 - GameData.activeAmmo
                            GameData.activeAmmo += 5 - GameData.activeAmmo
                        End If
                    End If
                ElseIf GameData.activeAmmo > 0 Then
                    GameData.ammo -= 5 - GameData.activeAmmo
                    GameData.activeAmmo += 5 - GameData.activeAmmo
                Else
                    GameData.activeAmmo = 5
                    GameData.ammo -= 5
                End If
                GameData.ammoLabel.Text = GameData.activeAmmo & " | " & GameData.ammo
            End If
        End If

        'If the bullet cooldown is greater than 0 lower it:
        If GameData.shootCooldown > 0 Then
            GameData.shootCooldown -= 1
        End If

        'Make all active bullets move:
        For i = 0 To 9
            'Fire every player bullet.
            If GameData.bulletFiring(i) Then
                If GameData.bulletDirection(i) = "right" Then
                    GameData.bullet(i).Left += 40
                Else
                    GameData.bullet(i).Left -= 40
                End If
                If GameData.bullet(i).Left > frmTerraLevel1.Width - GameData.bullet(i).Width Or GameData.bullet(i).Left < 0 Or anyWall(GameData.bullet(i)) Then
                    GameData.bulletFiring(i) = False
                    GameData.bullet(i).Visible = False
                End If
                For x = 0 To GameData.aliens.Length - 1
                    If GameData.aliens(x).Bounds.IntersectsWith(GameData.bullet(i).Bounds) And Not GameData.enemyDead(x) Then
                        DefaultAlien.hurt(20, x)
                        GameData.bulletFiring(i) = False
                        GameData.bullet(i).Visible = False
                    End If
                Next
                For x = 0 To GameData.bludgeon.Length - 1
                    If GameData.bludgeon(x).Bounds.IntersectsWith(GameData.bullet(i).Bounds) And Not GameData.bludgeonDead(x) Then
                        Bludgeon.hurt(20, x)
                        GameData.bulletFiring(i) = False
                        GameData.bullet(i).Visible = False
                    End If
                Next
            End If
            'Fire every enemy bullet.
            If GameData.enemyBulletFiring(i) Then
                GameData.enemyBullet(i).Left -= 40
                If GameData.enemyBullet(i).Left > frmTerraLevel1.Width - GameData.enemyBullet(i).Width Or GameData.enemyBullet(i).Left < 0 Or anyWall(GameData.enemyBullet(i)) Then
                    GameData.enemyBulletFiring(i) = False
                    GameData.enemyBullet(i).Visible = False
                End If
                If GameData.enemyBullet(i).Bounds.IntersectsWith(GameData.spikeball.Bounds) Then
                    Spikeball.hurt(0.5)
                    GameData.enemyBulletFiring(i) = False
                    GameData.enemyBullet(i).Visible = False
                End If
            End If
        Next
        GameData.ammoLabel.Text = GameData.activeAmmo & " | " & GameData.ammo
        Return True
    End Function
    'Boolean method for if an entity is touching the wall:
    Public Shared Function touchingWall(ByVal wallName, ByVal character)
        If character.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function
    'Boolean method for if an entity is touching any wall:
    Public Shared Function anyWall(ByVal character)
        For i = 0 To GameData.terrain.Length - 1
            If touchingWall(GameData.terrain(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
End Class
