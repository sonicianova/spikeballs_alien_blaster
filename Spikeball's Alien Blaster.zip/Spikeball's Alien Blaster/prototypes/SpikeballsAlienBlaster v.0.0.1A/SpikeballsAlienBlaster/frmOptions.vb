﻿Public Class frmOptions

    'Load settings:
    Dim fullscreen As Boolean = My.Settings.fullscreen
    Dim resHeight As Integer = My.Settings.resHeight
    Dim resWidth As Integer = My.Settings.resWidth

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        'If the settings are not saved warn the user:
        If Not fullscreen = My.Settings.fullscreen Or Not resHeight = My.Settings.resHeight Or Not resWidth = My.Settings.resWidth Then
            If MessageBox.Show("Your settings are not saved. Do you still want to go back?", "Warning!", MessageBoxButtons.OKCancel) = Windows.Forms.DialogResult.OK Then
                frmMainMenu.Show()
                Me.Close()
            End If
        Else
            frmMainMenu.Show()
            Me.Close()
        End If
    End Sub

    Private Sub btnFullscreen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFullscreen.Click
        'Change the fullscreen setting:
        If fullscreen Then
            btnFullscreen.Text = "WINDOWED"
            fullscreen = False
        Else
            btnFullscreen.Text = "FULLSCREEN"
            fullscreen = True
        End If
    End Sub

    Private Sub btnResolution_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResolution.Click
        'Change the resolution setting:
        If resWidth = 1280 Then
            btnResolution.Text = "RESOLUTION   1600x900"
            resHeight = 900
            resWidth = 1600
        ElseIf resWidth = 1600 Then
            btnResolution.Text = "RESOLUTION   1920x1080"
            resHeight = 1080
            resWidth = 1900
        ElseIf resWidth = 1900 Then
            btnResolution.Text = "RESOLUTION   1280x720"
            resHeight = 720
            resWidth = 1280
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        'Save and apply all changed settings:
        My.Settings.fullscreen = fullscreen
        My.Settings.resHeight = resHeight
        My.Settings.resWidth = resWidth
        My.Settings.Save()

        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2
    End Sub

    Private Sub frmOptions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Set button names:
        If fullscreen Then
            btnFullscreen.Text = "FULLSCREEN"
            Me.WindowState = FormWindowState.Maximized
        Else
            btnFullscreen.Text = "WINDOWED"
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2

        If resWidth = 1280 Then
            btnResolution.Text = "RESOLUTION   1280x720"
        ElseIf resWidth = 1600 Then
            btnResolution.Text = "RESOLUTION   1600x900"
        ElseIf resWidth = 1900 Then
            btnResolution.Text = "RESOLUTION   1920x1080"
        End If
    End Sub
End Class