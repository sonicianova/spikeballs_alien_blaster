﻿Public Class Camera
    Public Shared Function cameraUse()
        Dim width As Integer
        Select Case GameData.form
            Case "tutorial"
                width = frmGame.Width
            Case "level 1"
                width = frmTerraLevel1.Width
        End Select
        'Camera movement:
        If GameData.spikeball.Left > width * 0.6 And GameData.direction = "right" And (GameData.rightKey Or GameData.rolling) Then
            'If the player moves to the right of the center it will move the camera with the player
            'to the right, moving the entire level to the left.
            GameData.cameraMoving = True
            GameData.xPos += GameData.speed
        ElseIf frmTerraTerrain1.picGrass1.Left >= 0 And frmGame.picFloor1.Left >= 0 Then
            'This locks the camera so it cannot go left of the start point.
            GameData.speedRollMod = 2
            frmTerraTerrain1.picGrass1.Left = 0
            frmTerraTerrain1.picDirt1.Left = 0
            frmTerraTerrain1.picSlope1.Left = 1500
            frmTerraTerrain1.picBigBox1.Left = 0
            frmTerraTerrain1.picSmallBox1.Left = 0
            frmTerraTerrain1.picDirt2.Left = 1500
            frmTerraTerrain1.picGrass2.Left = 1750
            frmTerraTerrain1.picGrassCap1.Left = 3250
            frmTerraTerrain1.picGrass3.Left = 3362
            frmTerraTerrain1.picDirt3.Left = 3362
            frmTerraTerrain1.picSmallBox2.Left = 3362
            GameData.cameraMoving = False
        ElseIf GameData.spikeball.Left < width * 0.4 And GameData.direction = "left" And (GameData.leftKey Or GameData.rolling) Then
            'If the player moves to the left of the center it will move the camera with the player
            'to the left, moving the entire level to the right.
            GameData.cameraMoving = True
            GameData.xPos += GameData.speed
        ElseIf Not GameData.leftKey And Not GameData.rightKey And Not GameData.rolling And Not GameData.downKey And Not GameData.speed = 0 Then
            GameData.cameraMoving = True
            GameData.xPos += GameData.speed
        Else
            'If the player is not moving stop the camera movement.
            GameData.cameraMoving = False
        End If

        If GameData.cameraMoving Then
            If GameData.rolling Then
                moveLevel(GameData.speed * 2)
            Else
                moveLevel(GameData.speed)
            End If
        ElseIf ((GameData.direction = "left" And GameData.spikeball.Left > 0) Or GameData.direction = "right") Then
            Spikeball.move()
        End If
        Return True
    End Function

    'Move the level elements according to speed:
    Public Shared Function moveLevel(ByVal distance)
        If GameData.direction = "right" Then
            For i = GameData.terrain.Length - 1 To 0 Step -1
                GameData.terrain(i).Left -= distance
            Next
        Else
            For i = 0 To GameData.terrain.Length - 1
                GameData.terrain(i).Left -= distance
            Next
        End If
        For i = 0 To GameData.aliens.Length - 1
            GameData.enemyMovement(i) -= distance
        Next
        For i = 0 To 9
            GameData.bullet(i).Left -= distance
        Next
        For i = 0 To GameData.slopes.Length - 1
            GameData.slopes(i).Left -= distance
        Next
        For i = 0 To GameData.grass.Length - 1
            GameData.grass(i).Left -= distance
        Next
        For i = 0 To GameData.medkit.Length - 1
            GameData.medkit(i).Left -= distance
        Next
        For i = 0 To GameData.coin.Length - 1
            GameData.coin(i).Left -= distance
        Next
        For i = 0 To GameData.ammoBox.Length - 1
            GameData.ammoBox(i).Left -= distance
        Next
        For i = 0 To GameData.platforms.Length - 1
            GameData.platforms(i).Left -= distance
        Next
        For i = 0 To GameData.bludgeon.Length - 1
            GameData.bludgeon(i).Left -= distance
            GameData.bludgeonHealthBar(i).Left -= distance
            GameData.bombs(i).Left -= distance
        Next
        frmTerraBackground1.picBackground1.Left -= distance / 4
        frmTerraBackground1.picBackground2.Left -= distance / 4
        Return True
    End Function
End Class
