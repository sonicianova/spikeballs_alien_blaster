﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBackground
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picPlanet = New System.Windows.Forms.PictureBox
        Me.picTerraMinimapIcon = New System.Windows.Forms.PictureBox
        CType(Me.picPlanet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTerraMinimapIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picPlanet
        '
        Me.picPlanet.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picPlanet.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.Level1Act1
        Me.picPlanet.Location = New System.Drawing.Point(430, 150)
        Me.picPlanet.Name = "picPlanet"
        Me.picPlanet.Size = New System.Drawing.Size(420, 420)
        Me.picPlanet.TabIndex = 9
        Me.picPlanet.TabStop = False
        Me.picPlanet.Visible = False
        '
        'picTerraMinimapIcon
        '
        Me.picTerraMinimapIcon.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.TerraMinimapIcon
        Me.picTerraMinimapIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picTerraMinimapIcon.Location = New System.Drawing.Point(119, 403)
        Me.picTerraMinimapIcon.Name = "picTerraMinimapIcon"
        Me.picTerraMinimapIcon.Size = New System.Drawing.Size(140, 182)
        Me.picTerraMinimapIcon.TabIndex = 7
        Me.picTerraMinimapIcon.TabStop = False
        '
        'frmBackground
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.picPlanet)
        Me.Controls.Add(Me.picTerraMinimapIcon)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmBackground"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Spikeball's Alien Blaster"
        CType(Me.picPlanet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTerraMinimapIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picTerraMinimapIcon As System.Windows.Forms.PictureBox
    Friend WithEvents picPlanet As System.Windows.Forms.PictureBox
End Class
