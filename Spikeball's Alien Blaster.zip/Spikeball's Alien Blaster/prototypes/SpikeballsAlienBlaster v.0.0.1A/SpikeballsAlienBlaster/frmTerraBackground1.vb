﻿Public Class frmTerraBackground1

    Private Sub frmTerraBackground1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2
    End Sub
End Class