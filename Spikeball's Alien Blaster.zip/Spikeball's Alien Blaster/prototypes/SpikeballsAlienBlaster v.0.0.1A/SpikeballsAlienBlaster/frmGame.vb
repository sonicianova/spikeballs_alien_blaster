﻿Public Class frmGame
    Dim explosion() As PictureBox
    Dim skyTime As Integer = 0
    Public Shared skyColor As Integer = 0
    Dim explosionTimer() As Integer = {100, 80, 60, 40, 20, 0}
    Dim random As New Random

    Private Sub frmGame_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Start the timers on load:
        tmrGameTick.Start()
        GameData.form = "tutorial"

        GameData.bullet = New PictureBox() {picBullet1, picBullet2, picBullet3, picBullet4, picBullet5, picBullet6, picBullet7, picBullet8, picBullet9, picBullet10}
        GameData.enemyBullet = New PictureBox() {picEnemyBullet1, picEnemyBullet2, picEnemyBullet3, picEnemyBullet4, picEnemyBullet5, picEnemyBullet6, picEnemyBullet7, picEnemyBullet8, picEnemyBullet9, picEnemyBullet10}
        GameData.aliens = New PictureBox() {picDefAlien1, picDefAlien2, picPilot}
        GameData.alienHealth = New PictureBox() {picDefAlienHealth1, picDefAlienHealth2, picPilotHealth}
        GameData.terrain = New PictureBox() {picFloor1, picFloor2, picFloor3, picFloor4, picCeiling1, picWall1, picTutorialText1, picTutorialText2, picFragileWall1, picFragileWall2, picFragileWall3, picAlarm, picWallPanel1, picWall2, picCeiling2, picCorner1, picFloor5, picWall3, picTutorialText3, picWall4, picFloor6, picTutorialText4, picFragileWall4, picFragileWall5, picFragileWall6, picExplosion1, picExplosion2, picExplosion3, picExplosion4, picExplosion5, picExplosion6}
        explosion = New PictureBox() {picExplosion1, picExplosion2, picExplosion3, picExplosion4, picExplosion5, picExplosion6}
        GameData.bludgeon = New PictureBox() {}
        GameData.bludgeonDead = New Boolean() {}
        GameData.bludgeonHealth = New Integer() {}
        GameData.bludgeonHealthBar = New PictureBox() {}
        GameData.bludgeonTimer = New Integer() {}
        GameData.enemyDead = New Boolean() {False, False, False}
        GameData.slopes = New PictureBox() {}
        GameData.platforms = New PictureBox() {}
        GameData.attackCooldown = New Integer() {20, 20, 10}
        GameData.enemyMovement = New Integer() {8, 8, 0}
        GameData.enemyHealth = New Double() {100, 100, 100}
        GameData.enemyJumpHeight = New Integer() {5, 5, 0}
        GameData.knockBackModifier = New Double() {3.5, 3.5, 0}
        GameData.knockbackTimer = New Integer() {0, 0, 0}
        GameData.knockbackDirection = New String() {"right", "right", "right"}
        GameData.spikeball = picSpikeball
        GameData.spikeballHealth = picSpikeballHealth
        GameData.keyControl = True
        GameData.grass = New PictureBox() {}
        GameData.medkit = New PictureBox() {}
        GameData.coin = New PictureBox() {}
        GameData.ammoBox = New PictureBox() {}
        GameData.ammoLabel = Me.lblAmmo

        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2

        reset()
        Me.Cursor.Hide()
    End Sub

    'UNCOMMENT THIS TO BREAK ALL GRAPHICS >:D
    'Protected Overrides Sub OnPaintBackground(ByVal e As PaintEventArgs)
    'Do nothing.
    'End Sub

    'KEY DETECTION
    '=================================================================='
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        'Test if either of the keys have been pressed.
        'Set their value to true and override default button tabbing.
        If GameData.keyControl Then
            Select Case keyData
                Case Keys.Right
                    If Not GameData.rolling And Not GameData.reloading Then
                        GameData.rightKey = True
                    End If
                Case Keys.Left
                    If Not GameData.rolling And Not GameData.reloading Then
                        GameData.leftKey = True
                    End If
                Case Keys.Down
                    GameData.downKey = True
                    GameData.leftKey = False
                    GameData.rightKey = False
                    GameData.s = False
                Case Keys.A
                    GameData.a = True
                Case Keys.S
                    GameData.s = True
                Case Keys.R
                    If Not GameData.reloading And GameData.activeAmmo < 5 Then
                        GameData.reloading = True
                        GameData.reloadingTimer = 30
                    End If
            End Select
        End If
    End Function

    Private Sub frmMainMenu_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        'Test if either of the keys have been released:
        If GameData.keyControl Then
            e.SuppressKeyPress = True
            e.Handled = True
            Select Case e.KeyCode
                Case Keys.Right
                    GameData.rightKey = False
                Case Keys.Left
                    GameData.leftKey = False
                Case Keys.Down
                    GameData.downKey = False
                    GameData.rolling = False
                Case Keys.A
                    GameData.a = False
                Case Keys.S
                    GameData.s = False
            End Select
        End If
    End Sub


    '=================================================================='

    'GAME TICK
    '=================================================================='
    Private Sub tmrGameTick_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGameTick.Tick
        'If spikeball is falling in the transition, change the color to make it look like he's falling into a planet.
        If Not GameData.keyControl And Not anyWall(picSpikeball) Then
            If skyTime = 0 Then
                btnClose.BackColor = Color.Transparent
                'If the sky color is maximum stop it from changing.
                If skyColor = 510 Then
                    skyTime -= 1
                Else
                    'Increase the sky color. If it is greater than 255 then change the green value to the color value - 255. Else, change the blue color to the current value.
                    skyColor += 1
                    If skyColor > 255 Then
                        Me.BackColor = Color.FromArgb(0, skyColor - 255, 255)
                    Else
                        Me.BackColor = Color.FromArgb(0, 0, skyColor)
                    End If
                End If

            Else
                skyTime -= 2
            End If
        End If
        'Test if spikeball is far enough to trigger any text:
        Select Case GameData.textNumber
            Case 0
                If GameData.alarm Then
                    'When the alarm first goes off play the alien yelling of his escape.
                    GameData.textTimer = 100
                    GameData.textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.alienTalk1
                End If
            Case 1
                If GameData.alarm And GameData.enemyDead(1) Then
                    'When the second guard dies play the pilot yelling at the idiots.
                    GameData.textTimer = 95
                    GameData.textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.pilotTalk1
                End If
            Case 2
                If picPilot.Left <= Me.Width Then
                    'When the pilot sees spikeball tell spikeball he's dead.
                    GameData.textTimer = 50
                    GameData.textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.pilotTalk2
                End If
            Case 3
                If GameData.enemyDead(2) Then
                    'When the pilot dies tell everyone to abandon ship!
                    GameData.textTimer = 65
                    GameData.textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.pilotTalk3
                End If
            Case 4
                If GameData.textTimer = 0 Then
                    'When the pilot is finished talking Spikeball says he needs to get
                    'off the ship. Queue mega-explosions, take control from the player,
                    'and roll them off the ship.
                    GameData.textTimer = 65
                    GameData.textNumber += 1
                    picTalkBox.Visible = True
                    picSpikeballHealth.Visible = False
                    picTalkBox.Image = My.Resources.spikeballTalk1
                    GameData.keyControl = False
                    GameData.direction = "right"
                    GameData.downKey = True
                    My.Settings.tutorialPlayed = True
                    My.Settings.Save()
                End If
        End Select
        'If the pilot is dead explode stuff:
        Dim cloudX As Integer = 0
        If GameData.enemyDead(2) Then
            If skyColor >= 150 Then
                If skyColor = 150 Then
                    For i = 0 To explosion.Length - 2
                        explosionTimer(i) = Random.Next(200)
                    Next
                    explosionTimer(explosion.Length - 1) = 0
                End If
                'If the sky is ready for clouds then generate clouds in the starship
                For i = 0 To explosion.Length - 1
                    If explosion(i).Top < 0 - explosion(i).Height And explosion(i).Width = 200 Then
                        explosionTimer(i) = 0
                    End If
                    If explosionTimer(i) = 0 Then
                        explosionTimer(i) = 1000
                        explosion(i).Width = 200
                        explosion(i).Height = 120
                        explosion(i).Image = Nothing
                        'Pick a random background image
                        Select Case Random.Next(0, 2)
                            Case 0
                                explosion(i).BackgroundImage = My.Resources.cloud1
                            Case 1
                                explosion(i).BackgroundImage = My.Resources.cloud2
                            Case 2
                                explosion(i).BackgroundImage = My.Resources.cloud3
                        End Select
                        explosion(i).Top = Me.Height
                        cloudX = Random.Next(0, Me.Width)
                        'For each explosion in the explosion array excepting the current explosion continue to randomly reset the x position of the clouds while the cloud is within the bounds of spikeball's width or touching another explosion.
                        For x = 0 To explosion.Length - 1
                            Do While (cloudX > (Me.Height - picSpikeball.Width / 2 - 255) And cloudX < (Me.Height - picSpikeball.Width / 2 + 45 + picSpikeball.Width)) Or (Not i = x And touchingWall(explosion(x), explosion(i)))
                                cloudX = Random.Next(0, Me.Width)
                                explosion(i).Left = cloudX
                            Loop
                        Next
                        explosion(i).Visible = True
                    Else
                        'Move the cloud.
                        explosion(i).Left -= 3
                        explosionTimer(i) -= 1
                    End If
                Next
            Else
                'If the sky is not yet ready for clouds then generate explosions in the
                'starship
                If GameData.textNumber < 3 Then
                    GameData.textNumber = 3
                End If
                For i = 0 To 3
                    If explosionTimer(i) = 0 Then
                        explosion(i).Visible = True
                        explosion(i).Image = My.Resources.smallExplosion
                        explosion(i).Left = -picFloor4.Left - random.Next(picFloor4.Width) - GameData.xPos
                        explosion(i).Top = Random.Next(200) + picCeiling2.Top + 100
                        explosionTimer(i) = 60
                    Else
                        explosionTimer(i) -= 1
                    End If
                Next
            End If
        End If
        If GameData.textTimer > 0 Then
            GameData.textTimer -= 1
            If GameData.textTimer = 0 Then
                picTalkBox.Visible = False
                picTalkBox.Image = Nothing
            End If
        End If

        'Move the player:
        Spikeball.keyEvents()
        Spikeball.jump()

        'Bullet:
        Bullet.shoot()

        'If spikeball rolls into a wall break it:
        If touchingWall(picFragileWall3, picSpikeball) And GameData.rolling Then
            If Not GameData.breakingWall Then
                GameData.breakingWall = True
                GameData.breakModifier = 2.5
                picAlarm.Image = My.Resources.alarmBlaring
                GameData.alarm = True
                GameData.attack = True
            End If
        End If
        If touchingWall(picFragileWall5, picSpikeball) Then
            If Not GameData.breakingWall Then
                GameData.breakModifier = 2.5
                GameData.breakingWall = True
            End If
        End If

        If GameData.breakingWall Then
            'If the wall is visible then make them fall
            If picFragileWall1.Visible Then
                picFragileWall1.Left += 7 * GameData.breakModifier
                picFragileWall1.Top += 7 / GameData.breakModifier
            End If
            If picFragileWall2.Visible Then
                picFragileWall2.Left += 6 * GameData.breakModifier
                picFragileWall2.Top += 8 / GameData.breakModifier
            End If
            If picFragileWall3.Visible Then
                picFragileWall3.Left += 5 * GameData.breakModifier
                picFragileWall3.Top += 9 / GameData.breakModifier
            End If
            'Reduce how far they fall next time
            If GameData.breakModifier > 1 Then
                GameData.breakModifier -= 0.15
            End If
            'If they fall below the screen make them invisible
            If picFragileWall1.Top > Me.Height Then
                picFragileWall1.Visible = False
                GameData.breakingWall = False
            End If
            If picFragileWall2.Top > Me.Height Then
                picFragileWall2.Visible = False
            End If
            If picFragileWall3.Top > Me.Height Then
                picFragileWall3.Visible = False
            End If

            If Not GameData.keyControl Then
                'If the wall is visible then make them fall
                If picFragileWall4.Visible Then
                    picFragileWall4.Left += 6 * GameData.breakModifier
                    picFragileWall4.Top += 8 / GameData.breakModifier
                End If
                If picFragileWall5.Visible Then
                    picFragileWall5.Left += 5 * GameData.breakModifier
                    picFragileWall5.Top += 9 / GameData.breakModifier
                End If
                If picFragileWall6.Visible Then
                    picFragileWall6.Left += 7 * GameData.breakModifier
                    picFragileWall6.Top += 7 / GameData.breakModifier
                End If
                'Reduce how far they fall next time
                If GameData.breakModifier > 1 Then
                    GameData.breakModifier -= 0.15
                End If
            End If
        End If

        'Background color changes
        If Not GameData.keyControl And Not anyWall(picSpikeball) Then
            Select Case Me.BackColor
                Case Color.Silver
                    Me.BackColor = Color.Gray
                Case Color.Gray
                    Me.BackColor = Color.DarkGray
                Case Color.DarkGray
                    Me.BackColor = Color.Black
                Case Color.FromArgb(64, 0, 0)
                    Me.BackColor = Color.FromArgb(32, 0, 0)
                Case Color.FromArgb(32, 0, 0)
                    Me.BackColor = Color.Black
            End Select
        ElseIf GameData.alarm Then
            'If the alarm is blaring change the background of the form:
            Select Case Me.BackColor
                Case Color.Silver
                    Me.BackColor = Color.LightSalmon
                Case Color.LightSalmon
                    Me.BackColor = Color.Red
                Case Color.Red
                    Me.BackColor = Color.Maroon
                Case Color.Maroon
                    Me.BackColor = Color.FromArgb(64, 0, 0)
            End Select
        Else
            'Else revert the background to normal:
            Select Case Me.BackColor
                Case Color.FromArgb(64, 0, 0)
                    Me.BackColor = Color.Maroon
                Case Color.Maroon
                    Me.BackColor = Color.Red
                Case Color.Red
                    Me.BackColor = Color.LightSalmon
                Case Color.LightSalmon
                    Me.BackColor = Color.Silver
            End Select
        End If

        'CALL AI:
        For i = 0 To GameData.aliens.Length - 2
            DefaultAlien.act(GameData.aliens(i), GameData.alienHealth(i), i)
        Next

        'CALL WALL DETECT FUNCTIONS:
        For i = 0 To GameData.terrain.Length - 7
            If Not (GameData.rolling And (GameData.terrain(i) Is picFragileWall1 Or GameData.terrain(i) Is picFragileWall2 Or GameData.terrain(i) Is picFragileWall3 Or GameData.terrain(i) Is picFragileWall4 Or GameData.terrain(i) Is picFragileWall5 Or GameData.terrain(i) Is picFragileWall6)) Then
                Spikeball.wallDetect(GameData.terrain(i))
            End If
        Next

        'If the player is not rolling call wall detection on entities:
        If Not GameData.rolling And Not GameData.downKey Then
            For i = 0 To GameData.aliens.Length - 1
                If Not GameData.enemyDead(i) Then
                    Spikeball.wallDetect(GameData.aliens(i))
                End If
            Next
        End If

        If Not GameData.enemyDead(2) Then
            Spikeball.wallDetect(GameData.aliens(2))
        End If

        'Pilot code:
        If Not GameData.enemyDead(2) Then
            If GameData.attackCooldown(2) = 0 Then
                'Test for a free bullet and make it fire:
                For i = 0 To 9
                    If Not GameData.enemyBulletFiring(i) And picPilot.Left <= Me.Width Then
                        'Set up the bullet for it to fire:
                        GameData.enemyBulletFiring(i) = True
                        GameData.enemyBullet(i).Visible = True
                        GameData.enemyBullet(i).Top = picPilot.Top + 100
                        GameData.enemyBullet(i).Left = picPilot.Left - GameData.bullet(i).Width
                        GameData.enemyBulletDirection(i) = "left"
                        GameData.attackCooldown(2) = 10
                        Exit For
                    End If
                Next
                If Not GameData.enemyCostume(2) = "pilotShoot" Then
                    picPilot.Image = My.Resources.pilotShoot
                    GameData.enemyCostume(2) = "pilotShoot"
                End If
            Else
                GameData.attackCooldown(2) -= 1
            End If
        End If

        'Camera movement:
        Camera.cameraUse()
        For i = 0 To GameData.aliens.Length - 1
            GameData.aliens(i).Left += GameData.enemyMovement(i)
            GameData.alienHealth(i).Left += GameData.enemyMovement(i)
            GameData.enemyMovement(i) = 0
        Next
    End Sub
    '=================================================================='

    Public Shared closeTimer As Integer = 0

    'GAME FUNCTIONS
    '=================================================================='
    
    'Boolean method for if an entity is touching the wall:
    Private Function touchingWall(ByVal wallName, ByVal character)
        If character.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function
    'Boolean method for if an entity is touching any wall:
    Private Function anyWall(ByVal character)
        For i = 0 To GameData.terrain.Length - 1
            If touchingWall(GameData.terrain(i), character) And Not (GameData.rolling And GameData.breakingWall And (GameData.terrain(i) Is picFragileWall1 Or GameData.terrain(i) Is picFragileWall2 Or GameData.terrain(i) Is picFragileWall3 Or GameData.terrain(i) Is picFragileWall4 Or GameData.terrain(i) Is picFragileWall5 Or GameData.terrain(i) Is picFragileWall6)) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any entity:
    Private Function anyEntity(ByVal character)
        For i = 0 To GameData.aliens.Length() - 1
            If Not GameData.enemyDead(i) And touchingWall(GameData.aliens(i), character) Then
                Return True
            End If
        Next


        Return False
    End Function
    
    'Reset the form:
    Public Shared Function reset()
        If GameData.keyControl Then
            'Reset entities:
            frmGame.picSpikeball.Left = 38
            frmGame.picSpikeball.Top = frmGame.Height * 0.66
            frmGame.picSpikeball.Image = My.Resources.spikeballStandRight
            frmGame.picSpikeballHealth.Left = 50
            frmGame.picSpikeballHealth.Top = frmGame.Height * 0.66 - 16
            frmGame.picSpikeballHealth.Image = My.Resources.heathbar100
            frmGame.picDefAlien1.Left = 1343
            frmGame.picDefAlien1.Top = frmGame.Height * 0.66
            frmGame.picDefAlienHealth1.Left = 1368
            frmGame.picDefAlienHealth1.Top = frmGame.Height * 0.66 - 16
            frmGame.picDefAlien1.Visible = True
            frmGame.picDefAlienHealth1.Visible = True
            frmGame.picDefAlienHealth1.Image = My.Resources.heathbar100
            frmGame.picDefAlien2.Visible = True
            frmGame.picDefAlienHealth2.Visible = True
            frmGame.picDefAlienHealth2.Image = My.Resources.heathbar100

            'Reset terrain:
            frmGame.picFloor1.Left = 0
            frmGame.picFloor2.Left = 210
            frmGame.picFloor3.Left = 630
            frmGame.picFloor4.Left = 840
            frmGame.picFloor5.Left = 2310
            frmGame.picCeiling1.Left = 0
            frmGame.picWall1.Left = 0
            frmGame.picWall2.Left = 1470
            frmGame.picWall3.Left = 2310
            frmGame.picTutorialText3.Left = 1670
            frmGame.picCeiling2.Left = 1470
            frmGame.picCorner1.Left = 1370
            frmGame.picTutorialText1.Left = 12
            frmGame.picTutorialText2.Left = 1010
            frmGame.picFragileWall1.Left = 1250
            frmGame.picFragileWall1.Top = 420 + frmGame.Height - 720
            frmGame.picFragileWall2.Left = 1250
            frmGame.picFragileWall2.Top = 420 + frmGame.Height - 720 + 67
            frmGame.picFragileWall3.Left = 1250
            frmGame.picFragileWall3.Top = 420 + frmGame.Height - 720 + 134
            frmGame.picFragileWall1.Visible = True
            frmGame.picFragileWall2.Visible = True
            frmGame.picFragileWall3.Visible = True
            frmGame.picAlarm.Left = 1470
            frmGame.picAlarm.Image = My.Resources.alarmSilent
            frmGame.picDefAlienHealth2.Left = 1708
            frmGame.picDefAlienHealth2.Top = 380
            frmGame.picDefAlien2.Left = 1683
            frmGame.picDefAlien2.Top = 396
            frmGame.picWall4.Left = 4180
            frmGame.picFloor6.Left = 4180
            frmGame.picTutorialText4.Left = 998
            frmGame.picPilot.Left = 4780
            frmGame.picPilotHealth.Left = 4805
            frmGame.picPilot.Visible = True
            frmGame.picPilotHealth.Visible = True
            frmGame.picFragileWall4.Left = 5620
            frmGame.picFragileWall5.Left = 5620
            frmGame.picFragileWall6.Left = 5620

            frmGame.BackColor = Color.Silver

            'Reset variables:
            GameData.textNumber = 0
            GameData.xPos = 0
            GameData.jumpHeight = 0
            GameData.jumping = False
            GameData.jumpTimer = 0
            GameData.cameraMoving = False
            GameData.speed = 0
            GameData.a = False
            GameData.leftKey = False
            GameData.rightKey = False
            GameData.falling = True
            GameData.rolling = False
            GameData.health = 10
            GameData.breakingWall = False
            GameData.breakModifier = 2.5
            GameData.alarm = False
            GameData.attack = False
            GameData.keyControl = True
            GameData.downKey = False
            GameData.s = False
            GameData.ammo = 40
            GameData.activeAmmo = 5
            frmGame.explosion(0).Visible = False
            frmGame.explosion(1).Visible = False
            frmGame.explosion(2).Visible = False
            frmGame.explosion(3).Visible = False
            frmGame.picSpikeballHealth.Image = My.Resources.heathbar100
            frmGame.lblLives.Text = "SPIKEBALL : " & GameData.lives

            For x = 0 To GameData.enemyJumpHeight.Length - 1
                GameData.enemyJumpHeight(x) = 0
                GameData.knockbackTimer(x) = 0
                GameData.enemyDead(x) = False
                GameData.enemyHealth(x) = 100
            Next
            Return True
        End If
    End Function
    '=================================================================='

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        'Close the form:
        Close()
    End Sub
End Class