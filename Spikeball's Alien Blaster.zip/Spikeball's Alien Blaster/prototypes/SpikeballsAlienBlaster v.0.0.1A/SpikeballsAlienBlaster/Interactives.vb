﻿Public Class Interactives
    Public Shared Function interactives()
        'Medkits:
        For i = 0 To GameData.medkit.Length - 1
            If GameData.spikeball.Bounds.IntersectsWith(GameData.medkit(i).Bounds) And GameData.medkitUsed(i) = False Then
                GameData.medkitUsed(i) = True
                GameData.medkit(i).Image = My.Resources.medkitUse
                GameData.medkitCounter(i) = 25
                'Heal the player:
                GameData.health = 10
                GameData.spikeballHealth.Image = My.Resources.heathbar100
            End If
            If GameData.medkitCounter(i) > 0 Then
                GameData.medkitCounter(i) -= 1
                If GameData.medkitCounter(i) = 0 Then
                    GameData.medkit(i).Visible = False
                End If
            End If
        Next
        'Coins:
        For i = 0 To GameData.coin.Length - 1
            If GameData.spikeball.Bounds.IntersectsWith(GameData.coin(i).Bounds) And GameData.coinCollected(i) = False Then
                GameData.coinCollected(i) = True
                GameData.coin(i).Image = My.Resources.coinCollect
                GameData.coinCounter(i) = 20
            End If
            If GameData.coinCounter(i) > 0 Then
                GameData.coinCounter(i) -= 1
                If GameData.coinCounter(i) = 0 Then
                    GameData.coin(i).Visible = False
                End If
            End If
        Next
        'Ammo:
        For i = 0 To GameData.ammoBox.Length - 1
            If GameData.spikeball.Bounds.IntersectsWith(GameData.ammoBox(i).Bounds) And GameData.ammoCollected(i) = False Then
                GameData.ammoCollected(i) = True
                GameData.ammoBox(i).Image = My.Resources.ammoUse
                GameData.ammoCounter(i) = 20
                GameData.ammo += 5
                frmTerraLevel1.lblAmmo.Text = GameData.activeAmmo & " | " & GameData.ammo
            End If
            If GameData.ammoCounter(i) > 0 Then
                GameData.ammoCounter(i) -= 1
                If GameData.ammoCounter(i) = 0 Then
                    GameData.ammoBox(i).Visible = False
                End If
            End If
        Next
        Return True
    End Function

    Public Shared Function decorations()
        'Test if the player is rolling into the grass, and if so cut it down in the appropriate direction:
        For i = 0 To GameData.grass.Length - 1
            If GameData.spikeball.Bounds.IntersectsWith(GameData.grass(i).Bounds) And GameData.rolling And GameData.grassCut(i) = False Then
                GameData.grassCounter(i) = 10
                GameData.grassCut(i) = True
                If GameData.direction = "left" Then
                    GameData.grass(i).Image = My.Resources.grassCutLeft
                Else
                    GameData.grass(i).Image = My.Resources.grassCutRight
                End If
            End If
            If GameData.grassCounter(i) > 0 Then
                GameData.grassCounter(i) -= 1
                If GameData.grassCounter(i) = 0 Then
                    GameData.grass(i).Image = My.Resources.grassCut
                End If
            End If
            If GameData.grass(i).Left < 0 - GameData.grass(i).Width Or GameData.grass(i).Left > frmTerraLevel1.Width Then
                GameData.grassCut(i) = False
                GameData.grass(i).Image = My.Resources.grass
            End If
        Next
        Return True
    End Function
End Class
