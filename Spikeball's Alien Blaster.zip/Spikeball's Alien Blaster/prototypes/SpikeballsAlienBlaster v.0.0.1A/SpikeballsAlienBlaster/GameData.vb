﻿Public Class GameData
    'Create physics variables:
    Public Shared speed As Integer = 10
    Public Shared speedRollMod As Double = 2
    Public Shared jumpHeight As Integer = 5
    Public Shared direction As String = "right"

    'Create control variables:
    Public Shared leftKey As Boolean = False
    Public Shared rightKey As Boolean = False
    Public Shared downKey As Boolean = True
    Public Shared a As Boolean = False
    Public Shared s As Boolean = False
    Public Shared jumping As Boolean = False
    Public Shared rolling As Boolean = True
    Public Shared falling As Boolean = True
    Public Shared cameraMoving As Boolean = False
    Public Shared xPos As Integer = 0
    Public Shared shootCooldown As Integer = 0
    Public Shared breakModifier As Double = 2.5
    Public Shared breakingWall As Boolean = False
    Public Shared alarm As Boolean = False
    Public Shared attack As Boolean = False
    Public Shared textNumber As Integer = 0
    Public Shared textTimer As Integer = 0
    Public Shared keyControl As Integer = False
    Public Shared ammo As Integer = 40
    Public Shared activeAmmo As Integer = 5
    Public Shared reloading As Boolean = False
    Public Shared reloadingTimer As Integer = 0

    'Create timers:
    Public Shared transitionTimer As Integer = 0
    Public Shared jumpTimer As Integer = 0
    Public Shared knockbackTimer() As Integer = {0, 0}
    Public Shared fadeTimer As Integer = -1

    'Create graphics variables
    Public Shared graphic As String = "spikeballStandRight"

    'Create storage array lists of entities:
    Public Shared enemySpeeds() As Integer = {8, 8}
    Public Shared enemyCostume() As String = {"defAlienStandLeft", "defAlienStandLeft", "pilotStand"}
    Public Shared knockback() As Boolean = {True, True, False}
    Public Shared enemyJumpHeight() As Integer = {5, 5}
    Public Shared knockBackModifier() As Double = {3.5, 3.5}
    Public Shared knockbackDirection() As String = {"right", "right"}
    Public Shared attackCooldown() As Integer = {45, 45}
    Public Shared enemyHealth() As Double = {100, 100}
    Public Shared enemyDead() As Boolean = {False, False}
    Public Shared bulletFiring() As Boolean = {False, False, False, False, False, False, False, False, False, False}
    Public Shared gravitySlopes() As Integer = {0, 0}
    Public Shared enemyBulletFiring() As Boolean = {False, False, False, False, False, False, False, False, False, False}
    Public Shared bullet() As PictureBox
    Public Shared enemyBullet() As PictureBox
    Public Shared enemyBulletDirection() As String = {"right", "right", "right", "right", "right", "right", "right", "right", "right", "right"}
    Public Shared bulletDirection() As String = {"right", "right", "right", "right", "right", "right", "right", "right", "right", "right"}
    Public Shared grass() As PictureBox
    Public Shared enemyMovement() As Integer = {0, 0}
    Public Shared aliens() As PictureBox
    Public Shared alienHealth() As PictureBox
    Public Shared terrain() As PictureBox
    Public Shared slopes() As PictureBox
    Public Shared platforms() As PictureBox
    Public Shared grassCounter() As Integer = {0, 0, 0, 0}
    Public Shared grassCut() As Boolean = {False, False, False, False}
    Public Shared medkit() As PictureBox
    Public Shared medkitCounter() As Integer = {0}
    Public Shared medkitUsed() As Boolean = {False}
    Public Shared coin() As PictureBox
    Public Shared coinCounter() As Integer = {0, 0, 0, 0, 0}
    Public Shared coinCollected() As Boolean = {False, False, False, False, False}
    Public Shared ammoBox() As PictureBox
    Public Shared ammoCounter() As Integer = {0, 0, 0, 0, 0}
    Public Shared ammoCollected() As Boolean = {False, False, False, False, False}
    Public Shared bludgeon() As PictureBox
    Public Shared bludgeonHealthBar() As PictureBox
    Public Shared bludgeonHealth() As Integer = {150}
    Public Shared bludgeonFlightSpeed() As Double = {0}
    Public Shared bludgeonDead() As Boolean = {False}
    Public Shared bludgeonTimer() As Integer = {0}
    Public Shared bombs() As PictureBox
    Public Shared bombDrop() As Boolean = {False}
    Public Shared bombTimer() As Integer = {0}


    'Create score variables:
    Public Shared score As Integer = 0
    Public Shared lives As Integer = 5
    Public Shared health As Double = 100

    'Player:
    Public Shared spikeball As PictureBox = frmTerraLevel1.picSpikeball
    Public Shared spikeballHealth As PictureBox = frmTerraLevel1.picSpikeballHealth

    'Form:
    Public Shared form As String = "tutorial"
    Public Shared ammoLabel As Label = frmTerraLevel1.lblAmmo
End Class
