﻿Public Class Spikeball
    Public Shared Function move()
        'Move spikeball:
        If GameData.keyControl Then
            If GameData.rolling And GameData.transitionTimer = 0 And Not GameData.cameraMoving And GameData.spikeball.Left > 0 Then
                GameData.spikeball.Left += GameData.speed * GameData.speedRollMod
                GameData.spikeballHealth.Left += GameData.speed * GameData.speedRollMod
            ElseIf Not GameData.downKey Then
                GameData.spikeball.Left += GameData.speed
                GameData.spikeballHealth.Left += GameData.speed
            End If
        End If
        Return True
    End Function
    Public Shared Function keyEvents()
        'Test if either of the keys are pressed, and if so move spikeball and change the animation:
        If GameData.rightKey And Not GameData.reloading Then
            GameData.direction = "right"
            GameData.speed = 12
            'If Not cameraMoving Then
            '    picSpikeball.Left += speed
            '    picSpikeballHealth.Left += speed
            'End If
            If Not GameData.graphic = "spikeballRunRight" Then
                GameData.spikeball.Image = My.Resources.spikeballRunRight
                GameData.graphic = "spikeballRunRight"
            End If
        ElseIf GameData.leftKey And Not GameData.reloading Then
            GameData.direction = "left"
            GameData.speed = -12
            If Not GameData.graphic = "spikeballRunLeft" Then
                GameData.spikeball.Image = My.Resources.spikeballRunLeft
                GameData.graphic = "spikeballRunLeft"
            End If
        ElseIf GameData.downKey Then
            'If spikeball is not rolling then play the transition animation and
            'the rolling animation.
            If Not GameData.rolling = True Then
                GameData.speedRollMod = 2
                'If the graphic is not transition switch it to transition and start
                'the transition timer.
                If Not GameData.graphic = "transition" Then
                    If GameData.direction = "right" Then
                        GameData.spikeball.Image = My.Resources.spikeballTransitionRight
                    ElseIf GameData.direction = "left" Then
                        GameData.spikeball.Image = My.Resources.spikeballTransitionLeft
                    End If
                    GameData.graphic = "transition"
                    GameData.transitionTimer = 30
                End If
                'If the transition timer is 0 play the rolling animation.
                'Else decrease the transition timer.
                If GameData.transitionTimer = 0 Then
                    If GameData.direction = "right" Then
                        GameData.spikeball.Image = My.Resources.spikeballSpinRight
                    ElseIf GameData.direction = "left" Then
                        GameData.spikeball.Image = My.Resources.spikeballSpinLeft
                    End If
                    GameData.rolling = True
                Else
                    GameData.transitionTimer -= 1
                End If
            End If
            'If the speed is not already set set it:
            If GameData.direction = "left" Then
                GameData.speed = -12
            Else
                GameData.speed = 12
            End If
        ElseIf GameData.direction = "right" And GameData.keyControl And Not GameData.reloading Then
            GameData.spikeball.Image = My.Resources.spikeballStandRight
            GameData.graphic = "spikeballStandRight"
            If GameData.speed > 0 Then
                GameData.speed -= 2
            End If
        ElseIf GameData.direction = "left" And GameData.keyControl And Not GameData.reloading Then
            GameData.spikeball.Image = My.Resources.spikeballStandLeft
            GameData.graphic = "spikeballStandLeft"
            If GameData.speed < 0 Then
                GameData.speed += 2
            End If
        End If
        If GameData.a Then
            'If the a key is pressed and the player is not jumping and not falling then
            'start the jump timer and set jumping to true.
            If GameData.jumping = False And GameData.falling = False Then
                GameData.jumpHeight = 7
                GameData.spikeball.Top -= GameData.jumpHeight
                GameData.spikeballHealth.Top -= GameData.jumpHeight
                GameData.jumpTimer = 20
                GameData.jumping = True
            End If
        End If
        If GameData.s Then
            'If the s key is pressed and the player is not shooting then start the shoot timer and
            'release a bullet.
            If Not GameData.downKey Then
                If GameData.shootCooldown = 0 And Not GameData.reloading Then
                    'Test for a free bullet and make it fire:
                    For i = 0 To 9
                        If Not GameData.bulletFiring(i) And Not GameData.activeAmmo = 0 Then
                            'Set up the bullet for it to fire:
                            GameData.bulletFiring(i) = True
                            GameData.bullet(i).Visible = True
                            GameData.bullet(i).Top = GameData.spikeball.Top + 80
                            If GameData.direction = "right" Then
                                GameData.bullet(i).Left = GameData.spikeball.Left + GameData.spikeball.Width
                            Else
                                GameData.bullet(i).Left = GameData.spikeball.Left - GameData.bullet(i).Width
                            End If
                            GameData.bulletDirection(i) = GameData.direction
                            GameData.shootCooldown = 15
                            GameData.activeAmmo -= 1
                            frmTerraLevel1.lblAmmo.Text = GameData.activeAmmo & " | " & GameData.ammo
                            Exit For
                        End If
                    Next
                End If
            End If
        End If
        Return True
    End Function

    'WALL DETECT
    Public Shared Function wallDetect(ByVal wallName)

        If GameData.spikeball.Bounds.IntersectsWith(wallName.Bounds) Then
            If GameData.spikeball.Top > wallName.Top + wallName.Height / 1.2 Then
                'Negate top movement
                GameData.spikeball.Top += GameData.jumpHeight
                GameData.spikeballHealth.Top += GameData.jumpHeight
                GameData.jumpTimer = 0
                GameData.jumpHeight = 0
                Return True
            ElseIf GameData.spikeball.Top < wallName.Top - 100 Then
                'Stop the player from falling:
                GameData.falling = False
                GameData.jumping = False
                GameData.jumpHeight = 0
                GameData.jumpTimer = 0
                Return True
            ElseIf GameData.spikeball.Left < wallName.Left And GameData.direction = "right" And Not (anySlope() And GameData.rolling) Then
                If GameData.spikeball.Top < wallName.Top + wallName.Height Then
                    GameData.speed = 0
                    If GameData.rolling And GameData.keyControl And Not anySlope() Then
                        GameData.rolling = False
                        GameData.downKey = False
                    End If
                    Return True
                End If
            ElseIf GameData.spikeball.Left > wallName.Left And GameData.direction = "left" And Not (anySlope() And GameData.rolling) Then
                If GameData.spikeball.Top < wallName.Top + wallName.Height Then
                    GameData.speed = 0
                    If GameData.rolling And GameData.keyControl And Not anySlope() Then
                        GameData.rolling = False
                        GameData.downKey = False
                    End If
                    Return True
                End If
            ElseIf GameData.spikeball.Left < wallName.Left And GameData.direction = "right" And anySlope() Or GameData.spikeball.Left > wallName.Left And GameData.direction = "left" And anySlope() Then
                GameData.spikeball.Top = wallName.Top - GameData.spikeball.Height - 1
                GameData.spikeballHealth.Top = wallName.top - GameData.spikeballHealth.Height - GameData.spikeball.Height - 1
            Else
                Return False
            End If
        End If
        Return True

    End Function
    'PLATFORM DETECT
    Public Shared Function platformDetect(ByVal wallName)

        If GameData.spikeball.Bounds.IntersectsWith(wallName.Bounds) Then
            If GameData.spikeball.Top < wallName.Top - 100 Then
                'Stop the player from falling:
                GameData.falling = False
                GameData.jumping = False
                GameData.jumpHeight = 0
                GameData.jumpTimer = 0
                Return True
            ElseIf GameData.spikeball.Left < wallName.Left And GameData.direction = "right" And anySlope() Or GameData.spikeball.Left > wallName.Left And GameData.direction = "left" And anySlope() Then
                GameData.spikeball.Top = wallName.Top - GameData.spikeball.Height - 1
                GameData.spikeballHealth.Top = wallName.top - GameData.spikeballHealth.Height - GameData.spikeball.Height - 1
            Else
                Return False
            End If
        End If
        Return True

    End Function

    'SLOPE DETECT:
    Public Shared Function slopeDetectionRight(ByVal wallName)
        Dim gravitySlope As Integer = 0
        If GameData.spikeball.Bounds.IntersectsWith(wallName.Bounds) And Not GameData.jumpHeight > 0 Then
            'Stop the player from falling:
            If GameData.falling Then
                GameData.falling = False
                GameData.jumping = False
                GameData.jumpHeight = 0
                GameData.jumpTimer = 0
                gravitySlope = 3
            End If
            'If the gravity on the slope is running fall him onto the correct spot on the slope.
            If gravitySlope > -1 And GameData.spikeball.Top <= wallName.Top + (30 - (GameData.spikeball.Left - wallName.Left) * 0.25) - GameData.spikeball.Height Then
                gravitySlope -= 1
                GameData.spikeball.Top += (30 - (GameData.spikeball.Left - wallName.Left) * 0.25) / 3
                GameData.spikeballHealth.Top += (30 - (GameData.spikeball.Left - wallName.Left) * 0.25) / 3
            End If
            If GameData.spikeball.Left >= wallName.Left - 15 And GameData.spikeball.Left <= wallName.Width + wallName.Left - GameData.spikeball.Width + 15 Then
                If GameData.direction = "right" And (GameData.rightKey Or GameData.rolling) Then
                    'If spikeball is going up the slope (to the right), make him move up. Decrease his speed and make him go up faster if he's rolling.
                    If GameData.rolling Then
                        GameData.spikeball.Top -= 5.5
                        GameData.spikeballHealth.Top -= 5.5
                    Else
                        GameData.spikeball.Top -= 3
                        GameData.spikeballHealth.Top -= 3
                    End If
                ElseIf GameData.direction = "left" And (GameData.leftKey Or GameData.rolling) Then
                    'If spikeball is going down the slope (to the left) make him go down. Increase his speed and make him go up much faster if he's rolling.
                    If GameData.rolling Then
                        GameData.spikeball.Top += 6.5
                        GameData.spikeballHealth.Top += 6.5
                    Else
                        GameData.spikeball.Top += 3
                        GameData.spikeballHealth.Top += 3
                    End If
                End If
            End If
        End If
        Return True
    End Function

    'Boolean method for if an entity is touching any slope:
    Public Shared Function anySlope()
        For i = 0 To GameData.slopes.Length - 1
            If touchingWall(GameData.slopes(i)) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching the wall:
    Public Shared Function touchingWall(ByVal wallName)
        If GameData.spikeball.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function
    'Boolean method for if an entity is touching any wall:
    Public Shared Function anyWall()
        For i = 0 To GameData.terrain.Length - 1
            If touchingWall(GameData.terrain(i)) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any platform:
    Public Shared Function anyPlatform()
        For i = 0 To GameData.platforms.Length - 1
            If touchingWall(GameData.platforms(i)) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any entity:
    Public Shared Function anyEntity()
        For i = 0 To GameData.aliens.Length() - 1
            If Not GameData.enemyDead(i) And touchingWall(GameData.aliens(i)) Then
                Return True
            End If
        Next
        Return False
    End Function

    'Jump
    Public Shared Function jump()
        'Gravity and jumping:
        If GameData.jumping = False And GameData.falling = True Then
            'If the player is not jumping and the player is falling then
            'apply gravity.
            If ((GameData.form = "level 1" And frmTerraTerrain1.picGrass1.Top > 493 And GameData.spikeball.Top >= frmTerraLevel1.Height / 2 - GameData.spikeball.Height / 2) Or (GameData.form = "tutorial" And GameData.keyControl = False And frmGame.skyColor < 510)) Then
                For i = 0 To GameData.terrain.Length - 1
                    GameData.terrain(i).Top -= 30
                Next
                For i = 0 To GameData.grass.Length - 1
                    GameData.grass(i).Top -= 30
                Next
                For i = 0 To GameData.aliens.Length - 1
                    GameData.aliens(i).Top -= 30
                    GameData.alienHealth(i).Top -= 30
                Next
                For i = 0 To GameData.slopes.Length - 1
                    GameData.slopes(i).Top -= 30
                Next
                For i = 0 To GameData.medkit.Length - 1
                    GameData.medkit(i).Top -= 30
                Next
                For i = 0 To GameData.coin.Length - 1
                    GameData.coin(i).Top -= 30
                Next
                For i = 0 To GameData.ammoBox.Length - 1
                    GameData.ammoBox(i).Top -= 30
                Next
                For i = 0 To GameData.platforms.Length - 1
                    GameData.platforms(i).Top -= 30
                Next
                For i = 0 To GameData.bludgeon.Length - 1
                    GameData.bludgeon(i).Top -= 30
                    GameData.bludgeonHealthBar(i).Top -= 30
                Next

                frmTerraBackground1.picBackground1.Top -= 15
                frmTerraBackground1.picBackground2.Top -= 15
                GameData.jumpHeight = 0
                If GameData.form = "tutorial" And GameData.spikeball.Left > frmGame.Width / 2 - GameData.spikeball.Width / 2 And frmGame.picFloor6.Top < -100 Then
                    GameData.spikeball.Left -= 12
                End If
            Else
                If GameData.rolling Then
                    GameData.spikeball.Top += 25
                    GameData.spikeballHealth.Top += 25
                Else
                    GameData.spikeball.Top += 20
                    GameData.spikeballHealth.Top += 20
                End If
                GameData.jumpHeight = 0
            End If
        ElseIf GameData.jumping = True And GameData.jumpTimer > 0 Then
            'If the player is jumping reduce the timer of their jumping and
            'move them upward.
            GameData.jumpTimer -= 1
            If GameData.rolling Then
                GameData.spikeball.Top -= GameData.jumpHeight / 2
                GameData.spikeballHealth.Top -= GameData.jumpHeight / 2
            Else
                GameData.spikeball.Top -= GameData.jumpHeight
                GameData.spikeballHealth.Top -= GameData.jumpHeight
            End If
            If Not GameData.jumpHeight = 7 Then
                GameData.jumpHeight += 1
            End If
            'If the jumpTick = 0 then turn falling on.
            If GameData.jumpTimer = 0 Then
                GameData.falling = True
            End If
        ElseIf GameData.jumpTimer = 0 And GameData.jumping = True Then
            'If the player's jump timer has run out then slow their jumping to 0
            'and then turn gravity back on.
            If GameData.jumpHeight > -25 Then
                GameData.jumpHeight -= 1
            End If
            GameData.spikeball.Top -= GameData.jumpHeight
            GameData.spikeballHealth.Top -= GameData.jumpHeight
        ElseIf GameData.keyControl = False And GameData.form = "level 1" Then
            GameData.rolling = False
            GameData.downKey = False
            GameData.keyControl = True
            hurt(5)
        End If
        'If the player is not touching any of the level elements turn gravity on.
        If GameData.jumping = False And Not anyWall() And Not anyEntity() And Not anySlope() And Not anyPlatform() Then
            GameData.falling = True
            GameData.jumping = False
            GameData.jumpTimer = 0
        End If
        'If the player has fallen off the screen then kill them:
        If GameData.form = "tutorial" Then
            If GameData.spikeball.Top > frmGame.Height Then
                If GameData.keyControl Then
                    hurt(1000)
                Else
                    frmFade.Show()
                End If
            End If
        ElseIf GameData.form = "level 1" Then
            If GameData.spikeball.Top > frmTerraLevel1.Height Then
                hurt(1000)
            End If
        End If
        Return True
    End Function

    'Hurt the player:
    Public Shared Function hurt(ByVal pain)
        GameData.health -= pain
        If GameData.health = 10 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar100
        ElseIf GameData.health = 9 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar90
        ElseIf GameData.health = 8 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar80
        ElseIf GameData.health = 7 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar70
        ElseIf GameData.health = 6 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar60
        ElseIf GameData.health = 5 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar50
        ElseIf GameData.health = 4 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar40
        ElseIf GameData.health = 3 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar30
        ElseIf GameData.health = 2 Then
            GameData.spikeballHealth.Image = My.Resources.heathbar20
        ElseIf GameData.health = 1 Then
            GameData.spikeballHealth.Image = My.Resources.healthbar10
        ElseIf GameData.health < 0 Then
            'RESET THE FORM
            GameData.lives -= 1
            frmTerraLevel1.lblLives.Text = "SPIKEBALL | " & GameData.lives
            Select Case GameData.form
                Case "level 1"
                    If GameData.lives = 0 Then
                        frmTerraBackground1.Close()
                        frmTerraTerrain1.Close()
                        frmTerraLevel1.Close()
                    End If
                    frmTerraLevel1.reset()
                Case "tutorial"
                    If GameData.lives = 0 Then
                        frmGame.Close()
                    End If
                    frmGame.reset()
            End Select
        End If
        Return True
    End Function
End Class
