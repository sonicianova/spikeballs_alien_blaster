﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTerraBackground1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picBludgeonHealth1 = New System.Windows.Forms.PictureBox
        Me.picBludgeon1 = New System.Windows.Forms.PictureBox
        Me.picBackground2 = New System.Windows.Forms.PictureBox
        Me.picBackground1 = New System.Windows.Forms.PictureBox
        CType(Me.picBludgeonHealth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBludgeon1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBackground2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBackground1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBludgeonHealth1
        '
        Me.picBludgeonHealth1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picBludgeonHealth1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picBludgeonHealth1.Location = New System.Drawing.Point(69, 16)
        Me.picBludgeonHealth1.Name = "picBludgeonHealth1"
        Me.picBludgeonHealth1.Size = New System.Drawing.Size(100, 10)
        Me.picBludgeonHealth1.TabIndex = 52
        Me.picBludgeonHealth1.TabStop = False
        '
        'picBludgeon1
        '
        Me.picBludgeon1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picBludgeon1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.bludgeonRight
        Me.picBludgeon1.Location = New System.Drawing.Point(34, 32)
        Me.picBludgeon1.Name = "picBludgeon1"
        Me.picBludgeon1.Size = New System.Drawing.Size(171, 162)
        Me.picBludgeon1.TabIndex = 51
        Me.picBludgeon1.TabStop = False
        '
        'picBackground2
        '
        Me.picBackground2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picBackground2.Location = New System.Drawing.Point(0, 425)
        Me.picBackground2.Name = "picBackground2"
        Me.picBackground2.Size = New System.Drawing.Size(3000, 500)
        Me.picBackground2.TabIndex = 1
        Me.picBackground2.TabStop = False
        '
        'picBackground1
        '
        Me.picBackground1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.terraBackground1
        Me.picBackground1.Location = New System.Drawing.Point(0, 200)
        Me.picBackground1.Name = "picBackground1"
        Me.picBackground1.Size = New System.Drawing.Size(3000, 225)
        Me.picBackground1.TabIndex = 0
        Me.picBackground1.TabStop = False
        '
        'frmTerraBackground1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.picBludgeonHealth1)
        Me.Controls.Add(Me.picBludgeon1)
        Me.Controls.Add(Me.picBackground2)
        Me.Controls.Add(Me.picBackground1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmTerraBackground1"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "frmTerraBackground1"
        CType(Me.picBludgeonHealth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBludgeon1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBackground2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBackground1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBackground1 As System.Windows.Forms.PictureBox
    Friend WithEvents picBackground2 As System.Windows.Forms.PictureBox
    Friend WithEvents picBludgeonHealth1 As System.Windows.Forms.PictureBox
    Friend WithEvents picBludgeon1 As System.Windows.Forms.PictureBox
End Class
