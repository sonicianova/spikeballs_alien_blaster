﻿Public Class Bludgeon
    'Bludgeon function:
    Public Shared Function act(ByVal alien, ByVal alienHealth, ByVal position)
        'Determine speed based off where Spikeball is:
        If Not GameData.bludgeonDead(position) And GameData.bludgeon(position).Left <= frmTerraLevel1.Width + 400 Then
            If GameData.spikeball.Left < alien.left Then
                'If the spikeball is to the left of the alien then change its speed to go left:
                If GameData.bludgeonFlightSpeed(position) > 0 Then
                    GameData.bludgeonFlightSpeed(position) -= 0.5
                ElseIf GameData.bludgeonFlightSpeed(position) > -25 Then
                    GameData.bludgeonFlightSpeed(position) -= 1.5
                End If
            ElseIf GameData.spikeball.Left + GameData.spikeball.Width > alien.left Then
                'If the spikeball is to the right of the alien then change its speed to go right:
                If GameData.bludgeonFlightSpeed(position) < 0 Then
                    GameData.bludgeonFlightSpeed(position) += 0.5
                ElseIf GameData.bludgeonFlightSpeed(position) < 25 Then
                    GameData.bludgeonFlightSpeed(position) += 1.5
                End If
            End If
            'If they are above spikeball drop their bomb:
            If GameData.spikeball.Top > alien.Top + alien.Height And GameData.spikeball.Left < alien.Left And GameData.spikeball.Left + GameData.spikeball.Width > alien.Left And Not GameData.bombDrop(position) Then
                If GameData.bludgeonFlightSpeed(position) > 0 Then
                    GameData.bombs(position).Left = alien.Left + alien.Width - 85
                Else
                    GameData.bombs(position).Left = alien.Left + 85
                End If
                GameData.bombDrop(position) = True
                GameData.bombs(position).Visible = True
                GameData.bombs(position).Image = My.Resources.bomb
                GameData.bombs(position).Height = 35
                GameData.bombs(position).Top = alien.Top + alien.Height - GameData.bombs(position).Height
            End If
            'Change the picture
            If GameData.bludgeonFlightSpeed(position) < 0 And Not alien.Image Is My.Resources.bludgeonLeft Then
                alien.Image = My.Resources.bludgeonLeft
            ElseIf GameData.bludgeonFlightSpeed(position) > 0 And Not alien.Image Is My.Resources.bludgeonRight Then
                alien.Image = My.Resources.bludgeonRight
            End If
            'If the bomb is dropping calculate gravity on it and if it is exploding:
            If GameData.bombDrop(position) And GameData.bombTimer(position) = 0 Then
                GameData.bombs(position).Top += 25
                If anyWall(GameData.bombs(position)) Or GameData.bombs(position).Bounds.IntersectsWith(GameData.spikeball.Bounds) Then
                    GameData.bombs(position).Image = My.Resources.bombExplosion
                    GameData.bombTimer(position) = 20
                    GameData.bombs(position).Height = 80
                    GameData.bombs(position).Width = 40
                    GameData.bombs(position).Top -= 45
                    GameData.bombs(position).Left -= 10
                    If GameData.bombs(position).Bounds.IntersectsWith(GameData.spikeball.Bounds) Then
                        Spikeball.hurt(3)
                    End If
                End If
            ElseIf GameData.bombDrop(position) Then
                GameData.bombTimer(position) -= 1
                If GameData.bombTimer(position) = 0 Then
                    GameData.bombDrop(position) = False
                    GameData.bombs(position).Visible = False
                End If
            End If
        ElseIf GameData.bludgeonTimer(position) > 0 Then
            GameData.bludgeonTimer(position) -= 1
        ElseIf GameData.bludgeonDead(position) And GameData.bludgeonTimer(position) = 0 Then
            GameData.bludgeon(position).Visible = False
            GameData.bludgeonHealthBar(position).Visible = False
        End If
        Return True
    End Function

    'Boolean method for if an entity is touching any wall:
    Public Shared Function anyWall(ByVal character)
        For i = 0 To GameData.terrain.Length - 1
            If touchingWall(GameData.terrain(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching the wall:
    Public Shared Function touchingWall(ByVal wallName, ByVal character)
        If character.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function hurt(ByVal pain, ByVal position)
        GameData.bludgeonHealth(position) -= pain
        Select Case GameData.bludgeonHealth(position)
            Case 150
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar100
            Case Is >= 135
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar90
            Case Is >= 110
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar80
            Case Is >= 95
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar70
            Case Is >= 80
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar60
            Case Is >= 65
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar50
            Case Is >= 40
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar40
            Case Is >= 25
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar30
            Case Is >= 10
                GameData.bludgeonHealthBar(position).Image = My.Resources.heathbar20
            Case Is > 0
                GameData.bludgeonHealthBar(position).Image = My.Resources.healthbar10
            Case Else
                If GameData.bludgeonHealth(position) <= 0 Then
                    GameData.bludgeonHealthBar(position).Image = My.Resources.healthbar0
                    GameData.bludgeonDead(position) = True
                    If GameData.bludgeonFlightSpeed(position) > 0 Then
                        GameData.bludgeon(position).Image = My.Resources.bludgeonRightExplode
                    Else
                        GameData.bludgeon(position).Image = My.Resources.bludgeonLeftExplode
                    End If
                    GameData.bludgeonTimer(position) = 21
                End If
        End Select
        Return True
    End Function
End Class
