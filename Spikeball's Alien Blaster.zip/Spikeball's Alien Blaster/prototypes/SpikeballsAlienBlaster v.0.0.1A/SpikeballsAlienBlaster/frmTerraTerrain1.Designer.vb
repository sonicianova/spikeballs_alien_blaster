﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTerraTerrain1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picSmallBox3 = New System.Windows.Forms.PictureBox
        Me.picAmmo1 = New System.Windows.Forms.PictureBox
        Me.picSmallBox2 = New System.Windows.Forms.PictureBox
        Me.picDirt3 = New System.Windows.Forms.PictureBox
        Me.picGrass3 = New System.Windows.Forms.PictureBox
        Me.picCoin5 = New System.Windows.Forms.PictureBox
        Me.picCoin4 = New System.Windows.Forms.PictureBox
        Me.picCoin3 = New System.Windows.Forms.PictureBox
        Me.picCoin2 = New System.Windows.Forms.PictureBox
        Me.picCoin1 = New System.Windows.Forms.PictureBox
        Me.picGrassCap1 = New System.Windows.Forms.PictureBox
        Me.picMedkit1 = New System.Windows.Forms.PictureBox
        Me.picStump1 = New System.Windows.Forms.PictureBox
        Me.picGrassDeco4 = New System.Windows.Forms.PictureBox
        Me.picGrassDeco3 = New System.Windows.Forms.PictureBox
        Me.picGrassDeco2 = New System.Windows.Forms.PictureBox
        Me.picGrassDeco1 = New System.Windows.Forms.PictureBox
        Me.picDirt2 = New System.Windows.Forms.PictureBox
        Me.picSmallBox1 = New System.Windows.Forms.PictureBox
        Me.picBigBox1 = New System.Windows.Forms.PictureBox
        Me.picGrass2 = New System.Windows.Forms.PictureBox
        Me.picSlope1 = New System.Windows.Forms.PictureBox
        Me.picDirt1 = New System.Windows.Forms.PictureBox
        Me.picGrass1 = New System.Windows.Forms.PictureBox
        Me.picPlatform1 = New System.Windows.Forms.PictureBox
        CType(Me.picSmallBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAmmo1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSmallBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDirt3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrass3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCoin5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCoin4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCoin3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCoin2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCoin1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrassCap1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMedkit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStump1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrassDeco4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrassDeco3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrassDeco2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrassDeco1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDirt2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSmallBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBigBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrass2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSlope1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDirt1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrass1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPlatform1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picSmallBox3
        '
        Me.picSmallBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSmallBox3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.boxSmall
        Me.picSmallBox3.Location = New System.Drawing.Point(2770, 280)
        Me.picSmallBox3.Name = "picSmallBox3"
        Me.picSmallBox3.Size = New System.Drawing.Size(100, 100)
        Me.picSmallBox3.TabIndex = 71
        Me.picSmallBox3.TabStop = False
        '
        'picAmmo1
        '
        Me.picAmmo1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picAmmo1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.ammo
        Me.picAmmo1.Location = New System.Drawing.Point(2495, 530)
        Me.picAmmo1.Name = "picAmmo1"
        Me.picAmmo1.Size = New System.Drawing.Size(29, 40)
        Me.picAmmo1.TabIndex = 69
        Me.picAmmo1.TabStop = False
        '
        'picSmallBox2
        '
        Me.picSmallBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSmallBox2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.boxSmall
        Me.picSmallBox2.Location = New System.Drawing.Point(2370, 490)
        Me.picSmallBox2.Name = "picSmallBox2"
        Me.picSmallBox2.Size = New System.Drawing.Size(100, 100)
        Me.picSmallBox2.TabIndex = 68
        Me.picSmallBox2.TabStop = False
        '
        'picDirt3
        '
        Me.picDirt3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDirt3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.dirt
        Me.picDirt3.Location = New System.Drawing.Point(2370, 680)
        Me.picDirt3.Name = "picDirt3"
        Me.picDirt3.Size = New System.Drawing.Size(1500, 400)
        Me.picDirt3.TabIndex = 67
        Me.picDirt3.TabStop = False
        '
        'picGrass3
        '
        Me.picGrass3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrass3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.grassFloor
        Me.picGrass3.Location = New System.Drawing.Point(2370, 580)
        Me.picGrass3.Name = "picGrass3"
        Me.picGrass3.Size = New System.Drawing.Size(1500, 100)
        Me.picGrass3.TabIndex = 66
        Me.picGrass3.TabStop = False
        '
        'picCoin5
        '
        Me.picCoin5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCoin5.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.coin
        Me.picCoin5.Location = New System.Drawing.Point(2040, 235)
        Me.picCoin5.Name = "picCoin5"
        Me.picCoin5.Size = New System.Drawing.Size(40, 40)
        Me.picCoin5.TabIndex = 65
        Me.picCoin5.TabStop = False
        '
        'picCoin4
        '
        Me.picCoin4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCoin4.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.coin
        Me.picCoin4.Location = New System.Drawing.Point(1980, 235)
        Me.picCoin4.Name = "picCoin4"
        Me.picCoin4.Size = New System.Drawing.Size(40, 40)
        Me.picCoin4.TabIndex = 64
        Me.picCoin4.TabStop = False
        '
        'picCoin3
        '
        Me.picCoin3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCoin3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.coin
        Me.picCoin3.Location = New System.Drawing.Point(1109, 324)
        Me.picCoin3.Name = "picCoin3"
        Me.picCoin3.Size = New System.Drawing.Size(40, 40)
        Me.picCoin3.TabIndex = 63
        Me.picCoin3.TabStop = False
        '
        'picCoin2
        '
        Me.picCoin2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCoin2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.coin
        Me.picCoin2.Location = New System.Drawing.Point(1049, 324)
        Me.picCoin2.Name = "picCoin2"
        Me.picCoin2.Size = New System.Drawing.Size(40, 40)
        Me.picCoin2.TabIndex = 62
        Me.picCoin2.TabStop = False
        '
        'picCoin1
        '
        Me.picCoin1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picCoin1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.coin
        Me.picCoin1.Location = New System.Drawing.Point(989, 324)
        Me.picCoin1.Name = "picCoin1"
        Me.picCoin1.Size = New System.Drawing.Size(40, 40)
        Me.picCoin1.TabIndex = 61
        Me.picCoin1.TabStop = False
        '
        'picGrassCap1
        '
        Me.picGrassCap1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrassCap1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.grassCapRight
        Me.picGrassCap1.Location = New System.Drawing.Point(3250, 383)
        Me.picGrassCap1.Name = "picGrassCap1"
        Me.picGrassCap1.Size = New System.Drawing.Size(144, 100)
        Me.picGrassCap1.TabIndex = 60
        Me.picGrassCap1.TabStop = False
        '
        'picMedkit1
        '
        Me.picMedkit1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picMedkit1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.medkit
        Me.picMedkit1.Location = New System.Drawing.Point(245, 365)
        Me.picMedkit1.Name = "picMedkit1"
        Me.picMedkit1.Size = New System.Drawing.Size(60, 40)
        Me.picMedkit1.TabIndex = 59
        Me.picMedkit1.TabStop = False
        '
        'picStump1
        '
        Me.picStump1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picStump1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.stump1
        Me.picStump1.Location = New System.Drawing.Point(2000, 295)
        Me.picStump1.Name = "picStump1"
        Me.picStump1.Size = New System.Drawing.Size(83, 100)
        Me.picStump1.TabIndex = 56
        Me.picStump1.TabStop = False
        '
        'picGrassDeco4
        '
        Me.picGrassDeco4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrassDeco4.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.grass
        Me.picGrassDeco4.Location = New System.Drawing.Point(1900, 338)
        Me.picGrassDeco4.Name = "picGrassDeco4"
        Me.picGrassDeco4.Size = New System.Drawing.Size(100, 50)
        Me.picGrassDeco4.TabIndex = 55
        Me.picGrassDeco4.TabStop = False
        '
        'picGrassDeco3
        '
        Me.picGrassDeco3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrassDeco3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.grass
        Me.picGrassDeco3.Location = New System.Drawing.Point(461, 394)
        Me.picGrassDeco3.Name = "picGrassDeco3"
        Me.picGrassDeco3.Size = New System.Drawing.Size(100, 50)
        Me.picGrassDeco3.TabIndex = 54
        Me.picGrassDeco3.TabStop = False
        '
        'picGrassDeco2
        '
        Me.picGrassDeco2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrassDeco2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.grass
        Me.picGrassDeco2.Location = New System.Drawing.Point(361, 394)
        Me.picGrassDeco2.Name = "picGrassDeco2"
        Me.picGrassDeco2.Size = New System.Drawing.Size(100, 50)
        Me.picGrassDeco2.TabIndex = 53
        Me.picGrassDeco2.TabStop = False
        '
        'picGrassDeco1
        '
        Me.picGrassDeco1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrassDeco1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.grass
        Me.picGrassDeco1.Location = New System.Drawing.Point(1016, 394)
        Me.picGrassDeco1.Name = "picGrassDeco1"
        Me.picGrassDeco1.Size = New System.Drawing.Size(100, 50)
        Me.picGrassDeco1.TabIndex = 52
        Me.picGrassDeco1.TabStop = False
        '
        'picDirt2
        '
        Me.picDirt2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDirt2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.dirt
        Me.picDirt2.Location = New System.Drawing.Point(1500, 483)
        Me.picDirt2.Name = "picDirt2"
        Me.picDirt2.Size = New System.Drawing.Size(1870, 500)
        Me.picDirt2.TabIndex = 51
        Me.picDirt2.TabStop = False
        '
        'picSmallBox1
        '
        Me.picSmallBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSmallBox1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.boxSmall
        Me.picSmallBox1.Location = New System.Drawing.Point(0, 148)
        Me.picSmallBox1.Name = "picSmallBox1"
        Me.picSmallBox1.Size = New System.Drawing.Size(100, 100)
        Me.picSmallBox1.TabIndex = 50
        Me.picSmallBox1.TabStop = False
        '
        'picBigBox1
        '
        Me.picBigBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picBigBox1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.boxLarge
        Me.picBigBox1.Location = New System.Drawing.Point(0, 248)
        Me.picBigBox1.Name = "picBigBox1"
        Me.picBigBox1.Size = New System.Drawing.Size(200, 200)
        Me.picBigBox1.TabIndex = 49
        Me.picBigBox1.TabStop = False
        '
        'picGrass2
        '
        Me.picGrass2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrass2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.grassFloor
        Me.picGrass2.Location = New System.Drawing.Point(1750, 383)
        Me.picGrass2.Name = "picGrass2"
        Me.picGrass2.Size = New System.Drawing.Size(1500, 100)
        Me.picGrass2.TabIndex = 48
        Me.picGrass2.TabStop = False
        '
        'picSlope1
        '
        Me.picSlope1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSlope1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.rightSlope
        Me.picSlope1.Location = New System.Drawing.Point(1500, 383)
        Me.picSlope1.Name = "picSlope1"
        Me.picSlope1.Size = New System.Drawing.Size(250, 100)
        Me.picSlope1.TabIndex = 47
        Me.picSlope1.TabStop = False
        '
        'picDirt1
        '
        Me.picDirt1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDirt1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.dirt
        Me.picDirt1.Location = New System.Drawing.Point(0, 533)
        Me.picDirt1.Name = "picDirt1"
        Me.picDirt1.Size = New System.Drawing.Size(1500, 400)
        Me.picDirt1.TabIndex = 46
        Me.picDirt1.TabStop = False
        '
        'picGrass1
        '
        Me.picGrass1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrass1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.grassFloor
        Me.picGrass1.Location = New System.Drawing.Point(0, 433)
        Me.picGrass1.Name = "picGrass1"
        Me.picGrass1.Size = New System.Drawing.Size(1500, 100)
        Me.picGrass1.TabIndex = 45
        Me.picGrass1.TabStop = False
        '
        'picPlatform1
        '
        Me.picPlatform1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picPlatform1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.platform1
        Me.picPlatform1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picPlatform1.Location = New System.Drawing.Point(2670, 380)
        Me.picPlatform1.Name = "picPlatform1"
        Me.picPlatform1.Size = New System.Drawing.Size(240, 200)
        Me.picPlatform1.TabIndex = 70
        Me.picPlatform1.TabStop = False
        '
        'frmTerraTerrain1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Salmon
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.picSmallBox3)
        Me.Controls.Add(Me.picAmmo1)
        Me.Controls.Add(Me.picSmallBox2)
        Me.Controls.Add(Me.picDirt3)
        Me.Controls.Add(Me.picGrass3)
        Me.Controls.Add(Me.picCoin5)
        Me.Controls.Add(Me.picCoin4)
        Me.Controls.Add(Me.picCoin3)
        Me.Controls.Add(Me.picCoin2)
        Me.Controls.Add(Me.picCoin1)
        Me.Controls.Add(Me.picGrassCap1)
        Me.Controls.Add(Me.picMedkit1)
        Me.Controls.Add(Me.picStump1)
        Me.Controls.Add(Me.picGrassDeco4)
        Me.Controls.Add(Me.picGrassDeco3)
        Me.Controls.Add(Me.picGrassDeco2)
        Me.Controls.Add(Me.picGrassDeco1)
        Me.Controls.Add(Me.picDirt2)
        Me.Controls.Add(Me.picSmallBox1)
        Me.Controls.Add(Me.picBigBox1)
        Me.Controls.Add(Me.picGrass2)
        Me.Controls.Add(Me.picSlope1)
        Me.Controls.Add(Me.picDirt1)
        Me.Controls.Add(Me.picGrass1)
        Me.Controls.Add(Me.picPlatform1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmTerraTerrain1"
        Me.ShowInTaskbar = False
        Me.Text = "Spikeball's Alien Blaster"
        Me.TransparencyKey = System.Drawing.Color.Salmon
        CType(Me.picSmallBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAmmo1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSmallBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDirt3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrass3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCoin5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCoin4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCoin3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCoin2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCoin1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrassCap1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMedkit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStump1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrassDeco4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrassDeco3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrassDeco2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrassDeco1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDirt2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSmallBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBigBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrass2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSlope1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDirt1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrass1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPlatform1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picDirt1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrass1 As System.Windows.Forms.PictureBox
    Friend WithEvents picSlope1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrass2 As System.Windows.Forms.PictureBox
    Friend WithEvents picBigBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents picSmallBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents picDirt2 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrassDeco1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrassDeco2 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrassDeco3 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrassDeco4 As System.Windows.Forms.PictureBox
    Friend WithEvents picStump1 As System.Windows.Forms.PictureBox
    Friend WithEvents picMedkit1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrassCap1 As System.Windows.Forms.PictureBox
    Friend WithEvents picCoin1 As System.Windows.Forms.PictureBox
    Friend WithEvents picCoin2 As System.Windows.Forms.PictureBox
    Friend WithEvents picCoin3 As System.Windows.Forms.PictureBox
    Friend WithEvents picCoin4 As System.Windows.Forms.PictureBox
    Friend WithEvents picCoin5 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrass3 As System.Windows.Forms.PictureBox
    Friend WithEvents picDirt3 As System.Windows.Forms.PictureBox
    Friend WithEvents picSmallBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents picAmmo1 As System.Windows.Forms.PictureBox
    Friend WithEvents picPlatform1 As System.Windows.Forms.PictureBox
    Friend WithEvents picSmallBox3 As System.Windows.Forms.PictureBox
End Class
