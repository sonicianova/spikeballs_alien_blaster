﻿Public Class frmFade

    Public fadeTimer As Integer = -1

    Private Sub frmFade_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2

        tmrFade.Start()
    End Sub

    Private Sub tmrFade_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrFade.Tick
        If fadeTimer = -1 Then
            fadeTimer = 25
        End If
        If fadeTimer = 0 Then
            frmBackground.Show()
            frmMiniMap.Show()
            frmGame.Close()
            fadeTimer -= 2
        ElseIf fadeTimer > 0 Then
            fadeTimer -= 1
            Me.Opacity += 0.04
        ElseIf fadeTimer <= -50 Then
            Me.Close()
        Else
            fadeTimer -= 1
            Me.Opacity -= 0.02
        End If
    End Sub
End Class