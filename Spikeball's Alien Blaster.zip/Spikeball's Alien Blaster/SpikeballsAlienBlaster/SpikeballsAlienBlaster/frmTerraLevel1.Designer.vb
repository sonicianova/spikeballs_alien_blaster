﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTerraLevel1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.tmrGameTick = New System.Windows.Forms.Timer(Me.components)
        Me.btnClose = New System.Windows.Forms.Button
        Me.picTalkBox = New System.Windows.Forms.PictureBox
        Me.picBullet10 = New System.Windows.Forms.PictureBox
        Me.picBullet8 = New System.Windows.Forms.PictureBox
        Me.picBullet9 = New System.Windows.Forms.PictureBox
        Me.picBullet7 = New System.Windows.Forms.PictureBox
        Me.picBullet6 = New System.Windows.Forms.PictureBox
        Me.picBullet5 = New System.Windows.Forms.PictureBox
        Me.picBullet4 = New System.Windows.Forms.PictureBox
        Me.picBullet3 = New System.Windows.Forms.PictureBox
        Me.picBullet2 = New System.Windows.Forms.PictureBox
        Me.picBullet1 = New System.Windows.Forms.PictureBox
        Me.picSpikeballHealth = New System.Windows.Forms.PictureBox
        Me.picSpikeball = New System.Windows.Forms.PictureBox
        Me.picDefAlienHealth1 = New System.Windows.Forms.PictureBox
        Me.picDefAlien1 = New System.Windows.Forms.PictureBox
        CType(Me.picTalkBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBullet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSpikeballHealth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSpikeball, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDefAlienHealth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDefAlien1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrGameTick
        '
        Me.tmrGameTick.Interval = 20
        '
        'btnClose
        '
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Black
        Me.btnClose.FlatAppearance.BorderSize = 0
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Red
        Me.btnClose.Location = New System.Drawing.Point(1239, 12)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(29, 27)
        Me.btnClose.TabIndex = 40
        Me.btnClose.TabStop = False
        Me.btnClose.Text = "X"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'picTalkBox
        '
        Me.picTalkBox.BackColor = System.Drawing.Color.Transparent
        Me.picTalkBox.Location = New System.Drawing.Point(12, 12)
        Me.picTalkBox.Name = "picTalkBox"
        Me.picTalkBox.Size = New System.Drawing.Size(400, 100)
        Me.picTalkBox.TabIndex = 39
        Me.picTalkBox.TabStop = False
        Me.picTalkBox.Visible = False
        '
        'picBullet10
        '
        Me.picBullet10.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet10.Location = New System.Drawing.Point(655, 384)
        Me.picBullet10.Name = "picBullet10"
        Me.picBullet10.Size = New System.Drawing.Size(25, 5)
        Me.picBullet10.TabIndex = 31
        Me.picBullet10.TabStop = False
        Me.picBullet10.Visible = False
        '
        'picBullet8
        '
        Me.picBullet8.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet8.Location = New System.Drawing.Point(647, 376)
        Me.picBullet8.Name = "picBullet8"
        Me.picBullet8.Size = New System.Drawing.Size(25, 5)
        Me.picBullet8.TabIndex = 30
        Me.picBullet8.TabStop = False
        Me.picBullet8.Visible = False
        '
        'picBullet9
        '
        Me.picBullet9.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet9.Location = New System.Drawing.Point(639, 368)
        Me.picBullet9.Name = "picBullet9"
        Me.picBullet9.Size = New System.Drawing.Size(25, 5)
        Me.picBullet9.TabIndex = 29
        Me.picBullet9.TabStop = False
        Me.picBullet9.Visible = False
        '
        'picBullet7
        '
        Me.picBullet7.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet7.Location = New System.Drawing.Point(631, 360)
        Me.picBullet7.Name = "picBullet7"
        Me.picBullet7.Size = New System.Drawing.Size(25, 5)
        Me.picBullet7.TabIndex = 28
        Me.picBullet7.TabStop = False
        Me.picBullet7.Visible = False
        '
        'picBullet6
        '
        Me.picBullet6.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet6.Location = New System.Drawing.Point(623, 352)
        Me.picBullet6.Name = "picBullet6"
        Me.picBullet6.Size = New System.Drawing.Size(25, 5)
        Me.picBullet6.TabIndex = 27
        Me.picBullet6.TabStop = False
        Me.picBullet6.Visible = False
        '
        'picBullet5
        '
        Me.picBullet5.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet5.Location = New System.Drawing.Point(615, 344)
        Me.picBullet5.Name = "picBullet5"
        Me.picBullet5.Size = New System.Drawing.Size(25, 5)
        Me.picBullet5.TabIndex = 26
        Me.picBullet5.TabStop = False
        Me.picBullet5.Visible = False
        '
        'picBullet4
        '
        Me.picBullet4.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet4.Location = New System.Drawing.Point(607, 336)
        Me.picBullet4.Name = "picBullet4"
        Me.picBullet4.Size = New System.Drawing.Size(25, 5)
        Me.picBullet4.TabIndex = 25
        Me.picBullet4.TabStop = False
        Me.picBullet4.Visible = False
        '
        'picBullet3
        '
        Me.picBullet3.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet3.Location = New System.Drawing.Point(599, 328)
        Me.picBullet3.Name = "picBullet3"
        Me.picBullet3.Size = New System.Drawing.Size(25, 5)
        Me.picBullet3.TabIndex = 24
        Me.picBullet3.TabStop = False
        Me.picBullet3.Visible = False
        '
        'picBullet2
        '
        Me.picBullet2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet2.Location = New System.Drawing.Point(591, 320)
        Me.picBullet2.Name = "picBullet2"
        Me.picBullet2.Size = New System.Drawing.Size(25, 5)
        Me.picBullet2.TabIndex = 23
        Me.picBullet2.TabStop = False
        Me.picBullet2.Visible = False
        '
        'picBullet1
        '
        Me.picBullet1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.bullet
        Me.picBullet1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picBullet1.Location = New System.Drawing.Point(665, 395)
        Me.picBullet1.Name = "picBullet1"
        Me.picBullet1.Size = New System.Drawing.Size(25, 5)
        Me.picBullet1.TabIndex = 22
        Me.picBullet1.TabStop = False
        Me.picBullet1.Visible = False
        '
        'picSpikeballHealth
        '
        Me.picSpikeballHealth.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picSpikeballHealth.Location = New System.Drawing.Point(55, 275)
        Me.picSpikeballHealth.Name = "picSpikeballHealth"
        Me.picSpikeballHealth.Size = New System.Drawing.Size(100, 10)
        Me.picSpikeballHealth.TabIndex = 12
        Me.picSpikeballHealth.TabStop = False
        '
        'picSpikeball
        '
        Me.picSpikeball.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSpikeball.BackColor = System.Drawing.Color.Transparent
        Me.picSpikeball.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.spikeballSpinRight
        Me.picSpikeball.Location = New System.Drawing.Point(43, 291)
        Me.picSpikeball.Name = "picSpikeball"
        Me.picSpikeball.Size = New System.Drawing.Size(125, 125)
        Me.picSpikeball.TabIndex = 11
        Me.picSpikeball.TabStop = False
        '
        'picDefAlienHealth1
        '
        Me.picDefAlienHealth1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDefAlienHealth1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.heathbar100
        Me.picDefAlienHealth1.Location = New System.Drawing.Point(1143, 292)
        Me.picDefAlienHealth1.Name = "picDefAlienHealth1"
        Me.picDefAlienHealth1.Size = New System.Drawing.Size(100, 10)
        Me.picDefAlienHealth1.TabIndex = 42
        Me.picDefAlienHealth1.TabStop = False
        '
        'picDefAlien1
        '
        Me.picDefAlien1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDefAlien1.BackColor = System.Drawing.Color.Transparent
        Me.picDefAlien1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.defAlienStandLeft
        Me.picDefAlien1.Location = New System.Drawing.Point(1118, 308)
        Me.picDefAlien1.Name = "picDefAlien1"
        Me.picDefAlien1.Size = New System.Drawing.Size(150, 125)
        Me.picDefAlien1.TabIndex = 41
        Me.picDefAlien1.TabStop = False
        '
        'frmTerraLevel1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Salmon
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.picDefAlienHealth1)
        Me.Controls.Add(Me.picDefAlien1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.picTalkBox)
        Me.Controls.Add(Me.picBullet10)
        Me.Controls.Add(Me.picBullet8)
        Me.Controls.Add(Me.picBullet9)
        Me.Controls.Add(Me.picBullet7)
        Me.Controls.Add(Me.picBullet6)
        Me.Controls.Add(Me.picBullet5)
        Me.Controls.Add(Me.picBullet4)
        Me.Controls.Add(Me.picBullet3)
        Me.Controls.Add(Me.picBullet2)
        Me.Controls.Add(Me.picBullet1)
        Me.Controls.Add(Me.picSpikeballHealth)
        Me.Controls.Add(Me.picSpikeball)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "frmTerraLevel1"
        Me.Text = "frmTerraLevel1"
        Me.TransparencyKey = System.Drawing.Color.Salmon
        CType(Me.picTalkBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBullet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSpikeballHealth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSpikeball, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDefAlienHealth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDefAlien1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picSpikeballHealth As System.Windows.Forms.PictureBox
    Friend WithEvents picSpikeball As System.Windows.Forms.PictureBox
    Friend WithEvents tmrGameTick As System.Windows.Forms.Timer
    Friend WithEvents picBullet10 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet8 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet9 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet7 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet6 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet5 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet4 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet3 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet2 As System.Windows.Forms.PictureBox
    Friend WithEvents picBullet1 As System.Windows.Forms.PictureBox
    Friend WithEvents picTalkBox As System.Windows.Forms.PictureBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents picDefAlienHealth1 As System.Windows.Forms.PictureBox
    Friend WithEvents picDefAlien1 As System.Windows.Forms.PictureBox
End Class
