﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMiniMap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnClose = New System.Windows.Forms.Button
        Me.tmrTick = New System.Windows.Forms.Timer(Me.components)
        Me.picLock5 = New System.Windows.Forms.PictureBox
        Me.picLock4 = New System.Windows.Forms.PictureBox
        Me.picLock3 = New System.Windows.Forms.PictureBox
        Me.picLock2 = New System.Windows.Forms.PictureBox
        Me.picLock1 = New System.Windows.Forms.PictureBox
        Me.picReticle = New System.Windows.Forms.PictureBox
        Me.picTerraMinimapIcon = New System.Windows.Forms.PictureBox
        CType(Me.picLock5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLock4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLock3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLock2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLock1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picReticle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTerraMinimapIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClose.BackColor = System.Drawing.Color.Black
        Me.btnClose.FlatAppearance.BorderSize = 0
        Me.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.Red
        Me.btnClose.Location = New System.Drawing.Point(1239, 12)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(29, 27)
        Me.btnClose.TabIndex = 5
        Me.btnClose.TabStop = False
        Me.btnClose.Text = "X"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'tmrTick
        '
        Me.tmrTick.Interval = 20
        '
        'picLock5
        '
        Me.picLock5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picLock5.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.lock
        Me.picLock5.Location = New System.Drawing.Point(741, 296)
        Me.picLock5.Name = "picLock5"
        Me.picLock5.Size = New System.Drawing.Size(20, 27)
        Me.picLock5.TabIndex = 19
        Me.picLock5.TabStop = False
        Me.picLock5.Visible = False
        '
        'picLock4
        '
        Me.picLock4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picLock4.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.lock
        Me.picLock4.Location = New System.Drawing.Point(730, 348)
        Me.picLock4.Name = "picLock4"
        Me.picLock4.Size = New System.Drawing.Size(20, 27)
        Me.picLock4.TabIndex = 18
        Me.picLock4.TabStop = False
        Me.picLock4.Visible = False
        '
        'picLock3
        '
        Me.picLock3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picLock3.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.lock
        Me.picLock3.Location = New System.Drawing.Point(682, 405)
        Me.picLock3.Name = "picLock3"
        Me.picLock3.Size = New System.Drawing.Size(20, 27)
        Me.picLock3.TabIndex = 17
        Me.picLock3.TabStop = False
        Me.picLock3.Visible = False
        '
        'picLock2
        '
        Me.picLock2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picLock2.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.lock
        Me.picLock2.Location = New System.Drawing.Point(458, 288)
        Me.picLock2.Name = "picLock2"
        Me.picLock2.Size = New System.Drawing.Size(20, 27)
        Me.picLock2.TabIndex = 16
        Me.picLock2.TabStop = False
        Me.picLock2.Visible = False
        '
        'picLock1
        '
        Me.picLock1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picLock1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.lock
        Me.picLock1.Location = New System.Drawing.Point(453, 345)
        Me.picLock1.Name = "picLock1"
        Me.picLock1.Size = New System.Drawing.Size(20, 27)
        Me.picLock1.TabIndex = 15
        Me.picLock1.TabStop = False
        Me.picLock1.Visible = False
        '
        'picReticle
        '
        Me.picReticle.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picReticle.BackColor = System.Drawing.Color.Transparent
        Me.picReticle.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.standardReticle
        Me.picReticle.Location = New System.Drawing.Point(603, 323)
        Me.picReticle.Name = "picReticle"
        Me.picReticle.Size = New System.Drawing.Size(75, 75)
        Me.picReticle.TabIndex = 7
        Me.picReticle.TabStop = False
        '
        'picTerraMinimapIcon
        '
        Me.picTerraMinimapIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picTerraMinimapIcon.Location = New System.Drawing.Point(119, 403)
        Me.picTerraMinimapIcon.Name = "picTerraMinimapIcon"
        Me.picTerraMinimapIcon.Size = New System.Drawing.Size(140, 182)
        Me.picTerraMinimapIcon.TabIndex = 6
        Me.picTerraMinimapIcon.TabStop = False
        '
        'frmMiniMap
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.BlanchedAlmond
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.picLock5)
        Me.Controls.Add(Me.picLock4)
        Me.Controls.Add(Me.picLock3)
        Me.Controls.Add(Me.picLock2)
        Me.Controls.Add(Me.picLock1)
        Me.Controls.Add(Me.picReticle)
        Me.Controls.Add(Me.picTerraMinimapIcon)
        Me.Controls.Add(Me.btnClose)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "frmMiniMap"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Spikeball's Alien Blaster"
        Me.TransparencyKey = System.Drawing.Color.BlanchedAlmond
        CType(Me.picLock5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLock4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLock3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLock2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLock1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picReticle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTerraMinimapIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents picTerraMinimapIcon As System.Windows.Forms.PictureBox
    Friend WithEvents picReticle As System.Windows.Forms.PictureBox
    Public WithEvents tmrTick As System.Windows.Forms.Timer
    Friend WithEvents picLock5 As System.Windows.Forms.PictureBox
    Friend WithEvents picLock4 As System.Windows.Forms.PictureBox
    Friend WithEvents picLock3 As System.Windows.Forms.PictureBox
    Friend WithEvents picLock2 As System.Windows.Forms.PictureBox
    Friend WithEvents picLock1 As System.Windows.Forms.PictureBox
End Class
