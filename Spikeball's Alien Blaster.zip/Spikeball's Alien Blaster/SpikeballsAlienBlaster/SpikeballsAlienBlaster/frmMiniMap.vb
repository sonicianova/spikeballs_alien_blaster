﻿Public Class frmMiniMap

    Dim leftKey As Boolean = False
    Dim rightKey As Boolean = False
    Dim downKey As Boolean = False
    Dim upKey As Boolean = False
    Dim planets() As PictureBox
    Dim animationTimer As Integer = 0
    Dim reticle As String = "standard"
    Dim touching As Boolean = False
    Dim aKey As Boolean = False
    Dim selector As Integer = -1
    Dim transparencyTimer As Integer = -1
    Dim locks() As PictureBox
    Dim selectedLevel As Integer = 1
    Dim planetMap As Boolean = False

    'KEY DETECTION
    '=================================================================='
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        'Test if either of the keys have been pressed.
        'Set their value to true and override default button tabbing.
        Select Case keyData
            Case Keys.Right
                rightKey = True
            Case Keys.Left
                leftKey = True
            Case Keys.Down
                downKey = True
            Case Keys.Up
                upKey = True
            Case Keys.A
                aKey = True
        End Select
    End Function

    Private Sub frmMainMenu_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        'Test if either of the keys have been released:
        e.SuppressKeyPress = True
        e.Handled = True
        Select Case e.KeyCode
            Case Keys.Right
                rightKey = False
            Case Keys.Left
                leftKey = False
            Case Keys.Down
                downKey = False
            Case Keys.Up
                upKey = False
            Case Keys.A
                aKey = False
        End Select
    End Sub

    Private Sub frmMiniMap_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Fill the array:
        locks = New PictureBox() {picLock1, picLock2, picLock3, picLock4, picLock5}

        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2

        'Create the planets array:
        planets = New PictureBox() {picTerraMinimapIcon}

        'Start the timer
        tmrTick.Start()

        'Bring the fade form to the top:
        If My.Settings.tutorialPlayed Then
            frmFade.fadeTimer = -26
        Else
            frmFade.Hide()
            frmFade.Show()
        End If

        'If the player is bound to Terra bring that map up instead of the system map:
        If My.Settings.planetsUnlocked = 1 Then
            frmBackground.picPlanet.Visible = True
            For i = 0 To planets.Length - 1
                planets(i).Visible = False
                frmBackground.planets(i).Visible = False
            Next
            picReticle.Visible = False
            picLock1.Visible = True
            picLock2.Visible = True
            picLock3.Visible = True
            picLock4.Visible = True
            picLock5.Visible = True
            planetMap = True
        End If

        'Break each of the locks on the levels that are unlocked:
        For x = 1 To My.Settings.terraLevels - 1
            locks(x - 1).Visible = False
        Next

        AcceptButton = btnClose
    End Sub

    Private Sub tmrTick_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrTick.Tick
        'Key detection:
        If leftKey Then
            picReticle.Left -= 5
        End If
        If rightKey Then
            picReticle.Left += 5
        End If
        If upKey Then
            picReticle.Top -= 5
        End If
        If downKey Then
            picReticle.Top += 5
        End If
        'If the player is on the planet map and the a key is pressed, queue for their current level:
        If aKey And planetMap Then
            If selectedLevel = 1 Then
                frmBackground.Close()
                frmTerraTerrain1.Show()
                frmTerraLevel1.Show()
                Me.Close()
            End If
        End If

        'Reset the touching variable.
        touching = False
        For i = 0 To planets.Length - 1
            'If the reticle is touching any of the planets then change the reticle image if needed. If 'a' is pressed on an 
            If picReticle.Bounds.IntersectsWith(planets(i).Bounds) Then
                If reticle = "standard" Then
                    animationTimer = 10
                    picReticle.Image = My.Resources.reticleExpand
                    reticle = "expand"
                End If
                If aKey Then
                    selector = i
                End If
                touching = True
            End If
        Next
        If animationTimer > 0 Then
            animationTimer -= 1
            If animationTimer = 0 Then
                If reticle = "expand" Then
                    picReticle.Image = My.Resources.reticleSelect
                    reticle = "select"
                ElseIf reticle = "retract" Then
                    picReticle.Image = My.Resources.standardReticle
                    reticle = "standard"
                End If
            End If
        End If
        If Not touching Then
            If reticle = "select" Then
                animationTimer = 10
                picReticle.Image = My.Resources.reticleRetract
                reticle = "retract"
            End If
        End If

        'If the a key has been pressed then pull up the menu of the selected planet:
        If selector > -1 Then
            If transparencyTimer = -1 Then
                'If the transparency timer has not yet been called then set it to the proper number, signalling its initiation.
                transparencyTimer = 26
            ElseIf transparencyTimer > 0 Then
                'If the transparency timer has not run out then decrease it, change the visibility of the selected icon, and if it equals 0 after that then pull up the planet.
                transparencyTimer -= 1
                Select Case selector
                    Case 0
                        frmBackground.picPlanet.Image = My.Resources.Level1Act1
                        If transparencyTimer Mod 5 = 0 Then
                            If picTerraMinimapIcon.Visible Then
                                picTerraMinimapIcon.Visible = False
                                frmBackground.picTerraMinimapIcon.Visible = False
                            Else
                                picTerraMinimapIcon.Visible = True
                                frmBackground.picTerraMinimapIcon.Visible = True
                            End If
                        End If
                End Select
                If transparencyTimer = 0 Then
                    'If the timer has run out then make the main planet visible and hide everything else
                    frmBackground.picPlanet.Visible = True
                    For i = 0 To planets.Length - 1
                        planets(i).Visible = False
                        frmBackground.planets(i).Visible = False
                    Next
                    picReticle.Visible = False
                    picLock1.Visible = True
                    picLock2.Visible = True
                    picLock3.Visible = True
                    picLock4.Visible = True
                    picLock5.Visible = True
                    planetMap = True
                End If
            End If
        End If
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        'Close the form:
        frmBackground.Close()
        Close()
    End Sub

End Class