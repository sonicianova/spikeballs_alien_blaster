﻿Public Class DefaultAlien
    Public Shared rollPain As Integer = 0
    'Default alien function:
    Public Shared Function act(ByVal alien, ByVal alienHealth, ByVal position)
        'If the alien is not dead then perform AI:
        If Not GameData.enemyDead(position) Then
            'Find the direction of Spikeball and move toward it.
            If GameData.attack And GameData.spikeball.Left + GameData.spikeball.Width < alien.Left And alien.Left > 0 - GameData.xPos Then
                'If Spikeball is to the left move left:
                GameData.enemyMovement(position) -= GameData.enemySpeeds(position)
                If Not GameData.enemyCostume(position) = "defAlienWalkLeft" Then
                    alien.Image = My.Resources.defAlienWalkLeft
                    GameData.enemyCostume(position) = "defAlienWalkLeft"
                End If
            ElseIf GameData.attack And GameData.spikeball.Left > alien.Left + alien.Width And alien.Left < frmTerraLevel1.Width Then
                'If spikeball is to the right move right:
                GameData.enemyMovement(position) += GameData.enemySpeeds(position)
                If Not GameData.enemyCostume(position) = "defAlienWalkRight" Then
                    alien.Image = My.Resources.defAlienWalkRight
                    GameData.enemyCostume(position) = "defAlienWalkRight"
                End If
            ElseIf Not GameData.enemyCostume(position) = "defAlienAttackRight" And Not GameData.enemyCostume(position) = "defAlienAttackLeft" And alien.Bounds.IntersectsWith(GameData.spikeball.Bounds) Then
                GameData.attackCooldown(position) = 20
                If GameData.spikeball.Left < alien.Left Then
                    If Not GameData.enemyCostume(position) = "defAlienAttackLeft" Then
                        alien.Image = My.Resources.defAlienAttackLeft
                        GameData.enemyCostume(position) = "defAlienAttackLeft"
                    End If
                ElseIf GameData.spikeball.Left + GameData.spikeball.Width > alien.Left Then
                    If Not GameData.enemyCostume(position) = "defAlienAttackRight" Then
                        alien.Image = My.Resources.defAlienAttackRight
                        GameData.enemyCostume(position) = "defAlienAttackRight"
                    End If
                End If
            End If
            For i = 0 To GameData.terrain.Length - 1
                wallDetect(GameData.terrain(i), alien, position)
            Next
            'Test if they're pushing against another alien:
            For i = 0 To GameData.aliens.Length - 1
                wallDetect(GameData.aliens(i), alien, position)
            Next
            'Test if Spikeball is pushing them:
            If GameData.attack And GameData.spikeball.Bounds.IntersectsWith(alien.Bounds) Then
                If GameData.rolling And GameData.transitionTimer <= 0 Then
                    'If the player is rolling into them then start the knockback timer:
                    If Not GameData.knockback(position) Then
                        GameData.knockbackTimer(position) = 25
                        GameData.knockback(position) = True
                        GameData.knockbackDirection(position) = GameData.direction
                    End If
                    GameData.attackCooldown(position) = 7
                    If rollPain <= 0 Then
                        rollPain = 30
                        hurt(20, position)
                    End If
                Else
                    'Attack the player if the attack cooldown is 0:
                    If GameData.attackCooldown(position) <= 0 Then
                        If GameData.spikeball.Left < alien.Left Then
                            If Not GameData.enemyCostume(position) = "defAlienAttackLeft" Then
                                alien.Image = My.Resources.defAlienAttackLeft
                                GameData.enemyCostume(position) = "defAlienAttackLeft"
                            End If
                        ElseIf GameData.spikeball.Left + GameData.spikeball.Width > alien.Left Then
                            If Not GameData.enemyCostume(position) = "defAlienAttackRight" Then
                                alien.Image = My.Resources.defAlienAttackRight
                                GameData.enemyCostume(position) = "defAlienAttackRight"
                            End If
                        End If
                        GameData.attackCooldown(position) = 30
                        Spikeball.hurt(2)
                    End If
                End If
            End If
            GameData.attackCooldown(position) -= 1
            rollPain -= 1
            'If the alien is being knocked back then knock them back:
            If GameData.knockback(position) Then
                If GameData.knockbackTimer(position) > 0 Then
                    GameData.knockbackTimer(position) -= 1
                Else
                    If GameData.enemyJumpHeight(position) > -5 Then
                        GameData.enemyJumpHeight(position) -= 1
                        GameData.knockBackModifier(position) -= 0.05
                    End If
                End If
                alien.Top -= GameData.enemyJumpHeight(position)
                alienHealth.Top -= GameData.enemyJumpHeight(position)
                'If the alien is not touching one of the possible walls, move them to the left or right.
                If Not anyWall(alien) And Not anyAlien(alien) Then
                    If GameData.knockbackDirection(position) = "right" Then
                        GameData.enemyMovement(position) += GameData.enemySpeeds(position) * GameData.knockBackModifier(position) * 1.2
                    ElseIf alien.Left > 0 - GameData.xPos Then
                        GameData.enemyMovement(position) -= GameData.enemySpeeds(position) * GameData.knockBackModifier(position) * 1.2
                    End If
                End If
            End If
            'If the alien is not affected by gravity make them fall:
            If Not anyWall(alien) And Not GameData.knockback(position) Then
                alien.Top += 5
                alienHealth.Top += 5
            End If
            'If the alien has fallen off the screen kill them:
            If alien.Top >= frmTerraLevel1.Height Then
                hurt(100, position)
            End If
            For i = 0 To GameData.slopes.Length - 1
                entitySlopeDetectionRight(GameData.slopes(i), position)
            Next
        End If
        Return True
    End Function

    'WALL DETECT
    Public Shared Function wallDetect(ByVal wallName, ByVal alien, ByVal position)

        If alien.Bounds.IntersectsWith(wallName.Bounds) Then
            If alien.Top > wallName.Top + wallName.Height / 1.2 Then
                'Negate top movement
                alien.Top += GameData.enemyJumpHeight(position)
                GameData.alienHealth(position).Top += GameData.enemyJumpHeight(position)
                'GameData.enemyJumpHeight(position) = 0
                GameData.enemyJumpHeight(position) = -3
                Return True
            ElseIf alien.Top < wallName.Top - 100 Then
                'Stop the player from falling:
                GameData.enemyJumpHeight(position) = 5
                GameData.knockback(position) = False
                GameData.knockBackModifier(position) = 3.5
                Return True
            ElseIf alien.Left < wallName.Left And GameData.enemyMovement(position) > 0 Then
                'Negate right movement:
                If alien.Top < wallName.Top + wallName.Height And Not anySlope(alien) Then
                    GameData.enemyMovement(position) = 0
                    GameData.knockbackTimer(position) = 0
                    alien.Image = My.Resources.defAlienStandRight
                    GameData.enemyCostume(position) = "stand"
                    If GameData.knockback(position) Then
                        GameData.knockBackModifier(position) /= 1.5
                        GameData.enemyMovement(position) -= GameData.enemySpeeds(position) * GameData.knockBackModifier(position)
                        GameData.knockbackDirection(position) = "left"
                        GameData.enemyJumpHeight(position) = 0
                    End If
                    Return True
                End If
            ElseIf alien.Left > wallName.Left And GameData.enemyMovement(position) < 0 Then
                'Negate left movement:
                If alien.Top < wallName.Top + wallName.Height And Not anySlope(alien) Then
                    GameData.enemyMovement(position) = 0
                    GameData.knockbackTimer(position) = 0
                    alien.Image = My.Resources.defAlienStandLeft
                    GameData.enemyCostume(position) = "stand"
                    Return True
                    If GameData.knockback(position) Then
                        GameData.knockBackModifier(position) /= 1.5
                        GameData.enemyMovement(position) += GameData.enemySpeeds(position) * GameData.knockBackModifier(position)
                        GameData.knockbackDirection(position) = "right"
                        GameData.enemyJumpHeight(position) = 0
                    End If
                End If
            Else
                Return False
            End If
            End If
        Return True

    End Function

    'Entity slope detection:
    Public Shared Function entitySlopeDetectionRight(ByVal wallName, ByVal position)
        If GameData.aliens(position).Bounds.IntersectsWith(wallName.Bounds) Then
            'If the gravity on the slope is running fall him onto the correct spot on the slope.
            If GameData.gravitySlopes(position) > -1 And GameData.aliens(position).Top <= wallName.Top + (25 - (GameData.aliens(position).Left - wallName.Left) * 0.25) - GameData.aliens(position).Height Then
                GameData.gravitySlopes(position) -= 1
                GameData.aliens(position).Top += (25 - (GameData.aliens(position).Left - wallName.Left) * 0.25) / 3
                GameData.alienHealth(position).Top += (25 - (GameData.aliens(position).Left - wallName.Left) * 0.25) / 3
                GameData.enemyJumpHeight(position) = 0
                GameData.knockback(position) = False
                GameData.knockbackTimer(position) = 0
            End If
            If GameData.aliens(position).Left >= wallName.Left - 20 And GameData.aliens(position).Left <= wallName.Width + wallName.Left - GameData.aliens(position).Width Then
                If GameData.spikeball.Left > GameData.aliens(position).Left And Not GameData.spikeball.Bounds.IntersectsWith(GameData.aliens(position).Bounds) Then
                    'If spikeball is going up the slope (to the right), make him move up. 
                    GameData.aliens(position).Top -= 7
                    GameData.alienHealth(position).Top -= 7
                ElseIf GameData.spikeball.Left < GameData.aliens(position).Left And Not GameData.spikeball.Bounds.IntersectsWith(GameData.aliens(position).Bounds) And Not anyWall(GameData.aliens(position)) Then
                    'If spikeball is going down the slope (to the left) make him go down. 
                    GameData.aliens(position).Top += 0.1
                    GameData.alienHealth(position).Top += 0.1
                End If
            End If
        End If
        Return True

    End Function
    'Boolean method for if an entity is touching the wall:
    Public Shared Function touchingWall(ByVal wallName, ByVal character)
        If character.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function
    'Boolean method for if an entity is touching any slope:
    Public Shared Function anySlope(ByVal character)
        For i = 0 To GameData.slopes.Length - 1
            If touchingWall(GameData.slopes(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any wall:
    Public Shared Function anyWall(ByVal character)
        For i = 0 To GameData.terrain.Length - 1
            If touchingWall(GameData.terrain(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any wall:
    Public Shared Function anyAlien(ByVal character)
        For i = 0 To GameData.aliens.Length - 1
            If Not GameData.aliens(i) Is character And touchingWall(GameData.aliens(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any entity:
    Public Shared Function anyEntity(ByVal character)
        For i = 0 To GameData.aliens.Length() - 1
            If Not GameData.enemyDead(i) And touchingWall(GameData.aliens(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Hurt:
    Public Shared Function hurt(ByVal pain, ByVal position)
        GameData.enemyHealth(position) -= pain
        Select Case GameData.enemyHealth(position)
            Case 100
                GameData.alienHealth(position).Image = My.Resources.heathbar100
            Case Is >= 90
                GameData.alienHealth(position).Image = My.Resources.heathbar90
            Case Is >= 80
                GameData.alienHealth(position).Image = My.Resources.heathbar80
            Case Is >= 70
                GameData.alienHealth(position).Image = My.Resources.heathbar70
            Case Is >= 60
                GameData.alienHealth(position).Image = My.Resources.heathbar60
            Case Is >= 50
                GameData.alienHealth(position).Image = My.Resources.heathbar50
            Case Is >= 40
                GameData.alienHealth(position).Image = My.Resources.heathbar40
            Case Is >= 30
                GameData.alienHealth(position).Image = My.Resources.heathbar30
            Case Is >= 20
                GameData.alienHealth(position).Image = My.Resources.heathbar20
            Case Is >= 10
                GameData.alienHealth(position).Image = My.Resources.healthbar10
            Case Else
                If GameData.enemyHealth(position) <= 0 Then
                    GameData.alienHealth(position).Image = My.Resources.healthbar0
                    GameData.enemyDead(position) = True
                    GameData.aliens(position).Visible = False
                    GameData.alienHealth(position).Visible = False
                End If
        End Select
        Return True
    End Function
End Class
