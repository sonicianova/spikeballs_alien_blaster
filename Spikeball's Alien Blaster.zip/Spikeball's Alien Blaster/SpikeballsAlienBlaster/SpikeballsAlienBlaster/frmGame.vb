﻿Public Class frmGame
    'Create physics variables:
    Dim speed As Integer = 10
    Dim jumpHeight As Integer = 5
    Dim direction As String = "right"

    'Create control variables:
    Dim leftKey As Boolean = False
    Dim rightKey As Boolean = False
    Dim downKey As Boolean = False
    Dim a As Boolean = False
    Dim s As Boolean = False
    Dim jumping As Boolean = False
    Dim rolling As Boolean = False
    Dim falling As Boolean = True
    Dim cameraMoving As Boolean = False
    Dim xPos As Integer = 0
    Dim shootCooldown As Integer = 0
    Dim breakModifier As Double = 2.5
    Dim breakingWall As Boolean = False
    Dim alarm As Boolean = False
    Dim attack As Boolean = False
    Dim textNumber As Integer = 0
    Dim textTimer As Integer = 0
    Dim keyControl As Integer = True
    Dim skyTime As Integer = 200
    Dim skyColor As Integer = 0

    'Create timers:
    Dim transitionTimer As Integer = 0
    Dim jumpTimer As Integer = 0
    Dim knockbackTimer() As Integer = {0, 0, 0}
    Dim fadeTimer As Integer = -1
    Dim explosionTimer() As Integer = {80, 60, 40, 20, 0, 100}

    'Create graphics variables
    Dim graphic As String = "spikeballStandRight"

    'Create storage array lists of entities:
    Dim enemySpeeds() As Integer = {8, 8, 0}
    Dim enemyCostume() As String = {"defAlienStandLeft", "defAlienStandLeft", "pilotStand"}
    Dim knockback() As Boolean = {True, True, False}
    Dim enemyJumpHeight() As Integer = {5, 5, 0}
    Dim knockBackModifier() As Double = {3.5, 3.5, 0}
    Dim knockbackDirection() As String = {"right", "right", "null"}
    Dim attackCooldown() As Integer = {45, 45, 5}
    Dim enemyHealth() As Double = {100, 100, 150}
    Dim enemyDead() As Boolean = {False, False, False}
    Dim bulletFiring() As Boolean = {False, False, False, False, False, False, False, False, False, False}
    Dim enemyBulletFiring() As Boolean = {False, False, False, False, False, False, False, False, False, False}
    Dim bullet() As PictureBox
    Dim enemyBullet() As PictureBox
    Dim enemyBulletDirection() As String = {"right", "right", "right", "right", "right", "right", "right", "right", "right", "right"}
    Dim bulletDirection() As String = {"right", "right", "right", "right", "right", "right", "right", "right", "right", "right"}
    Dim enemyMovement() As Integer = {0, 0, 0}
    Dim aliens() As PictureBox
    Dim alienHealth() As PictureBox
    Dim terrain() As PictureBox
    Dim explosion() As PictureBox
    Dim closeTimer As Integer = 50

    'Create score variables:
    Dim score As Integer = 0
    Dim lives As Integer = 5
    Dim health As Double = 100
    Dim random As New Random()

    Private Sub frmGame_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Start the timers on load:
        tmrGameTick.Start()

        bullet = New PictureBox() {picBullet1, picBullet2, picBullet3, picBullet4, picBullet5, picBullet6, picBullet7, picBullet8, picBullet9, picBullet10}
        enemyBullet = New PictureBox() {picEnemyBullet1, picEnemyBullet2, picEnemyBullet3, picEnemyBullet4, picEnemyBullet5, picEnemyBullet6, picEnemyBullet7, picEnemyBullet8, picEnemyBullet9, picEnemyBullet10}
        aliens = New PictureBox() {picDefAlien1, picDefAlien2, picPilot}
        alienHealth = New PictureBox() {picDefAlienHealth1, picDefAlienHealth2, picPilotHealth}
        terrain = New PictureBox() {picFloor1, picFloor2, picFloor3, picFloor4, picCeiling1, picWall1, picTutorialText1, picTutorialText2, picFragileWall1, picFragileWall2, picFragileWall3, picAlarm, picWallPanel1, picWall2, picCeiling2, picCorner1, picFloor5, picWall3, picTutorialText3, picWall4, picFloor6, picTutorialText4, picFragileWall4, picFragileWall5, picFragileWall6, picExplosion1, picExplosion2, picExplosion3, picExplosion4, picExplosion5, picExplosion6}
        explosion = New PictureBox() {picExplosion1, picExplosion2, picExplosion3, picExplosion4, picExplosion5, picExplosion6}

        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2

        reset()
        Me.Cursor.Hide()
    End Sub

    'UNCOMMENT THIS TO BREAK ALL GRAPHICS >:D
    'Protected Overrides Sub OnPaintBackground(ByVal e As PaintEventArgs)
    'Do nothing.
    'End Sub

    'KEY DETECTION
    '=================================================================='
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        'Test if either of the keys have been pressed.
        'Set their value to true and override default button tabbing.
        If keyControl Then
            Select Case keyData
                Case Keys.Right
                    If Not rolling Then
                        rightKey = True
                    End If
                Case Keys.Left
                    If Not rolling Then
                        leftKey = True
                    End If
                Case Keys.Down
                    downKey = True
                    leftKey = False
                    rightKey = False
                    s = False
                Case Keys.A
                    a = True
                Case Keys.S
                    s = True
            End Select
        End If
    End Function

    Private Sub frmMainMenu_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        'Test if either of the keys have been released:
        If keyControl Then
            e.SuppressKeyPress = True
            e.Handled = True
            Select Case e.KeyCode
                Case Keys.Right
                    rightKey = False
                Case Keys.Left
                    leftKey = False
                Case Keys.Down
                    downKey = False
                    rolling = False
                Case Keys.A
                    a = False
                Case Keys.S
                    s = False
            End Select
        End If
    End Sub


    '=================================================================='

    'GAME TICK
    '=================================================================='
    Private Sub tmrGameTick_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGameTick.Tick
        'If spikeball is falling in the transition, change the color to make it look like he's falling into a planet.
        If Not keyControl And Not anyWall(picSpikeball) Then
            If skyTime = 0 Then
                btnClose.BackColor = Color.Transparent
                'If the sky color is maximum stop it from changing.
                If skyColor = 510 Then
                    skyTime -= 1
                Else
                    'Increase the sky color. If it is greater than 255 then change the green value to the color value - 255. Else, change the blue color to the current value.
                    skyColor += 1
                    If skyColor > 255 Then
                        Me.BackColor = Color.FromArgb(0, skyColor - 255, 255)
                    Else
                        Me.BackColor = Color.FromArgb(0, 0, skyColor)
                    End If
                End If

            Else
                skyTime -= 2
            End If
        End If
        'Test if spikeball is far enough to trigger any text:
        Select Case textNumber
            Case 0
                If alarm Then
                    'When the alarm first goes off play the alien yelling of his escape.
                    textTimer = 100
                    textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.alienTalk1
                End If
            Case 1
                If alarm And enemyDead(1) Then
                    'When the second guard dies play the pilot yelling at the idiots.
                    textTimer = 95
                    textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.pilotTalk1
                End If
            Case 2
                If picPilot.Left <= Me.Width Then
                    'When the pilot sees spikeball tell spikeball he's dead.
                    textTimer = 50
                    textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.pilotTalk2
                End If
            Case 3
                If enemyDead(2) Then
                    'When the pilot dies tell everyone to abandon ship!
                    textTimer = 65
                    textNumber += 1
                    picTalkBox.Visible = True
                    picTalkBox.Image = My.Resources.pilotTalk3
                End If
            Case 4
                If textTimer = 0 Then
                    'When the pilot is finished talking Spikeball says he needs to get
                    'off the ship. Queue mega-explosions, take control from the player,
                    'and roll them off the ship.
                    textTimer = 65
                    textNumber += 1
                    picTalkBox.Visible = True
                    picSpikeballHealth.Visible = False
                    picTalkBox.Image = My.Resources.spikeballTalk1
                    keyControl = False
                    direction = "right"
                    downKey = True
                End If
        End Select
        'If the pilot is dead explode stuff:
        Dim cloudX As Integer = 0
        If enemyDead(2) Then
            If skyColor >= 150 Then
                If skyColor = 150 Then
                    For i = 0 To explosion.Length - 2
                        explosionTimer(i) = random.Next(200)
                    Next
                    explosionTimer(explosion.Length - 1) = 0
                End If
                'If the sky is ready for clouds then generate clouds in the starship
                For i = 0 To explosion.Length - 1
                    If explosion(i).Top < 0 - explosion(i).Height And explosion(i).Width = 200 Then
                        explosionTimer(i) = 0
                    End If
                    If explosionTimer(i) = 0 Then
                        explosionTimer(i) = 1000
                        explosion(i).Width = 200
                        explosion(i).Height = 120
                        explosion(i).Image = Nothing
                        'Pick a random background image
                        Select Case random.Next(0, 2)
                            Case 0
                                explosion(i).BackgroundImage = My.Resources.cloud1
                            Case 1
                                explosion(i).BackgroundImage = My.Resources.cloud2
                            Case 2
                                explosion(i).BackgroundImage = My.Resources.cloud3
                        End Select
                        explosion(i).Top = Me.Height
                        cloudX = random.Next(0, Me.Width)
                        'For each explosion in the explosion array excepting the current explosion continue to randomly reset the x position of the clouds while the cloud is within the bounds of spikeball's width or touching another explosion.
                        For x = 0 To explosion.Length - 1
                            Do While (cloudX > (Me.Height - picSpikeball.Width / 2 - 255) And cloudX < (Me.Height - picSpikeball.Width / 2 + 45 + picSpikeball.Width)) Or (Not i = x And touchingWall(explosion(x), explosion(i)))
                                cloudX = random.Next(0, Me.Width)
                                explosion(i).Left = cloudX
                            Loop
                        Next
                        explosion(i).Visible = True
                    Else
                        'Move the cloud.
                        explosion(i).Top -= 25
                        explosion(i).Left -= 3
                        explosionTimer(i) -= 1
                    End If
                Next
            Else
                'If the sky is not yet ready for clouds then generate explosions in the
                'starship
                If textNumber < 3 Then
                    textNumber = 3
                End If
                For i = 0 To 3
                    If explosionTimer(i) = 0 Then
                        explosion(i).Visible = True
                        explosion(i).Image = My.Resources.smallExplosion
                        explosion(i).Left = -picFloor4.Left - random.Next(picFloor4.Width) - xPos
                        explosion(i).Top = random.Next(200) + picCeiling2.Top + 100
                        explosionTimer(i) = 60
                    Else
                        explosionTimer(i) -= 1
                    End If
                Next
            End If
        End If
        If textTimer > 0 Then
            textTimer -= 1
            If textTimer = 0 Then
                picTalkBox.Visible = False
                picTalkBox.Image = Nothing
            End If
        End If
        'Test if either of the keys are pressed, and if so move spikeball and change the animation:
        If rightKey Then
            direction = "right"
            speed = 10
            If Not cameraMoving Then
                picSpikeball.Left += speed
                picSpikeballHealth.Left += speed
            End If
            If Not graphic = "spikeballRunRight" Then
                picSpikeball.Image = My.Resources.spikeballRunRight
                graphic = "spikeballRunRight"
            End If
        ElseIf leftKey Then
            direction = "left"
            speed = -10
            If Not cameraMoving And picSpikeball.Left > 0 Then
                picSpikeball.Left += speed
                picSpikeballHealth.Left += speed
            End If
            If Not graphic = "spikeballRunLeft" Then
                picSpikeball.Image = My.Resources.spikeballRunLeft
                graphic = "spikeballRunLeft"
            End If
        ElseIf downKey Then
            'If spikeball is not rolling then play the transition animation and
            'the rolling animation.
            If Not rolling = True Then
                'If the graphic is not transition switch it to transition and start
                'the transition timer.
                If Not graphic = "transition" Then
                    If direction = "right" Then
                        picSpikeball.Image = My.Resources.spikeballTransitionRight
                    ElseIf direction = "left" Then
                        picSpikeball.Image = My.Resources.spikeballTransitionLeft
                    End If
                    graphic = "transition"
                    transitionTimer = 30
                End If
                'If the transition timer is 0 play the rolling animation.
                'Else decrease the transition timer.
                If transitionTimer = 0 Then
                    If direction = "right" Then
                        picSpikeball.Image = My.Resources.spikeballSpinRight
                    ElseIf direction = "left" Then
                        picSpikeball.Image = My.Resources.spikeballSpinLeft
                    End If
                    rolling = True
                Else
                    transitionTimer -= 1
                End If
            End If
            'If the speed is not already set set it:
            If direction = "left" Then
                speed = -10
            Else
                speed = 10
            End If
            'If spikeball is not in transition roll him forward.
            If transitionTimer = 0 And Not cameraMoving And picSpikeball.Left > 0 Then
                picSpikeball.Left += speed * 2
                picSpikeballHealth.Left += speed * 2
            End If
        ElseIf direction = "right" And keyControl Then
            picSpikeball.Image = My.Resources.spikeballStandRight
            graphic = "spikeballStandRight"
        ElseIf direction = "left" And keyControl Then
            picSpikeball.Image = My.Resources.spikeballStandLeft
            graphic = "spikeballStandLeft"
        End If
        If a Then
            'If the a key is pressed and the player is not jumping and not falling then
            'start the jump timer and set jumping to true.
            If jumping = False And falling = False Then
                jumpHeight = 5
                picSpikeball.Top -= jumpHeight
                picSpikeballHealth.Top -= jumpHeight
                jumpTimer = 15
                jumping = True
            End If
        End If
        If s Then
            'If the s key is pressed and the player is not shooting then start the shoot timer and
            'release a bullet.
            If Not downKey Then
                If shootCooldown = 0 Then
                    'Test for a free bullet and make it fire:
                    For i = 0 To 9
                        If Not bulletFiring(i) Then
                            'Set up the bullet for it to fire:
                            bulletFiring(i) = True
                            bullet(i).Visible = True
                            bullet(i).Top = picSpikeball.Top + 80
                            If direction = "right" Then
                                bullet(i).Left = picSpikeball.Left + picSpikeball.Width
                            Else
                                bullet(i).Left = picSpikeball.Left - bullet(i).Width
                            End If
                            bulletDirection(i) = direction
                            shootCooldown = 20
                            Exit For
                        End If
                    Next
                End If
            End If
        End If

        'If spikeball rolls into a wall break it:
        If touchingWall(picFragileWall3, picSpikeball) And rolling Then
            If Not breakingWall Then
                breakingWall = True
                breakModifier = 2.5
                picAlarm.Image = My.Resources.alarmBlaring
                alarm = True
                attack = True
            End If
        End If
        If touchingWall(picFragileWall5, picSpikeball) Then
            If Not breakingWall Then
                breakModifier = 2.5
                breakingWall = True
            End If
        End If

        If breakingWall Then
            'If the wall is visible then make them fall
            If picFragileWall1.Visible Then
                picFragileWall1.Left += 7 * breakModifier
                picFragileWall1.Top += 7 / breakModifier
            End If
            If picFragileWall2.Visible Then
                picFragileWall2.Left += 6 * breakModifier
                picFragileWall2.Top += 8 / breakModifier
            End If
            If picFragileWall3.Visible Then
                picFragileWall3.Left += 5 * breakModifier
                picFragileWall3.Top += 9 / breakModifier
            End If
            'Reduce how far they fall next time
            If breakModifier > 1 Then
                breakModifier -= 0.15
            End If
            'If they fall below the screen make them invisible
            If picFragileWall1.Top > Me.Height Then
                picFragileWall1.Visible = False
                breakingWall = False
            End If
            If picFragileWall2.Top > Me.Height Then
                picFragileWall2.Visible = False
            End If
            If picFragileWall3.Top > Me.Height Then
                picFragileWall3.Visible = False
            End If

            If Not keyControl Then
                'If the wall is visible then make them fall
                If picFragileWall4.Visible Then
                    picFragileWall4.Left += 6 * breakModifier
                    picFragileWall4.Top += 8 / breakModifier
                End If
                If picFragileWall5.Visible Then
                    picFragileWall5.Left += 5 * breakModifier
                    picFragileWall5.Top += 9 / breakModifier
                End If
                If picFragileWall6.Visible Then
                    picFragileWall6.Left += 7 * breakModifier
                    picFragileWall6.Top += 7 / breakModifier
                End If
                'Reduce how far they fall next time
                If breakModifier > 1 Then
                    breakModifier -= 0.15
                End If
            End If
        End If

        'Background color changes
        If Not keyControl And Not anyWall(picSpikeball) Then
            Select Case Me.BackColor
                Case Color.Silver
                    Me.BackColor = Color.Gray
                Case Color.Gray
                    Me.BackColor = Color.DarkGray
                Case Color.DarkGray
                    Me.BackColor = Color.Black
                Case Color.FromArgb(64, 0, 0)
                    Me.BackColor = Color.FromArgb(32, 0, 0)
                Case Color.FromArgb(32, 0, 0)
                    Me.BackColor = Color.Black
            End Select
        ElseIf alarm Then
            'If the alarm is blaring change the background of the form:
            Select Case Me.BackColor
                Case Color.Silver
                    Me.BackColor = Color.LightSalmon
                Case Color.LightSalmon
                    Me.BackColor = Color.Red
                Case Color.Red
                    Me.BackColor = Color.Maroon
                Case Color.Maroon
                    Me.BackColor = Color.FromArgb(64, 0, 0)
            End Select
        Else
            'Else revert the background to normal:
            Select Case Me.BackColor
                Case Color.FromArgb(64, 0, 0)
                    Me.BackColor = Color.Maroon
                Case Color.Maroon
                    Me.BackColor = Color.Red
                Case Color.Red
                    Me.BackColor = Color.LightSalmon
                Case Color.LightSalmon
                    Me.BackColor = Color.Silver
            End Select
        End If

        'If the bullet cooldown is greater than 0 lower it:
        If shootCooldown > 0 Then
            shootCooldown -= 1
        End If

        'Make all active bullets move:
        For i = 0 To 9
            'Fire every player bullet.
            If bulletFiring(i) Then
                If bulletDirection(i) = "right" Then
                    bullet(i).Left += 40
                Else
                    bullet(i).Left -= 40
                End If
                If bullet(i).Left > Me.Width - bullet(i).Width Or bullet(i).Left < 0 Or anyWall(bullet(i)) Then
                    bulletFiring(i) = False
                    bullet(i).Visible = False
                End If
                If bullet(i).Bounds.IntersectsWith(picAlarm.Bounds) Then
                    alarm = False
                    picAlarm.Image = My.Resources.alarmBroken
                    bulletFiring(i) = False
                    bullet(i).Visible = False
                End If
                For x = 0 To aliens.Length - 1
                    If aliens(x).Bounds.IntersectsWith(bullet(i).Bounds) And Not enemyDead(x) Then
                        hurtEntity(20, x)
                        bulletFiring(i) = False
                        bullet(i).Visible = False
                    End If
                Next
            End If
            'Fire every enemy bullet.
            If enemyBulletFiring(i) Then
                enemyBullet(i).Left -= 40
                If enemyBullet(i).Left > Me.Width - enemyBullet(i).Width Or enemyBullet(i).Left < 0 Or anyWall(enemyBullet(i)) Then
                    enemyBulletFiring(i) = False
                    enemyBullet(i).Visible = False
                End If
                If enemyBullet(i).Bounds.IntersectsWith(picSpikeball.Bounds) Then
                    hurt(1)
                    enemyBulletFiring(i) = False
                    enemyBullet(i).Visible = False
                End If
            End If
        Next

        'CALL AI:
        For i = 0 To aliens.Length - 2
            defaultAlien(aliens(i), alienHealth(i), i)
        Next

        'CALL WALL DETECT FUNCTIONS:
        For i = 0 To terrain.Length - 7
            If Not (rolling And breakingWall And (terrain(i) Is picFragileWall1 Or terrain(i) Is picFragileWall2 Or terrain(i) Is picFragileWall3 Or terrain(i) Is picFragileWall4 Or terrain(i) Is picFragileWall5 Or terrain(i) Is picFragileWall6)) Then
                wallDetect(terrain(i))
            End If
        Next

        'If the player is not rolling call wall detection on entities:
        If Not rolling And Not downKey Then
            For i = 0 To aliens.Length - 1
                If Not enemyDead(i) Then
                    wallDetect(aliens(i))
                End If
            Next
        End If

        If Not enemyDead(2) Then
            wallDetect(aliens(2))
        End If

        'Pilot code:
        If Not enemyDead(2) Then
            If attackCooldown(2) = 0 Then
                'Test for a free bullet and make it fire:
                For i = 0 To 9
                    If Not enemyBulletFiring(i) And picPilot.Left <= Me.Width Then
                        'Set up the bullet for it to fire:
                        enemyBulletFiring(i) = True
                        enemyBullet(i).Visible = True
                        enemyBullet(i).Top = picPilot.Top + 100
                        enemyBullet(i).Left = picPilot.Left - bullet(i).Width
                        enemyBulletDirection(i) = "left"
                        attackCooldown(2) = 10
                        Exit For
                    End If
                Next
                If Not enemyCostume(2) = "pilotShoot" Then
                    picPilot.Image = My.Resources.pilotShoot
                    enemyCostume(2) = "pilotShoot"
                End If
            Else
                attackCooldown(2) -= 1
            End If
        End If

        'Gravity and jumping:
        If jumping = False And falling = True Then
            If keyControl Or Me.BackColor = Color.FromArgb(0, 255, 255) Then
                'If the player is not jumping and the player is falling then
                'apply gravity.
                If rolling Then
                    picSpikeball.Top += 30
                    picSpikeballHealth.Top += 30
                Else
                    picSpikeball.Top += 20
                    picSpikeballHealth.Top += 20
                End If
                jumpHeight = 0
            Else
                'If the player is falling in the cutscene afterward move all of the
                'terrain upward instead:
                For i = 0 To terrain.Length - 1
                    If skyColor <= 150 And terrain(i).Top > 0 - terrain(i).Height - 300 Then
                        terrain(i).Top -= 30
                    End If
                Next
                'If the player is still to the right of the screen move him towards the middle:
                If picWall4.Left < 0 - picWall4.Width Then
                    If picSpikeball.Left > Me.Width / 2 - picSpikeball.Width / 2 Then
                        picSpikeball.Left -= speed
                        downKey = False
                        rolling = False
                        If Not graphic = "spikeballSpinRight" Then
                            picSpikeball.Image = My.Resources.spikeballSpinRight
                            graphic = "spikeballSpinRight"
                        End If
                    End If
                End If
            End If
        ElseIf jumping = True And jumpTimer > 0 Then
            'If the player is jumping reduce the timer of their jumping and
            'move them upward.
            jumpTimer -= 1
            If rolling Then
                picSpikeball.Top -= jumpHeight / 2
                picSpikeballHealth.Top -= jumpHeight / 2
            Else
                picSpikeball.Top -= jumpHeight
                picSpikeballHealth.Top -= jumpHeight
            End If
            If Not jumpHeight = 5 Then
                jumpHeight += 1
            End If
            'If the jumpTick = 0 then turn falling on.
            If jumpTimer = 0 Then
                falling = True
            End If
        ElseIf jumpTimer = 0 And jumping = True Then
            'If the player's jump timer has run out then slow their jumping to 0
            'and then turn gravity back on.
            If jumpHeight > -10 Then
                jumpHeight -= 1
            End If
            If rolling And jumpHeight <= 0 Then
                picSpikeball.Top -= jumpHeight * 1.5
                picSpikeballHealth.Top -= jumpHeight * 1.5
            ElseIf rolling Then
                picSpikeball.Top -= jumpHeight
                picSpikeballHealth.Top -= jumpHeight
            Else
                picSpikeball.Top -= jumpHeight * 1.5
                picSpikeballHealth.Top -= jumpHeight * 1.5
            End If
        End If

        'Camera movement:
        If picSpikeball.Left > Me.Width * 0.6 And direction = "right" And (rightKey Or rolling) Then
            'If the player moves to the right of the center it will move the camera with the player
            'to the right, moving the entire level to the left.
            cameraMoving = True
            xPos += speed
        ElseIf picFloor1.Left >= 0 Then
            'This locks the camera so it cannot go left of the start point.
            picFloor1.Left = 0
            picFloor2.Left = 210
            picFloor3.Left = 630
            picFloor4.Left = 840
            picWall1.Left = 0
            picCeiling1.Left = 0
            cameraMoving = False
        ElseIf picSpikeball.Left < Me.Width * 0.4 And direction = "left" And (leftKey Or rolling) Then
            'If the player moves to the left of the center it will move the camera with the player
            'to the left, moving the entire level to the right.
            cameraMoving = True
            xPos += speed
        Else
            'If the player is not moving stop the camera movement.
            cameraMoving = False
        End If
        If cameraMoving Then
            If rolling Then
                moveLevel(speed * 2)
            Else
                moveLevel(speed)
            End If
        End If

        'If the player is not touching any of the level elements turn gravity on.
        If jumping = False And Not anyWall(picSpikeball) And Not anyEntity(picSpikeball) Then
            falling = True
            jumping = False
            jumpTimer = 0
        End If

        'If the player has fallen off the screen then kill them:
        If picSpikeball.Top > Me.Height Then
            If Me.BackColor = Color.FromArgb(0, 255, 255) Then
                If closeTimer = 0 Then
                    frmFade.Show()
                    My.Settings.tutorialPlayed = True
                    My.Settings.Save()
                Else
                    closeTimer -= 1
                End If
            Else
                hurt(1000)
            End If
        End If
        For i = 0 To aliens.Length - 1
            aliens(i).Left += enemyMovement(i)
            alienHealth(i).Left += enemyMovement(i)
            enemyMovement(i) = 0
        Next
    End Sub
    '=================================================================='

    'GAME FUNCTIONS
    '=================================================================='
    'Default alien function:
    Dim rollPain As Integer = 0
    Private Function defaultAlien(ByVal alien, ByVal alienHealth, ByVal position)
        'If the alien is not dead then perform AI:
        If Not enemyDead(position) Then
            'Find the direction of Spikeball and move toward it.
            If attack And picSpikeball.Left + picSpikeball.Width < alien.Left And alien.Left > 0 - xPos And Not (touchingWall(picFragileWall1, alien) Or touchingWall(picFragileWall2, alien) Or touchingWall(picFragileWall3, alien) And alien.Left > picFragileWall1.Left) Then
                'If Spikeball is to the left move left:
                enemyMovement(position) -= enemySpeeds(position)
                If Not enemyCostume(position) = "defAlienWalkLeft" Then
                    alien.Image = My.Resources.defAlienWalkLeft
                    enemyCostume(position) = "defAlienWalkLeft"
                End If
            End If
            If attack And picSpikeball.Left > alien.Left + alien.Width And alien.Left < Me.Width And Not (touchingWall(picFragileWall1, alien) Or touchingWall(picFragileWall2, alien) Or touchingWall(picFragileWall3, alien) Or touchingWall(picWall3, alien) And alien.Left > picFragileWall1.Right) Then
                'If spikeball is to the right move right:
                enemyMovement(position) += enemySpeeds(position)
                If Not enemyCostume(position) = "defAlienWalkRight" Then
                    alien.Image = My.Resources.defAlienWalkRight
                    enemyCostume(position) = "defAlienWalkRight"
                End If
            End If
            'Test if they're pushing against another alien:
            For i = 0 To aliens.Length - 1
                If Not i = position And Not enemyDead(i) And alien.Bounds.IntersectsWith(aliens(i).Bounds) Then
                    If knockback(position) Then
                        If knockbackDirection(position) = "right" Then
                            enemyMovement(position) -= enemySpeeds(0) * knockBackModifier(position)
                            knockbackDirection(position) = "left"
                        ElseIf alien.Left > 0 - xPos Then
                            enemyMovement(position) += enemySpeeds(0) * knockBackModifier(position)
                            knockbackDirection(position) = "right"
                        End If
                    Else
                        If alien.Left < aliens(i).Left Then
                            enemyMovement(position) -= enemySpeeds(position)
                        Else
                            enemyMovement(position) += enemySpeeds(position)
                        End If
                    End If
                End If
            Next
            'Test if Spikeball is pushing them:
            If attack And picSpikeball.Bounds.IntersectsWith(alien.Bounds) Then
                If rolling Then
                    'If the player is rolling into them then start the knockback timer:
                    If Not knockback(position) Then
                        knockbackTimer(position) = 25
                        knockback(position) = True
                        knockbackDirection(position) = direction
                    End If
                    attackCooldown(position) = 15
                    If rollPain <= 0 Then
                        rollPain = 30
                        hurtEntity(20, position)
                    End If
                Else
                    'Attack the player if the attack cooldown is 0:
                    If attackCooldown(position) <= 0 Then
                        If picSpikeball.Left < alien.Left Then
                            If Not enemyCostume(position) = "defAlienAttackLeft" Then
                                alien.Image = My.Resources.defAlienAttackLeft
                                enemyCostume(position) = "defAlienAttackLeft"
                            End If
                        ElseIf picSpikeball.Left + picSpikeball.Width > alien.Left Then
                            If Not enemyCostume(position) = "defAlienAttackRight" Then
                                alien.Image = My.Resources.defAlienAttackRight
                                enemyCostume(position) = "defAlienAttackRight"
                            End If
                        End If
                        hurt(1)
                        attackCooldown(position) = 45
                    Else
                        attackCooldown(position) -= 1
                    End If
                End If
            End If
            rollPain -= 1
            'If the alien is being knocked back then knock them back:
            If knockback(position) Then
                If knockbackTimer(position) > 0 Then
                    knockbackTimer(position) -= 1
                Else
                    If enemyJumpHeight(position) > -5 Then
                        enemyJumpHeight(position) -= 1
                        knockBackModifier(position) -= 0.05
                    End If
                    If anyWall(alien) And Not touchingWall(picCeiling1, alien) Then
                        enemyJumpHeight(position) = 5
                        knockback(position) = False
                        knockBackModifier(position) = 3.5
                    End If
                End If
                alien.Top -= enemyJumpHeight(position)
                alienHealth.Top -= enemyJumpHeight(position)
                'If the alien is not touching one of the possible walls, move them to the left or right.
                If Not touchingWall(picFragileWall1, alien) And Not touchingWall(picFragileWall2, alien) And Not touchingWall(picFragileWall3, alien) And Not touchingWall(picFloor5, alien) Then
                    If knockbackDirection(position) = "right" Then
                        enemyMovement(position) += enemySpeeds(position) * knockBackModifier(position) * 1.2
                    ElseIf alien.Left > 0 - xPos Then
                        enemyMovement(position) -= enemySpeeds(position) * knockBackModifier(position) * 1.2
                    End If
                Else
                    If knockbackDirection(position) = "right" Then
                        knockBackModifier(position) /= 1.5
                        enemyMovement(position) -= enemySpeeds(position) * knockBackModifier(position)
                        knockbackDirection(position) = "left"
                    ElseIf alien.Left > 0 - xPos Then
                        knockBackModifier(position) /= 1.5
                        enemyMovement(position) += enemySpeeds(position) * knockBackModifier(position)
                        knockbackDirection(position) = "right"
                    End If
                End If
            End If
            If touchingWall(picCeiling1, alien) Or touchingWall(picAlarm, alien) Or touchingWall(picCeiling2, alien) Or touchingWall(picTutorialText3, alien) Or touchingWall(picCorner1, alien) Then
                knockbackTimer(position) = 0
                enemyJumpHeight(position) = 0
                alien.Top += 5
            End If
            'If the alien is not affected by gravity make them fall:
            If Not anyWall(alien) And Not knockback(position) Then
                alien.Top += 5
                alienHealth.Top += 5
            End If
            'If the alien has fallen off the screen kill them:
            If alien.Top >= Me.Height Then
                hurtEntity(100, position)
            End If
        End If
        Return True
    End Function
    'WALL DETECT
    Private Function wallDetect(ByVal wallName)

        If picSpikeball.Bounds.IntersectsWith(wallName.Bounds) Then
            If picSpikeball.Top > wallName.Top + wallName.Height / 1.2 Then
                'Negate top movement
                picSpikeball.Top += jumpHeight
                picSpikeballHealth.Top += jumpHeight
                jumpTimer = 0
                jumpHeight = 0
                Return True
            ElseIf picSpikeball.Top < wallName.Top - 100 Then
                'Stop the player from falling:
                falling = False
                jumping = False
                jumpHeight = 0
                jumpTimer = 0
                Return True
            ElseIf picSpikeball.Left < wallName.Left And direction = "right" Then
                If picSpikeball.Top < wallName.Top + wallName.Height Then
                    'Negate left movement
                    picSpikeball.Left -= speed
                    picSpikeballHealth.Left -= speed
                    speed = 0
                    If rolling And keyControl Then
                        rolling = False
                        downKey = False
                    End If
                    Return True
                End If
            ElseIf picSpikeball.Left > wallName.Left And direction = "left" Then
                If picSpikeball.Top < wallName.Top + wallName.Height Then
                    'Negate right movement
                    picSpikeball.Left -= speed
                    picSpikeballHealth.Left -= speed
                    speed = 0
                    If rolling And keyControl Then
                        rolling = False
                        downKey = False
                    End If
                    Return True
                End If
            Else
                Return False
            End If
        End If
        Return True

    End Function
    'Boolean method for if an entity is touching the wall:
    Private Function touchingWall(ByVal wallName, ByVal character)
        If character.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function
    'Boolean method for if an entity is touching any wall:
    Private Function anyWall(ByVal character)
        For i = 0 To terrain.Length - 1
            If touchingWall(terrain(i), character) And Not (rolling And breakingWall And (terrain(i) Is picFragileWall1 Or terrain(i) Is picFragileWall2 Or terrain(i) Is picFragileWall3 Or terrain(i) Is picFragileWall4 Or terrain(i) Is picFragileWall5 Or terrain(i) Is picFragileWall6)) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any entity:
    Private Function anyEntity(ByVal character)
        For i = 0 To aliens.Length() - 1
            If Not enemyDead(i) And touchingWall(aliens(i), character) Then
                Return True
            End If
        Next


        Return False
    End Function
    'Move the level elements according to speed:
    Private Function moveLevel(ByVal distance)
        For i = 0 To terrain.Length - 1
            terrain(i).Left -= distance
        Next
        For i = 0 To aliens.Length - 1
            enemyMovement(i) -= distance
        Next
        For i = 0 To 9
            bullet(i).Left -= distance
        Next
        Return True
    End Function
    'Hurt the player:
    Private Function hurt(ByVal pain)
        health -= pain
        If health = 10 Then
            picSpikeballHealth.Image = My.Resources.heathbar100
        ElseIf health = 9 Then
            picSpikeballHealth.Image = My.Resources.heathbar90
        ElseIf health = 8 Then
            picSpikeballHealth.Image = My.Resources.heathbar80
        ElseIf health = 7 Then
            picSpikeballHealth.Image = My.Resources.heathbar70
        ElseIf health = 6 Then
            picSpikeballHealth.Image = My.Resources.heathbar60
        ElseIf health = 5 Then
            picSpikeballHealth.Image = My.Resources.heathbar50
        ElseIf health = 4 Then
            picSpikeballHealth.Image = My.Resources.heathbar40
        ElseIf health = 3 Then
            picSpikeballHealth.Image = My.Resources.heathbar30
        ElseIf health = 2 Then
            picSpikeballHealth.Image = My.Resources.heathbar20
        ElseIf health = 1 Then
            picSpikeballHealth.Image = My.Resources.healthbar10
        ElseIf health < 0 Then
            'RESET THE FORM
            reset()
        End If
        Return True
    End Function
    'Reset the form:
    Private Function reset()
        'Reset entities:
        picSpikeball.Left = 38
        picSpikeball.Top = Me.Height * 0.66
        picSpikeball.Image = My.Resources.spikeballStandRight
        picSpikeballHealth.Left = 50
        picSpikeballHealth.Top = Me.Height * 0.66 - 16
        picSpikeballHealth.Image = My.Resources.heathbar100
        picDefAlien1.Left = 1343
        picDefAlien1.Top = Me.Height * 0.66
        picDefAlienHealth1.Left = 1368
        picDefAlienHealth1.Top = Me.Height * 0.66 - 16
        picDefAlien1.Visible = True
        picDefAlienHealth1.Visible = True
        picDefAlienHealth1.Image = My.Resources.heathbar100
        picDefAlien2.Visible = True
        picDefAlienHealth2.Visible = True
        picDefAlienHealth2.Image = My.Resources.heathbar100

        'Reset terrain:
        picFloor1.Left = 0
        picFloor2.Left = 210
        picFloor3.Left = 630
        picFloor4.Left = 840
        picFloor5.Left = 2310
        picCeiling1.Left = 0
        picWall1.Left = 0
        picWall2.Left = 1470
        picWall3.Left = 2310
        picTutorialText3.Left = 1670
        picCeiling2.Left = 1470
        picCorner1.Left = 1370
        picTutorialText1.Left = 12
        picTutorialText2.Left = 1010
        picFragileWall1.Left = 1250
        picFragileWall1.Top = 420 + Me.Height - 720
        picFragileWall2.Left = 1250
        picFragileWall2.Top = 420 + Me.Height - 720 + 67
        picFragileWall3.Left = 1250
        picFragileWall3.Top = 420 + Me.Height - 720 + 134
        picFragileWall1.Visible = True
        picFragileWall2.Visible = True
        picFragileWall3.Visible = True
        picAlarm.Left = 1470
        picAlarm.Image = My.Resources.alarmSilent
        picDefAlienHealth2.Left = 1708
        picDefAlienHealth2.Top = 380
        picDefAlien2.Left = 1683
        picDefAlien2.Top = 396
        picWall4.Left = 4180
        picFloor6.Left = 4180
        picTutorialText4.Left = 998
        picPilot.Left = 4780
        picPilotHealth.Left = 4805
        picPilot.Visible = True
        picPilotHealth.Visible = True
        picFragileWall4.Left = 5620
        picFragileWall5.Left = 5620
        picFragileWall6.Left = 5620

        Me.BackColor = Color.Silver

        'Reset variables:
        textNumber = 0
        xPos = 0
        jumpHeight = 0
        jumping = False
        jumpTimer = 0
        cameraMoving = False
        speed = 0
        a = False
        leftKey = False
        rightKey = False
        falling = True
        rolling = False
        health = 10
        lives -= 1
        breakingWall = False
        breakModifier = 2.5
        alarm = False
        attack = False
        keyControl = True
        downKey = False
        s = False
        explosion(0).Visible = False
        explosion(1).Visible = False
        explosion(2).Visible = False
        explosion(3).Visible = False

        For x = 0 To enemyJumpHeight.Length - 1
            enemyJumpHeight(x) = 0
            knockbackTimer(x) = 0
            enemyDead(x) = False
            enemyHealth(x) = 100
        Next
        Return True
    End Function
    'Hurt any entity:
    Private Function hurtEntity(ByVal pain, ByVal position)
        enemyHealth(position) -= pain
        Select Case enemyHealth(position)
            Case 100
                alienHealth(position).Image = My.Resources.heathbar100
            Case Is >= 90
                alienHealth(position).Image = My.Resources.heathbar90
            Case Is >= 80
                alienHealth(position).Image = My.Resources.heathbar80
            Case Is >= 70
                alienHealth(position).Image = My.Resources.heathbar70
            Case Is >= 60
                alienHealth(position).Image = My.Resources.heathbar60
            Case Is >= 50
                alienHealth(position).Image = My.Resources.heathbar50
            Case Is >= 40
                alienHealth(position).Image = My.Resources.heathbar40
            Case Is >= 30
                alienHealth(position).Image = My.Resources.heathbar30
            Case Is >= 20
                alienHealth(position).Image = My.Resources.heathbar20
            Case Is >= 10
                alienHealth(position).Image = My.Resources.healthbar10
            Case Else
                If enemyHealth(position) <= 0 Then
                    alienHealth(position).Image = My.Resources.healthbar0
                    enemyDead(position) = True
                    aliens(position).Visible = False
                    alienHealth(position).Visible = False
                End If
        End Select
        Return True
    End Function
    '=================================================================='

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        'Close the form:
        Close()
    End Sub
End Class