﻿Public Class frmTerraLevel1
    Public Shared textNumber As Integer = 0
    Public Shared textTimer As Integer = 0
    Private Sub frmGame_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Start the timer on load:
        tmrGameTick.Start()

        GameData.form = "level 1"

        'Entities:
        GameData.bullet = New PictureBox() {picBullet1, picBullet2, picBullet3, picBullet4, picBullet5, picBullet6, picBullet7, picBullet8, picBullet9, picBullet10}
        GameData.enemyBullet = New PictureBox() {}
        GameData.aliens = New PictureBox() {picDefAlien1, picDefAlien2}
        GameData.alienHealth = New PictureBox() {picDefAlienHealth1, picDefAlienHealth2}
        GameData.bludgeon = New PictureBox() {frmTerraBackground1.picBludgeon1}
        GameData.bludgeonHealthBar = New PictureBox() {frmTerraBackground1.picBludgeonHealth1}
        GameData.bombs = New PictureBox() {picBomb1}
        GameData.bludgeonHealth = New Integer() {150}
        GameData.bludgeonDead = New Boolean() {False}
        GameData.bludgeonFlightSpeed = New Double() {0}
        GameData.bludgeonTimer = New Integer() {0}
        GameData.bombDrop = New Boolean() {False}
        GameData.bombTimer = New Integer() {0}
        GameData.enemyCostume = New String() {"defAlienStandLeft", "defAlienStandLeft"}
        GameData.enemyJumpHeight = New Integer() {0, 0}
        GameData.enemyMovement = New Integer() {0, 0}
        GameData.enemySpeeds = New Integer() {8, 8}
        GameData.enemyDead = New Boolean() {False, False}
        GameData.enemyHealth = New Double() {100, 100}

        'Terrain:
        GameData.terrain = New PictureBox() {frmTerraTerrain1.picGrass1, frmTerraTerrain1.picDirt1, frmTerraTerrain1.picGrass2, frmTerraTerrain1.picBigBox1, frmTerraTerrain1.picSmallBox1, frmTerraTerrain1.picDirt2, frmTerraTerrain1.picStump1, frmTerraTerrain1.picGrassCap1, frmTerraTerrain1.picGrass3, frmTerraTerrain1.picDirt3, frmTerraTerrain1.picSmallBox2, frmTerraTerrain1.picSmallBox3, frmTerraTerrain1.picGrass4, frmTerraTerrain1.picDirt4, frmTerraTerrain1.picDirt5, frmTerraTerrain1.picGrass5}

        'Other arrays:
        GameData.slopes = New PictureBox() {frmTerraTerrain1.picSlope1, frmTerraTerrain1.picSlope2, frmTerraTerrain1.picSlope3}
        GameData.grass = New PictureBox() {frmTerraTerrain1.picGrassDeco1, frmTerraTerrain1.picGrassDeco2, frmTerraTerrain1.picGrassDeco3, frmTerraTerrain1.picGrassDeco4}
        GameData.medkit = New PictureBox() {frmTerraTerrain1.picMedkit1}
        GameData.coin = New PictureBox() {frmTerraTerrain1.picCoin1, frmTerraTerrain1.picCoin2, frmTerraTerrain1.picCoin3, frmTerraTerrain1.picCoin4, frmTerraTerrain1.picCoin5}
        GameData.ammoBox = New PictureBox() {frmTerraTerrain1.picAmmo1}
        GameData.platforms = New PictureBox() {frmTerraTerrain1.picPlatform1}
        GameData.keyControl = False
        GameData.rolling = True
        GameData.spikeball = picSpikeball
        GameData.spikeball.Image = My.Resources.spikeballSpinRight
        GameData.spikeballHealth = picSpikeballHealth
        GameData.ammoLabel = lblAmmo


        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
            Me.Cursor.Hide()
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2
        reset()

    End Sub

    'UNCOMMENT THIS TO BREAK ALL GRAPHICS >:D
    'Protected Overrides Sub OnPaintBackground(ByVal e As PaintEventArgs)
    'Do nothing.
    'End Sub

    'KEY DETECTION
    '=================================================================='
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        'Test if either of the keys have been pressed.
        'Set their value to true and override default button tabbing.
        If GameData.keyControl Then
            Select Case keyData
                Case Keys.Right
                    If Not GameData.rolling And Not GameData.reloading Then
                        GameData.rightKey = True
                    End If
                Case Keys.Left
                    If Not GameData.rolling And Not GameData.reloading Then
                        GameData.leftKey = True
                    End If
                Case Keys.Down
                    GameData.downKey = True
                    GameData.leftKey = False
                    GameData.rightKey = False
                    GameData.s = False
                Case Keys.A
                    GameData.a = True
                Case Keys.S
                    GameData.s = True
                Case Keys.R
                    If Not GameData.reloading And GameData.activeAmmo < 5 Then
                        GameData.reloading = True
                        GameData.reloadingTimer = 30
                    End If
            End Select
        End If
    End Function
    Private Sub frmTerraLevel1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        'Test if either of the keys have been released:
        If GameData.keyControl Then
            e.SuppressKeyPress = True
            e.Handled = True
            Select Case e.KeyCode
                Case Keys.Right
                    GameData.rightKey = False
                Case Keys.Left
                    GameData.leftKey = False
                Case Keys.Down
                    GameData.downKey = False
                    GameData.rolling = False
                Case Keys.A
                    GameData.a = False
                Case Keys.S
                    GameData.s = False
            End Select
        End If
    End Sub


    'GAME TICK
    '=================================================================='
    Private Sub tmrGameTick_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGameTick.Tick
        'Story Text:
        Select Case textNumber
            'Add cases here as the story develops:
        End Select
        If textTimer > 0 Then
            textTimer -= 1
            If textTimer = 0 Then
                picTalkBox.Visible = False
                picTalkBox.Image = Nothing
            End If
        End If
        Spikeball.keyEvents()

        'CALL AI:
        If GameData.keyControl Then
            For i = 0 To GameData.aliens.Length - 1
                DefaultAlien.act(GameData.aliens(i), GameData.alienHealth(i), i)
            Next
            For i = 0 To GameData.bludgeon.Length - 1
                Bludgeon.act(GameData.bludgeon(i), GameData.bludgeonHealthBar(i), i)
            Next
        End If

        'CALL WALL DETECT FUNCTIONS:
        For i = 0 To GameData.terrain.Length - 1
            Spikeball.wallDetect(GameData.terrain(i))
        Next
        For i = 0 To GameData.platforms.Length - 1
            Spikeball.platformDetect(GameData.platforms(i))
        Next
        For i = 0 To GameData.slopes.Length - 1
            Spikeball.slopeDetectionRight(GameData.slopes(i))
        Next

        'If the player is not rolling call wall detection on entities:
        If Not GameData.rolling And Not GameData.downKey Then
            For i = 0 To GameData.aliens.Length - 1
                If Not GameData.enemyDead(i) Then
                    Spikeball.wallDetect(GameData.aliens(i))
                End If
            Next
        End If

        'Bullets:
        Bullet.shoot()

        'Interactives
        Interactives.interactives()
        Interactives.decorations()

        'Apply gravity/jumping mechanics
        Spikeball.jump()

        'Move the camera:
        Camera.cameraUse()

        'Move every entity based on the sum total of the values for movement for them:
        For i = 0 To GameData.aliens.Length - 1
            GameData.aliens(i).Left += GameData.enemyMovement(i)
            GameData.alienHealth(i).Left += GameData.enemyMovement(i)
            GameData.enemyMovement(i) = 0
        Next
        For i = 0 To GameData.bludgeon.Length - 1
            GameData.bludgeon(i).Left += GameData.bludgeonFlightSpeed(i)
            GameData.bludgeonHealthBar(i).Left += GameData.bludgeonFlightSpeed(i)
            If Not GameData.bombDrop(i) Then
                GameData.bombs(i).Left += GameData.bludgeonFlightSpeed(i)
            End If
        Next
    End Sub
    '=================================================================='

    'Reset the form:
    Public Shared Function reset()
        'Reset entities:
        frmTerraLevel1.picSpikeball.Left = frmTerraLevel1.Width / 2 - frmTerraLevel1.picSpikeball.Width / 2
        frmTerraLevel1.picSpikeball.Top = -100
        frmTerraLevel1.picSpikeball.Image = My.Resources.spikeballSpinRight
        frmTerraLevel1.picSpikeballHealth.Left = frmTerraLevel1.Width / 2 - frmTerraLevel1.picSpikeballHealth.Width / 2
        frmTerraLevel1.picSpikeballHealth.Top = -116
        frmTerraLevel1.picSpikeballHealth.Image = My.Resources.heathbar100

        'Reset terrain:
        frmTerraTerrain1.picGrass1.Visible = True
        frmTerraTerrain1.picGrass1.Left = 0
        frmTerraTerrain1.picDirt1.Visible = True
        frmTerraTerrain1.picDirt1.Left = 0
        frmTerraTerrain1.picSlope1.Visible = True
        frmTerraTerrain1.picSlope1.Left = 1500
        frmTerraTerrain1.picGrass2.Visible = True
        frmTerraLevel1.picDefAlien1.Visible = True
        frmTerraLevel1.picDefAlien1.Left = 1118
        frmTerraLevel1.picDefAlienHealth1.Left = 1143
        frmTerraLevel1.picDefAlienHealth1.Visible = True
        frmTerraLevel1.picDefAlien1.Top = 308
        frmTerraLevel1.picDefAlienHealth1.Top = 292
        frmTerraTerrain1.picGrassDeco2.Left = 361
        frmTerraTerrain1.picGrassDeco3.Left = 461
        frmTerraTerrain1.picGrassDeco1.Left = 1016
        frmTerraTerrain1.picGrassDeco4.Left = 1900
        frmTerraTerrain1.picStump1.Left = 2000
        frmTerraTerrain1.picMedkit1.Left = 245
        frmTerraTerrain1.picMedkit1.Visible = True
        frmTerraTerrain1.picMedkit1.Image = My.Resources.medkit
        frmTerraTerrain1.picGrassCap1.Left = 3250
        frmTerraTerrain1.picCoin1.Left = 989
        frmTerraTerrain1.picCoin2.Left = 1049
        frmTerraTerrain1.picCoin3.Left = 1109
        frmTerraTerrain1.picCoin4.Left = 1990
        frmTerraTerrain1.picCoin5.Left = 2050
        frmTerraBackground1.picBackground1.Top = 200
        frmTerraBackground1.picBackground2.Top = 425
        frmTerraBackground1.picBackground1.Top += 850
        frmTerraBackground1.picBackground2.Top += 850
        frmTerraBackground1.picBackground1.Left = 0
        frmTerraBackground1.picBackground2.Left = 0
        frmTerraTerrain1.picGrass3.Left = 3362
        frmTerraTerrain1.picDirt3.Left = 3362
        frmTerraTerrain1.picSmallBox2.Left = 3362
        frmTerraLevel1.picDefAlien2.Left = 3462
        frmTerraLevel1.picDefAlienHealth2.Left = 3487
        frmTerraTerrain1.picAmmo1.Left = 3487
        frmTerraTerrain1.picPlatform1.Left = 3662
        frmTerraTerrain1.picSmallBox3.Left = 3762
        frmTerraBackground1.picBludgeon1.Left = 4034
        frmTerraBackground1.picBludgeonHealth1.Left = 4069
        frmTerraLevel1.picDefAlienHealth2.Top = 384
        frmTerraLevel1.picDefAlien2.Top = 400
        frmTerraTerrain1.picSlope2.Left = 4860
        frmTerraTerrain1.picGrass4.Left = 5110
        frmTerraTerrain1.picSlope3.Left = 5360
        frmTerraTerrain1.picDirt4.Left = 4860
        frmTerraTerrain1.picDirt5.Left = 5360
        frmTerraTerrain1.picGrass5.Left = 5610
        For i = 0 To GameData.terrain.Length - 1
            GameData.terrain(i).Top += 1500
        Next
        For i = 0 To GameData.grass.Length - 1
            GameData.grass(i).Top += 1500
        Next
        For i = 0 To GameData.aliens.Length - 1
            GameData.aliens(i).Top += 1500
            GameData.alienHealth(i).Top += 1500
            GameData.aliens(i).Visible = True
            GameData.alienHealth(i).Visible = True
            GameData.aliens(i).Image = My.Resources.defAlienStandLeft
        Next
        For i = 0 To GameData.slopes.Length - 1
            GameData.slopes(i).Top += 1500
        Next
        For i = 0 To GameData.medkit.Length - 1
            GameData.medkit(i).Top += 1500
        Next
        For i = 0 To GameData.platforms.Length - 1
            GameData.platforms(i).Top += 1500
        Next
        For i = 0 To GameData.coin.Length - 1
            GameData.coin(i).Top += 1500
            GameData.coinCollected(i) = False
            GameData.coinCounter(i) = 0
            GameData.coin(i).Image = My.Resources.coin
            GameData.coin(i).Visible = True
        Next
        For i = 0 To GameData.ammoBox.Length - 1
            GameData.ammoBox(i).Top += 1500
            GameData.ammoCollected(i) = False
            GameData.ammoCounter(i) = 0
            GameData.ammoBox(i).Image = My.Resources.ammo
            GameData.ammoBox(i).Visible = True
        Next
        For i = 0 To GameData.bludgeon.Length - 1
            GameData.bludgeon(i).Top += 1500
            GameData.bludgeonHealthBar(i).Top += 1500
            GameData.bludgeonFlightSpeed(i) = 0
            GameData.bludgeonDead(i) = False
            GameData.bludgeonTimer(i) = 0
            GameData.bludgeonHealth(i) = 150
            GameData.bludgeonHealthBar(i).Image = My.Resources.heathbar100
            GameData.bludgeon(i).Visible = True
            GameData.bludgeonHealthBar(i).Visible = True
            GameData.bombDrop(i) = False
            GameData.bombTimer(i) = 0
            GameData.bombs(i).Visible = False
            GameData.bombs(i).Height = 35
            GameData.bombs(i).Image = My.Resources.bomb
        Next

        'Reset variables:
        GameData.textNumber = 0
        GameData.xPos = 0
        GameData.jumpHeight = 0
        GameData.jumping = False
        GameData.jumpTimer = 0
        GameData.cameraMoving = False
        GameData.speed = 0
        GameData.a = False
        GameData.leftKey = False
        GameData.rightKey = False
        GameData.falling = True
        GameData.rolling = True
        GameData.health = 10
        GameData.breakingWall = False
        GameData.breakModifier = 2.5
        GameData.alarm = True
        GameData.attack = True
        GameData.keyControl = False
        GameData.downKey = True
        GameData.s = False
        GameData.activeAmmo = 5
        GameData.ammo = 40
        frmTerraLevel1.lblAmmo.Text = GameData.activeAmmo & " | " & GameData.ammo
        For i = 0 To GameData.medkit.Length - 1
            GameData.medkitUsed(i) = False
        Next

        For x = 0 To GameData.enemyJumpHeight.Length - 1
            GameData.enemyJumpHeight(x) = 0
            GameData.knockbackTimer(x) = 0
            GameData.enemyDead(x) = False
            GameData.enemyHealth(x) = 100
            GameData.alienHealth(x).Image = My.Resources.heathbar100
        Next
        Return True
    End Function
    '=================================================================='

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        frmTerraBackground1.Close()
        frmTerraTerrain1.Close()
        Me.Close()
    End Sub

End Class