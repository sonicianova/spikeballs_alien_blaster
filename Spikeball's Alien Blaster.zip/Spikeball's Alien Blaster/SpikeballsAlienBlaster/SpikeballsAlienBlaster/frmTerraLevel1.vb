﻿Public Class frmTerraLevel1
    'Create physics variables:
    Dim speed As Integer = 10
    Dim speedRollMod As Double = 2
    Dim jumpHeight As Integer = 5
    Dim direction As String = "right"

    'Create control variables:
    Dim leftKey As Boolean = False
    Dim rightKey As Boolean = False
    Dim downKey As Boolean = True
    Dim a As Boolean = False
    Dim s As Boolean = False
    Dim jumping As Boolean = False
    Dim rolling As Boolean = True
    Dim falling As Boolean = True
    Dim cameraMoving As Boolean = False
    Dim xPos As Integer = 0
    Dim shootCooldown As Integer = 0
    Dim breakModifier As Double = 2.5
    Dim breakingWall As Boolean = False
    Dim alarm As Boolean = False
    Dim attack As Boolean = False
    Dim textNumber As Integer = 0
    Dim textTimer As Integer = 0
    Dim keyControl As Integer = False

    'Create timers:
    Dim transitionTimer As Integer = 0
    Dim jumpTimer As Integer = 0
    Dim knockbackTimer() As Integer = {0}
    Dim fadeTimer As Integer = -1

    'Create graphics variables
    Dim graphic As String = "spikeballStandRight"

    'Create storage array lists of entities:
    Dim enemySpeeds() As Integer = {8}
    Dim enemyCostume() As String = {"defAlienStandLeft", "defAlienStandLeft", "pilotStand"}
    Dim knockback() As Boolean = {True, True, False}
    Dim enemyJumpHeight() As Integer = {5}
    Dim knockBackModifier() As Double = {3.5}
    Dim knockbackDirection() As String = {"right"}
    Dim attackCooldown() As Integer = {45}
    Dim enemyHealth() As Double = {100}
    Dim enemyDead() As Boolean = {False}
    Dim bulletFiring() As Boolean = {False, False, False, False, False, False, False, False, False, False}
    Dim gravitySlopes() As Integer = {0}
    Dim enemyBulletFiring() As Boolean = {False, False, False, False, False, False, False, False, False, False}
    Dim bullet() As PictureBox
    Dim enemyBullet() As PictureBox
    Dim enemyBulletDirection() As String = {"right", "right", "right", "right", "right", "right", "right", "right", "right", "right"}
    Dim bulletDirection() As String = {"right", "right", "right", "right", "right", "right", "right", "right", "right", "right"}
    Dim grass() As PictureBox
    Dim enemyMovement() As Integer = {0}
    Dim aliens() As PictureBox
    Dim alienHealth() As PictureBox
    Dim terrain() As PictureBox
    Dim slopes() As PictureBox
    Dim grassCounter() As Integer = {0}

    'Create score variables:
    Dim score As Integer = 0
    Dim lives As Integer = 5
    Dim health As Double = 100

    Private Sub frmGame_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Start the timers on load:
        tmrGameTick.Start()

        bullet = New PictureBox() {picBullet1, picBullet2, picBullet3, picBullet4, picBullet5, picBullet6, picBullet7, picBullet8, picBullet9, picBullet10}
        enemyBullet = New PictureBox() {}
        aliens = New PictureBox() {picDefAlien1}
        alienHealth = New PictureBox() {picDefAlienHealth1}
        terrain = New PictureBox() {frmTerraTerrain1.picGrass1, frmTerraTerrain1.picDirt1, frmTerraTerrain1.picGrass2, frmTerraTerrain1.picBigBox1, frmTerraTerrain1.picSmallBox1, frmTerraTerrain1.picDirt2}
        slopes = New PictureBox() {frmTerraTerrain1.picSlope1}
        grass = New PictureBox() {frmTerraTerrain1.picGrassDeco1}

        'Resize form to saved settings:
        If My.Settings.fullscreen Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
        Me.Width = My.Settings.resWidth
        Me.Height = My.Settings.resHeight
        Me.Left = Screen.PrimaryScreen.Bounds.Width / 2 - Me.Width / 2
        Me.Top = Screen.PrimaryScreen.Bounds.Height / 2 - Me.Height / 2

        reset()
    End Sub

    'UNCOMMENT THIS TO BREAK ALL GRAPHICS >:D
    'Protected Overrides Sub OnPaintBackground(ByVal e As PaintEventArgs)
    'Do nothing.
    'End Sub

    'KEY DETECTION
    '=================================================================='
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        'Test if either of the keys have been pressed.
        'Set their value to true and override default button tabbing.
        If keyControl Then
            Select Case keyData
                Case Keys.Right
                    If Not rolling Then
                        rightKey = True
                    End If
                Case Keys.Left
                    If Not rolling Then
                        leftKey = True
                    End If
                Case Keys.Down
                    downKey = True
                    leftKey = False
                    rightKey = False
                    s = False
                Case Keys.A
                    a = True
                Case Keys.S
                    s = True
            End Select
        End If
    End Function
    Private Sub frmTerraLevel1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        'Test if either of the keys have been released:
        If keyControl Then
            e.SuppressKeyPress = True
            e.Handled = True
            Select Case e.KeyCode
                Case Keys.Right
                    rightKey = False
                Case Keys.Left
                    leftKey = False
                Case Keys.Down
                    downKey = False
                    rolling = False
                Case Keys.A
                    a = False
                Case Keys.S
                    s = False
            End Select
        End If
    End Sub
    

    'GAME TICK
    '=================================================================='
    Private Sub tmrGameTick_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrGameTick.Tick
        speed = 0
        'Story Text:
        Select Case textNumber
            'Add cases here as the story develops:
        End Select
        If textTimer > 0 Then
            textTimer -= 1
            If textTimer = 0 Then
                picTalkBox.Visible = False
                picTalkBox.Image = Nothing
            End If
        End If
        'Test if either of the keys are pressed, and if so move spikeball and change the animation:
        If rightKey Then
            direction = "right"
            speed = 10
            If Not cameraMoving Then
                picSpikeball.Left += speed
                picSpikeballHealth.Left += speed
            End If
            If Not graphic = "spikeballRunRight" Then
                picSpikeball.Image = My.Resources.spikeballRunRight
                graphic = "spikeballRunRight"
            End If
        ElseIf leftKey Then
            direction = "left"
            speed = -10
            If Not cameraMoving And picSpikeball.Left > 0 Then
                picSpikeball.Left += speed
                picSpikeballHealth.Left += speed
            End If
            If Not graphic = "spikeballRunLeft" Then
                picSpikeball.Image = My.Resources.spikeballRunLeft
                graphic = "spikeballRunLeft"
            End If
        ElseIf downKey And keyControl Then
            'If spikeball is not rolling then play the transition animation and
            'the rolling animation.
            If Not rolling = True Then
                speedRollMod = 2
                'If the graphic is not transition switch it to transition and start
                'the transition timer.
                If Not graphic = "transition" Then
                    If direction = "right" Then
                        picSpikeball.Image = My.Resources.spikeballTransitionRight
                    ElseIf direction = "left" Then
                        picSpikeball.Image = My.Resources.spikeballTransitionLeft
                    End If
                    graphic = "transition"
                    transitionTimer = 30
                End If
                'If the transition timer is 0 play the rolling animation.
                'Else decrease the transition timer.
                If transitionTimer = 0 Then
                    If direction = "right" Then
                        picSpikeball.Image = My.Resources.spikeballSpinRight
                    ElseIf direction = "left" Then
                        picSpikeball.Image = My.Resources.spikeballSpinLeft
                    End If
                    rolling = True
                Else
                    transitionTimer -= 1
                End If
            End If
            'If the speed is not already set set it:
            If direction = "left" Then
                speed = -10
            Else
                speed = 10
            End If
            'If spikeball is not in transition roll him forward.
            If transitionTimer = 0 And Not cameraMoving And picSpikeball.Left > 0 Then
                picSpikeball.Left += speed * speedRollMod
                picSpikeballHealth.Left += speed * speedRollMod
            End If
        ElseIf direction = "right" And keyControl Then
            picSpikeball.Image = My.Resources.spikeballStandRight
            graphic = "spikeballStandRight"
        ElseIf direction = "left" And keyControl Then
            picSpikeball.Image = My.Resources.spikeballStandLeft
            graphic = "spikeballStandLeft"
        End If
        If a Then
            'If the a key is pressed and the player is not jumping and not falling then
            'start the jump timer and set jumping to true.
            If jumping = False And falling = False Then
                jumpHeight = 5
                picSpikeball.Top -= jumpHeight
                picSpikeballHealth.Top -= jumpHeight
                jumpTimer = 15
                jumping = True
            End If
        End If
        If s Then
            'If the s key is pressed and the player is not shooting then start the shoot timer and
            'release a bullet.
            If Not downKey Then
                If shootCooldown = 0 Then
                    'Test for a free bullet and make it fire:
                    For i = 0 To 9
                        If Not bulletFiring(i) Then
                            'Set up the bullet for it to fire:
                            bulletFiring(i) = True
                            bullet(i).Visible = True
                            bullet(i).Top = picSpikeball.Top + 80
                            If direction = "right" Then
                                bullet(i).Left = picSpikeball.Left + picSpikeball.Width
                            Else
                                bullet(i).Left = picSpikeball.Left - bullet(i).Width
                            End If
                            bulletDirection(i) = direction
                            shootCooldown = 20
                            Exit For
                        End If
                    Next
                End If
            End If
        End If

        'If the bullet cooldown is greater than 0 lower it:
        If shootCooldown > 0 Then
            shootCooldown -= 1
        End If

        'Make all active bullets move:
        For i = 0 To 9
            'Fire every player bullet.
            If bulletFiring(i) Then
                If bulletDirection(i) = "right" Then
                    bullet(i).Left += 40
                Else
                    bullet(i).Left -= 40
                End If
                If bullet(i).Left > Me.Width - bullet(i).Width Or bullet(i).Left < 0 Or anyWall(bullet(i)) Then
                    bulletFiring(i) = False
                    bullet(i).Visible = False
                End If
                For x = 0 To aliens.Length - 1
                    If aliens(x).Bounds.IntersectsWith(bullet(i).Bounds) And Not enemyDead(x) Then
                        hurtEntity(20, x)
                        bulletFiring(i) = False
                        bullet(i).Visible = False
                    End If
                Next
            End If
            'Fire every enemy bullet.
            If enemyBulletFiring(i) Then
                enemyBullet(i).Left -= 40
                If enemyBullet(i).Left > Me.Width - enemyBullet(i).Width Or enemyBullet(i).Left < 0 Or anyWall(enemyBullet(i)) Then
                    enemyBulletFiring(i) = False
                    enemyBullet(i).Visible = False
                End If
                If enemyBullet(i).Bounds.IntersectsWith(picSpikeball.Bounds) Then
                    hurt(1)
                    enemyBulletFiring(i) = False
                    enemyBullet(i).Visible = False
                End If
            End If
        Next

        'CALL AI:
        If keyControl Then
            For i = 0 To aliens.Length - 1
                defaultAlien(aliens(i), alienHealth(i), i)
            Next
        End If

        'CALL WALL DETECT FUNCTIONS:
        For i = 0 To terrain.Length - 1
            wallDetect(terrain(i))
        Next
        For i = 0 To slopes.Length - 1
            slopeDetectionRight(slopes(i))
        Next

        'If the player is not rolling call wall detection on entities:
        If Not rolling And Not downKey Then
            For i = 0 To aliens.Length - 1
                If Not enemyDead(i) Then
                    wallDetect(aliens(i))
                End If
            Next
        End If

        'Quality of life animations on decorations:
        For i = 0 To grass.Length - 1
            If picSpikeball.Bounds.IntersectsWith(grass(i).Bounds) And Not grass(i).Image Is My.Resources.grassCut Then

            End If
        Next

        'Gravity and jumping:
        If jumping = False And falling = True Then
            'If the player is not jumping and the player is falling then
            'apply gravity.
            If frmTerraTerrain1.picGrass1.Top > 493 And picSpikeball.Top >= Me.Height / 2 - picSpikeball.Height / 2 Then
                frmTerraTerrain1.picGrass1.Top -= 30
                frmTerraTerrain1.picDirt1.Top -= 30
                frmTerraTerrain1.picBigBox1.Top -= 30
                frmTerraTerrain1.picSmallBox1.Top -= 30
                picDefAlien1.Top -= 30
                picDefAlienHealth1.Top -= 30
                jumpHeight = 0
            Else
                If rolling Then
                    picSpikeball.Top += 25
                    picSpikeballHealth.Top += 25
                Else
                    picSpikeball.Top += 20
                    picSpikeballHealth.Top += 20
                End If
                jumpHeight = 0
            End If
        ElseIf jumping = True And jumpTimer > 0 Then
            'If the player is jumping reduce the timer of their jumping and
            'move them upward.
            jumpTimer -= 1
            If rolling Then
                picSpikeball.Top -= jumpHeight / 2
                picSpikeballHealth.Top -= jumpHeight / 2
            Else
                picSpikeball.Top -= jumpHeight
                picSpikeballHealth.Top -= jumpHeight
            End If
            If Not jumpHeight = 5 Then
                jumpHeight += 1
            End If
            'If the jumpTick = 0 then turn falling on.
            If jumpTimer = 0 Then
                falling = True
            End If
        ElseIf jumpTimer = 0 And jumping = True Then
            'If the player's jump timer has run out then slow their jumping to 0
            'and then turn gravity back on.
            If jumpHeight > -10 Then
                jumpHeight -= 1
            End If
            If rolling And jumpHeight <= 0 Then
                picSpikeball.Top -= jumpHeight * 1.5
                picSpikeballHealth.Top -= jumpHeight * 1.5
            ElseIf rolling Then
                picSpikeball.Top -= jumpHeight
                picSpikeballHealth.Top -= jumpHeight
            Else
                picSpikeball.Top -= jumpHeight * 1.5
                picSpikeballHealth.Top -= jumpHeight * 1.5
            End If
        ElseIf keyControl = False Then
            rolling = False
            downKey = False
            keyControl = True
            hurt(5)
        End If

        'Camera movement:
        If picSpikeball.Left > Me.Width * 0.6 And direction = "right" And (rightKey Or rolling) Then
            'If the player moves to the right of the center it will move the camera with the player
            'to the right, moving the entire level to the left.
            cameraMoving = True
            xPos += speed
        ElseIf frmTerraTerrain1.picGrass1.Left >= 0 Then
            'This locks the camera so it cannot go left of the start point.
            speedRollMod = 2
            frmTerraTerrain1.picGrass1.Left = 0
            frmTerraTerrain1.picDirt1.Left = 0
            frmTerraTerrain1.picSlope1.Left = 1500
            frmTerraTerrain1.picBigBox1.Left = 0
            frmTerraTerrain1.picSmallBox1.Left = 0
            frmTerraTerrain1.picDirt2.Left = 1500
            frmTerraTerrain1.picGrass2.Left = 1750
            cameraMoving = False
        ElseIf picSpikeball.Left < Me.Width * 0.4 And direction = "left" And (leftKey Or rolling) Then
            'If the player moves to the left of the center it will move the camera with the player
            'to the left, moving the entire level to the right.
            cameraMoving = True
            xPos += speed
        Else
            'If the player is not moving stop the camera movement.
            cameraMoving = False
        End If
        If cameraMoving Then
            If rolling Then
                moveLevel(speed * 2)
            Else
                moveLevel(speed)
            End If
        End If

        'If the player is not touching any of the level elements turn gravity on.
        If jumping = False And Not anyWall(picSpikeball) And Not anyEntity(picSpikeball) And Not anySlope(picSpikeball) Then
            falling = True
            jumping = False
            jumpTimer = 0
        End If

        'If the player has fallen off the screen then kill them:
        If picSpikeball.Top > Me.Height Then
            hurt(1000)
        End If

        'Move every entity based on the sum total of the values for movement for them:
        For i = 0 To aliens.Length - 1
            aliens(i).Left += enemyMovement(i)
            alienHealth(i).Left += enemyMovement(i)
            enemyMovement(i) = 0
        Next
    End Sub
    '=================================================================='

    'Default alien function:
    Dim rollPain As Integer = 0
    Private Function defaultAlien(ByVal alien, ByVal alienHealth, ByVal position)
        'If the alien is not dead then perform AI:
        If Not enemyDead(position) Then
            'Find the direction of Spikeball and move toward it.
            If attack And picSpikeball.Left + picSpikeball.Width < alien.Left And alien.Left > 0 - xPos Then 'And Not (touchingWall(picFragileWall1, alien) Or touchingWall(picFragileWall2, alien) Or touchingWall(picFragileWall3, alien) And alien.Left > picFragileWall1.Left) Then
                'If Spikeball is to the left move left:
                enemyMovement(position) -= enemySpeeds(position)
                If Not enemyCostume(position) = "defAlienWalkLeft" Then
                    alien.Image = My.Resources.defAlienWalkLeft
                    enemyCostume(position) = "defAlienWalkLeft"
                End If
            End If
            If attack And picSpikeball.Left > alien.Left + alien.Width And alien.Left < Me.Width Then 'And Not (touchingWall(picFragileWall1, alien) Or touchingWall(picFragileWall2, alien) Or touchingWall(picFragileWall3, alien) Or touchingWall(picWall3, alien) And alien.Left > picFragileWall1.Right) Then
                'If spikeball is to the right move right:
                enemyMovement(position) += enemySpeeds(position)
                If Not enemyCostume(position) = "defAlienWalkRight" Then
                    alien.Image = My.Resources.defAlienWalkRight
                    enemyCostume(position) = "defAlienWalkRight"
                End If
            End If
            'Test if they're pushing against another alien:
            For i = 0 To aliens.Length - 1
                If Not i = position And Not enemyDead(i) And alien.Bounds.IntersectsWith(aliens(i).Bounds) Then
                    If knockback(position) Then
                        If knockbackDirection(position) = "right" Then
                            enemyMovement(position) -= enemySpeeds(0) * knockBackModifier(position)
                            knockbackDirection(position) = "left"
                        ElseIf alien.Left > 0 - xPos Then
                            enemyMovement(position) += enemySpeeds(0) * knockBackModifier(position)
                            knockbackDirection(position) = "right"
                        End If
                    Else
                        If alien.Left < aliens(i).Left Then
                            enemyMovement(position) -= enemySpeeds(position)
                        Else
                            enemyMovement(position) += enemySpeeds(position)
                        End If
                    End If
                End If
            Next
            'Test if Spikeball is pushing them:
            If attack And picSpikeball.Bounds.IntersectsWith(alien.Bounds) Then
                If rolling And transitionTimer <= 0 Then
                    'If the player is rolling into them then start the knockback timer:
                    If Not knockback(position) Then
                        knockbackTimer(position) = 25
                        knockback(position) = True
                        knockbackDirection(position) = direction
                    End If
                    attackCooldown(position) = 15
                    If rollPain <= 0 Then
                        rollPain = 30
                        hurtEntity(20, position)
                    End If
                Else
                    'Attack the player if the attack cooldown is 0:
                    If attackCooldown(position) <= 0 Then
                        If picSpikeball.Left < alien.Left Then
                            If Not enemyCostume(position) = "defAlienAttackLeft" Then
                                alien.Image = My.Resources.defAlienAttackLeft
                                enemyCostume(position) = "defAlienAttackLeft"
                            End If
                        ElseIf picSpikeball.Left + picSpikeball.Width > alien.Left Then
                            If Not enemyCostume(position) = "defAlienAttackRight" Then
                                alien.Image = My.Resources.defAlienAttackRight
                                enemyCostume(position) = "defAlienAttackRight"
                            End If
                        End If
                        hurt(1)
                        attackCooldown(position) = 45
                    Else
                        attackCooldown(position) -= 1
                    End If
                End If
            End If
            rollPain -= 1
            'If the alien is being knocked back then knock them back:
            If knockback(position) Then
                If knockbackTimer(position) > 0 Then
                    knockbackTimer(position) -= 1
                Else
                    If enemyJumpHeight(position) > -5 Then
                        enemyJumpHeight(position) -= 1
                        knockBackModifier(position) -= 0.05
                    End If
                    If anyWall(alien) Then
                        enemyJumpHeight(position) = 5
                        knockback(position) = False
                        knockBackModifier(position) = 3.5
                    End If
                End If
                alien.Top -= enemyJumpHeight(position)
                alienHealth.Top -= enemyJumpHeight(position)
                'If the alien is not touching one of the possible walls, move them to the left or right.
                If Not anyWall(alien) Then
                    If knockbackDirection(position) = "right" Then
                        enemyMovement(position) += enemySpeeds(position) * knockBackModifier(position) * 1.2
                    ElseIf alien.Left > 0 - xPos Then
                        enemyMovement(position) -= enemySpeeds(position) * knockBackModifier(position) * 1.2
                    End If
                Else
                    If knockbackDirection(position) = "right" Then
                        knockBackModifier(position) /= 1.5
                        enemyMovement(position) -= enemySpeeds(position) * knockBackModifier(position)
                        knockbackDirection(position) = "left"
                    ElseIf alien.Left > 0 - xPos Then
                        knockBackModifier(position) /= 1.5
                        enemyMovement(position) += enemySpeeds(position) * knockBackModifier(position)
                        knockbackDirection(position) = "right"
                    End If
                End If
            End If
            'If touchingWall(picCeiling1, alien) Or touchingWall(picAlarm, alien) Or touchingWall(picCeiling2, alien) Or touchingWall(picTutorialText3, alien) Or touchingWall(picCorner1, alien) Then
            '    knockbackTimer(position) = 0
            '    enemyJumpHeight(position) = 0
            '    alien.Top += 5
            'End If
            'If the alien is not affected by gravity make them fall:
            If Not anyWall(alien) And Not knockback(position) Then
                alien.Top += 5
                alienHealth.Top += 5
            End If
            'If the alien has fallen off the screen kill them:
            If alien.Top >= Me.Height Then
                hurtEntity(100, position)
            End If
            For i = 0 To slopes.Length - 1
                entitySlopeDetectionRight(slopes(i), position)
            Next
        End If
        Return True
    End Function
    'WALL DETECT
    Private Function wallDetect(ByVal wallName)

        If picSpikeball.Bounds.IntersectsWith(wallName.Bounds) Then
            If picSpikeball.Top > wallName.Top + wallName.Height / 1.2 Then
                'Negate top movement
                picSpikeball.Top += jumpHeight
                picSpikeballHealth.Top += jumpHeight
                jumpTimer = 0
                jumpHeight = 0
                Return True
            ElseIf picSpikeball.Top < wallName.Top - 100 Then
                'Stop the player from falling:
                falling = False
                jumping = False
                jumpHeight = 0
                jumpTimer = 0
                Return True
            ElseIf picSpikeball.Left < wallName.Left And direction = "right" Then
                If picSpikeball.Top < wallName.Top + wallName.Height Then
                    'Negate left movement
                    picSpikeball.Left -= speed
                    picSpikeballHealth.Left -= speed
                    speed = 0
                    If rolling And keyControl And Not anySlope(picSpikeball) Then
                        rolling = False
                        downKey = False
                    End If
                    Return True
                End If
            ElseIf picSpikeball.Left > wallName.Left And direction = "left" Then
                If picSpikeball.Top < wallName.Top + wallName.Height Then
                    'Negate right movement
                    picSpikeball.Left -= speed
                    picSpikeballHealth.Left -= speed
                    speed = 0
                    If rolling And keyControl And Not anySlope(picSpikeball) Then
                        rolling = False
                        downKey = False
                    End If
                    Return True
                End If
            Else
                Return False
            End If
        End If
        Return True

    End Function
    Dim gravitySlope As Integer = 0
    'Player slope detection:
    Private Function slopeDetectionRight(ByVal wallName)
        If picSpikeball.Bounds.IntersectsWith(wallName.Bounds) Then
            'Stop the player from falling:
            If falling Then
                falling = False
                jumping = False
                jumpHeight = 0
                jumpTimer = 0
                gravitySlope = 3
            End If
            'If the gravity on the slope is running fall him onto the correct spot on the slope.
            If gravitySlope > -1 And picSpikeball.Top <= wallName.Top + (35 - (picSpikeball.Left - wallName.Left) * 0.25) - picSpikeball.Height Then
                gravitySlope -= 1
                picSpikeball.Top += (35 - (picSpikeball.Left - wallName.Left) * 0.25) / 3
                picSpikeballHealth.Top += (35 - (picSpikeball.Left - wallName.Left) * 0.25) / 3
            End If
            If picSpikeball.Left >= wallName.Left - 20 And picSpikeball.Left <= wallName.Width + wallName.Left - picSpikeball.Width Then
                If direction = "right" And (rightKey Or rolling) Then
                    'If spikeball is going up the slope (to the right), make him move up. Decrease his speed and make him go up faster if he's rolling.
                    If rolling Then
                        speedRollMod /= 2
                        picSpikeball.Top -= 5
                        picSpikeballHealth.Top -= 5
                    Else
                        picSpikeball.Top -= 3
                        picSpikeballHealth.Top -= 3
                    End If
                ElseIf direction = "left" And (leftKey Or rolling) Then
                    'If spikeball is going down the slope (to the left) make him go down. Increase his speed and make him go up much faster if he's rolling.
                    If rolling Then
                        speedRollMod *= 2
                        picSpikeball.Top += 6.5
                        picSpikeballHealth.Top += 6.5
                    Else
                        picSpikeball.Top += 3
                        picSpikeballHealth.Top += 3
                    End If
                End If
            End If
        End If
        Return True

    End Function
    'Entity slope detection:
    Private Function entitySlopeDetectionRight(ByVal wallName, ByVal position)
        If aliens(position).Bounds.IntersectsWith(wallName.Bounds) Then
            'If the gravity on the slope is running fall him onto the correct spot on the slope.
            If gravitySlopes(position) > -1 And aliens(position).Top <= wallName.Top + (25 - (aliens(position).Left - wallName.Left) * 0.25) - aliens(position).Height Then
                gravitySlopes(position) -= 1
                aliens(position).Top += (25 - (aliens(position).Left - wallName.Left) * 0.25) / 3
                alienHealth(position).Top += (25 - (aliens(position).Left - wallName.Left) * 0.25) / 3
            End If
            If aliens(position).Left >= wallName.Left - 20 And aliens(position).Left <= wallName.Width + wallName.Left - aliens(position).Width Then
                If picSpikeball.Left > aliens(position).Left And Not picSpikeball.Bounds.IntersectsWith(aliens(position).Bounds) Then
                    'If spikeball is going up the slope (to the right), make him move up. 
                    aliens(position).Top -= 0.7
                    alienHealth(position).Top -= 0.7
                ElseIf picSpikeball.Left < aliens(position).Left And Not picSpikeball.Bounds.IntersectsWith(aliens(position).Bounds) Then
                    'If spikeball is going down the slope (to the left) make him go down. 
                    aliens(position).Top += 0.7
                    alienHealth(position).Top += 0.7
                End If
            End If
        End If
        Return True

    End Function
    'Boolean method for if an entity is touching the wall:
    Private Function touchingWall(ByVal wallName, ByVal character)
        If character.Bounds.IntersectsWith(wallName.Bounds) Then
            Return True
        Else
            Return False
        End If
    End Function
    'Boolean method for if an entity is touching any slope:
    Private Function anySlope(ByVal character)
        For i = 0 To slopes.Length - 1
            If touchingWall(slopes(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any wall:
    Private Function anyWall(ByVal character)
        For i = 0 To terrain.Length - 1
            If touchingWall(terrain(i), character) Then
                Return True
            End If
        Next
        Return False
    End Function
    'Boolean method for if an entity is touching any entity:
    Private Function anyEntity(ByVal character)
        For i = 0 To aliens.Length() - 1
            If Not enemyDead(i) And touchingWall(aliens(i), character) Then
                Return True
            End If
        Next


        Return False
    End Function
    'Move the level elements according to speed:
    Private Function moveLevel(ByVal distance)
        For i = 0 To terrain.Length - 1
            terrain(i).Left -= distance
        Next
        For i = 0 To aliens.Length - 1
            enemyMovement(i) -= distance
        Next
        For i = 0 To 9
            bullet(i).Left -= distance
        Next
        For i = 0 To slopes.Length - 1
            slopes(i).Left -= distance
        Next
        For i = 0 To grass.Length - 1
            grass(i).Left -= distance
        Next
        Return True
    End Function
    'Hurt the player:
    Private Function hurt(ByVal pain)
        health -= pain
        If health = 10 Then
            picSpikeballHealth.Image = My.Resources.heathbar100
        ElseIf health = 9 Then
            picSpikeballHealth.Image = My.Resources.heathbar90
        ElseIf health = 8 Then
            picSpikeballHealth.Image = My.Resources.heathbar80
        ElseIf health = 7 Then
            picSpikeballHealth.Image = My.Resources.heathbar70
        ElseIf health = 6 Then
            picSpikeballHealth.Image = My.Resources.heathbar60
        ElseIf health = 5 Then
            picSpikeballHealth.Image = My.Resources.heathbar50
        ElseIf health = 4 Then
            picSpikeballHealth.Image = My.Resources.heathbar40
        ElseIf health = 3 Then
            picSpikeballHealth.Image = My.Resources.heathbar30
        ElseIf health = 2 Then
            picSpikeballHealth.Image = My.Resources.heathbar20
        ElseIf health = 1 Then
            picSpikeballHealth.Image = My.Resources.healthbar10
        ElseIf health < 0 Then
            'RESET THE FORM
            reset()
        End If
        Return True
    End Function
    'Reset the form:
    Private Function reset()
        'Reset entities:
        picSpikeball.Left = Me.Width / 2 - picSpikeball.Width / 2
        picSpikeball.Top = -100
        picSpikeball.Image = My.Resources.spikeballSpinRight
        picSpikeballHealth.Left = Me.Width / 2 - picSpikeballHealth.Width / 2
        picSpikeballHealth.Top = -116
        picSpikeballHealth.Image = My.Resources.heathbar100

        'Reset terrain:
        frmTerraTerrain1.picGrass1.Visible = True
        frmTerraTerrain1.picGrass1.Left = 0
        frmTerraTerrain1.picGrass1.Top += 1500
        frmTerraTerrain1.picDirt1.Visible = True
        frmTerraTerrain1.picDirt1.Left = 0
        frmTerraTerrain1.picDirt1.Top += 1500
        frmTerraTerrain1.picSlope1.Visible = True
        frmTerraTerrain1.picSlope1.Left = 1500
        frmTerraTerrain1.picGrass2.Visible = True
        frmTerraTerrain1.picSmallBox1.Top += 1500
        frmTerraTerrain1.picBigBox1.Top += 1500
        picDefAlien1.Top += 1500
        picDefAlienHealth1.Top += 1500

        'Reset variables:
        textNumber = 0
        xPos = 0
        jumpHeight = 0
        jumping = False
        jumpTimer = 0
        cameraMoving = False
        speed = 0
        a = False
        leftKey = False
        rightKey = False
        falling = True
        rolling = True
        health = 10
        lives -= 1
        breakingWall = False
        breakModifier = 2.5
        alarm = True
        attack = True
        keyControl = False
        downKey = True
        s = False

        For x = 0 To enemyJumpHeight.Length - 1
            enemyJumpHeight(x) = 0
            knockbackTimer(x) = 0
            enemyDead(x) = False
            enemyHealth(x) = 100
        Next
        Return True
    End Function
    'Hurt any entity:
    Private Function hurtEntity(ByVal pain, ByVal position)
        enemyHealth(position) -= pain
        Select Case enemyHealth(position)
            Case 100
                alienHealth(position).Image = My.Resources.heathbar100
            Case Is >= 90
                alienHealth(position).Image = My.Resources.heathbar90
            Case Is >= 80
                alienHealth(position).Image = My.Resources.heathbar80
            Case Is >= 70
                alienHealth(position).Image = My.Resources.heathbar70
            Case Is >= 60
                alienHealth(position).Image = My.Resources.heathbar60
            Case Is >= 50
                alienHealth(position).Image = My.Resources.heathbar50
            Case Is >= 40
                alienHealth(position).Image = My.Resources.heathbar40
            Case Is >= 30
                alienHealth(position).Image = My.Resources.heathbar30
            Case Is >= 20
                alienHealth(position).Image = My.Resources.heathbar20
            Case Is >= 10
                alienHealth(position).Image = My.Resources.healthbar10
            Case Else
                If enemyHealth(position) <= 0 Then
                    alienHealth(position).Image = My.Resources.healthbar0
                    enemyDead(position) = True
                    aliens(position).Visible = False
                    alienHealth(position).Visible = False
                End If
        End Select
        Return True
    End Function
    '=================================================================='

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        frmTerraTerrain1.Close()
        Me.Close()
    End Sub
End Class