﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTerraTerrain1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picGrassDeco1 = New System.Windows.Forms.PictureBox
        Me.picDirt2 = New System.Windows.Forms.PictureBox
        Me.picSmallBox1 = New System.Windows.Forms.PictureBox
        Me.picBigBox1 = New System.Windows.Forms.PictureBox
        Me.picGrass2 = New System.Windows.Forms.PictureBox
        Me.picSlope1 = New System.Windows.Forms.PictureBox
        Me.picDirt1 = New System.Windows.Forms.PictureBox
        Me.picGrass1 = New System.Windows.Forms.PictureBox
        CType(Me.picGrassDeco1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDirt2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSmallBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBigBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrass2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSlope1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDirt1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrass1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picGrassDeco1
        '
        Me.picGrassDeco1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrassDeco1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.grass
        Me.picGrassDeco1.Location = New System.Drawing.Point(1016, 394)
        Me.picGrassDeco1.Name = "picGrassDeco1"
        Me.picGrassDeco1.Size = New System.Drawing.Size(100, 50)
        Me.picGrassDeco1.TabIndex = 52
        Me.picGrassDeco1.TabStop = False
        '
        'picDirt2
        '
        Me.picDirt2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDirt2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.dirt
        Me.picDirt2.Location = New System.Drawing.Point(1500, 483)
        Me.picDirt2.Name = "picDirt2"
        Me.picDirt2.Size = New System.Drawing.Size(1750, 300)
        Me.picDirt2.TabIndex = 51
        Me.picDirt2.TabStop = False
        '
        'picSmallBox1
        '
        Me.picSmallBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSmallBox1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.boxSmall
        Me.picSmallBox1.Location = New System.Drawing.Point(0, 148)
        Me.picSmallBox1.Name = "picSmallBox1"
        Me.picSmallBox1.Size = New System.Drawing.Size(100, 100)
        Me.picSmallBox1.TabIndex = 50
        Me.picSmallBox1.TabStop = False
        '
        'picBigBox1
        '
        Me.picBigBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picBigBox1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.boxLarge
        Me.picBigBox1.Location = New System.Drawing.Point(0, 248)
        Me.picBigBox1.Name = "picBigBox1"
        Me.picBigBox1.Size = New System.Drawing.Size(200, 200)
        Me.picBigBox1.TabIndex = 49
        Me.picBigBox1.TabStop = False
        '
        'picGrass2
        '
        Me.picGrass2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrass2.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.grassFloor
        Me.picGrass2.Location = New System.Drawing.Point(1750, 383)
        Me.picGrass2.Name = "picGrass2"
        Me.picGrass2.Size = New System.Drawing.Size(1500, 100)
        Me.picGrass2.TabIndex = 48
        Me.picGrass2.TabStop = False
        '
        'picSlope1
        '
        Me.picSlope1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picSlope1.Image = Global.SpikeballsAlienBlaster.My.Resources.Resources.rightSlope
        Me.picSlope1.Location = New System.Drawing.Point(1500, 383)
        Me.picSlope1.Name = "picSlope1"
        Me.picSlope1.Size = New System.Drawing.Size(250, 100)
        Me.picSlope1.TabIndex = 47
        Me.picSlope1.TabStop = False
        '
        'picDirt1
        '
        Me.picDirt1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picDirt1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.dirt
        Me.picDirt1.Location = New System.Drawing.Point(0, 533)
        Me.picDirt1.Name = "picDirt1"
        Me.picDirt1.Size = New System.Drawing.Size(1500, 200)
        Me.picDirt1.TabIndex = 46
        Me.picDirt1.TabStop = False
        '
        'picGrass1
        '
        Me.picGrass1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.picGrass1.BackgroundImage = Global.SpikeballsAlienBlaster.My.Resources.Resources.grassFloor
        Me.picGrass1.Location = New System.Drawing.Point(0, 433)
        Me.picGrass1.Name = "picGrass1"
        Me.picGrass1.Size = New System.Drawing.Size(1500, 100)
        Me.picGrass1.TabIndex = 45
        Me.picGrass1.TabStop = False
        '
        'frmTerraTerrain1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1280, 720)
        Me.Controls.Add(Me.picGrassDeco1)
        Me.Controls.Add(Me.picDirt2)
        Me.Controls.Add(Me.picSmallBox1)
        Me.Controls.Add(Me.picBigBox1)
        Me.Controls.Add(Me.picGrass2)
        Me.Controls.Add(Me.picSlope1)
        Me.Controls.Add(Me.picDirt1)
        Me.Controls.Add(Me.picGrass1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmTerraTerrain1"
        Me.ShowInTaskbar = False
        Me.Text = "Spikeball's Alien Blaster"
        CType(Me.picGrassDeco1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDirt2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSmallBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBigBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrass2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSlope1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDirt1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrass1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picDirt1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrass1 As System.Windows.Forms.PictureBox
    Friend WithEvents picSlope1 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrass2 As System.Windows.Forms.PictureBox
    Friend WithEvents picBigBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents picSmallBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents picDirt2 As System.Windows.Forms.PictureBox
    Friend WithEvents picGrassDeco1 As System.Windows.Forms.PictureBox
End Class
